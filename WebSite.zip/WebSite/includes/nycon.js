/*
###############################################
# CONTROLE: LEITURA,GRAVA��O SMARTCARD NYKON  #
###############################################
*/
var nrFac	    = "";
var idCliente	    = "";
var idFilialCliente = "";
var placa	    = "";
var path_nykon      = "c:\\nykon\\";
var cont_nykon = 0;

/*
 arr[0] = portaNycom
 arr[1] = pedido
 arr[2] = cliente
 arr[3] = placa
*/

function gravarQuantidade (portaNycon,posicao,quantidade)
{
	try
	{	
		arquivoEnvio.WriteLine("Gravar_Quantidade("+   portaNycon  + ",\"" + posicao + "\",\"" + quantidade +"\")");
	}catch(excpt){
		alert(excpt.description +"\ne Erro Number " + excpt.number);
	}
}	

function gravarCartaoNycon(arr){
	try
	{
		arquivoEnvio.WriteLine("Cartao("+arr[0]+")");
		arquivoEnvio.WriteLine("Limpar_Cartao("+arr[0]+")");  
		arquivoEnvio.WriteLine("Gravar_Dados_Pedido("+arr[0]+ ",\"" + arr[1] + "\",\"" + arr[2] +"\",\""+ arr[3]  + "\",\"" + 1 +"\")");
	}catch(excpt){
		return false;
	}
	return true;
}
		
function abrirArquivo(){
	 try
	 {	
		this.Fso =  new ActiveXObject("Scripting.FileSystemObject");
		arquivoEnvio = this.Fso.CreateTextFile(path_nykon + "Envio.txt",true);
		//arquivoEnvio = this.Fso.OpenTextFile(path_nykon + "Envio.txt",8,false); 
	 }catch(excpt){
		//alert(excpt.description +"\ne Erro Number " + excpt.number);
		var bResp = (msgBox("Para essa opera��o, � necessario mudar as configura��es do Browser!\nExibir ajuda?",null,"SIM","NAO") == 0) ? true : false;

		if (bResp == true){
			showModalDialog("../help/nycon/HelpNycon.html",'',"center=yes;dialogWidth=1000px;dialogHeight=1000px;status=no;scroll=no");
		}			
		return false;
	}
	return true;
}


function Fu_gravarCartao(arr)
{
	
	 try
	 {	
		this.Fso =  new ActiveXObject("Scripting.FileSystemObject");
		arquivoEnvio = this.Fso.CreateTextFile(path_nykon + "Envio.txt",true);
		arquivoEnvio.WriteLine("Cartao("+arr[0]+")");
		arquivoEnvio.WriteLine("Limpar_Cartao("+arr[0]+")");  
		arquivoEnvio.WriteLine("Gravar_Dados_Pedido("+arr[0]+ ",\"" + arr[1] + "\",\"" + arr[2] +"\",\""+ arr[3]  + "\",\"" + 1 +"\")");
		arquivoEnvio.close();
			
	 }catch(excpt){
		var bResp = (msgBox("Para essa opera��o, � necessario mudar as configura��es do Browser!\nExibir ajuda?",null,"SIM","NAO") == 0) ? true : false;

		if (bResp == true)
		{
			showModalDialog("../help/nycon/HelpNycon.html",'',"center=yes;dialogWidth=1000px;dialogHeight=1000px;status=no;scroll=no");
		}			
		return false;
		}
	return true;
}	

//arr[0] = portaNycom
//arr[1] = pedido
//arr[2] = cliente
//arr[3] = placa
function Fu_lerCartao(arr)
{
	 try
	 {	
		this.Fso =  new ActiveXObject("Scripting.FileSystemObject");
		arquivoEnvio = this.Fso.CreateTextFile(path_nykon + "Envio.txt",true);
		arquivoEnvio.WriteLine("Cartao("+arr[0]+")");
		arquivoEnvio.WriteLine("Ler_Dados_Pedido("+arr[0]+")");  
		arquivoEnvio.WriteLine("Ler_Quantidade_Total("+arr[0]+")");
		arquivoEnvio.WriteLine("Ler_Temperatura_Total("+arr[0]+")");
	 }catch(excpt){

		var bResp = (msgBox("Para essa opera��o, � necessario mudar as configura��es do Browser!\nExibir ajuda?",null,"SIM","NAO") == 0) ? true : false;

		if (bResp == true)
		{
			showModalDialog("../help/nycon/HelpNycon.html",'',"center=yes;dialogWidth=1000px;dialogHeight=1000px;status=no;scroll=no");
		}			
		return false;
		
	 }finally{
		if(this.Fso != undefined)
		{	
			arquivoEnvio.close();
		}
	}
	return true;
}	



	
function Fu_gravarQuantidade (portaNycon,posicao,quantidade)
{
	try
	{	
		arquivoEnvio = this.Fso.OpenTextFile(path_nykon + "Envio.txt",8,false); 
		arquivoEnvio.WriteLine("Gravar_Quantidade("+   portaNycon  + ",\"" + posicao + "\",\"" + quantidade +"\")");
	}catch(excpt){
		alert(excpt.description +"\ne Erro Number " + excpt.number);
	}finally{
		arquivoEnvio.close();
	}
}	
	

/*function para Leitura quando a opera��o for  "Gravar_Cart�o".*/
function Fu_Ler_RetornoG()
{		
		this.Fso =  new ActiveXObject("Scripting.FileSystemObject");
		//alert("Diretorio : " + path_nykon)
		//alert(this.Fso.FileExists(path_nykon + "Retorno.Txt"))
		if (this.Fso.FileExists(path_nykon + "Finalop.Txt"))
		{
  			var arq =  this.Fso.GetFile(path_nykon + "Retorno.Txt");
			var arquivoEnvio = arq.OpenAsTextStream(1);
		
			/*O retorno tem que ser vazio, caso contrario retorno msg de erro.*/
			
			var retErro = arquivoEnvio.ReadAll();
			
			/* Maior que 6 pq o basecom gera espa�os em branco mesmo n�o retornando nenhum erro.*/
			//if (retErro.length > 6)
			
			//**** BUG 0002213 ANDERSON - ALTERA FORMA DE IDENTIFICAR ERRO - 04/10/2006  ****
			if (retErro.toUpperCase().indexOf("ERRO") != -1)
			{
				arquivoEnvio.close();				
				return main('ErroCartao',retErro);
			}
			
			//Gravado Sucesso.
			main("cartaoGravado");
 		}
 		/*O Basecom n�o gerou o arquivo de retorno, isso ocorre pq n�o encontrou o card no leitor.*/
 		else
 		{	
 			if (parseInt(cont_nykon) == 5){
 				cont_nykon = 0;
 				var blConfirm = (msgBox("N�o foi poss�vel ler o cart�o.Verifique se o mesmo encontra - se posicionado no leitor.\nTentar novamente ? ",null,"SIM","NAO") == 0) ? true : false;
				if(blConfirm)
				{
					window.setTimeout("Fu_Ler_RetornoG()",2000);
				}else{
					return false;
				}
			}
			cont_nykon = parseInt(cont_nykon) + 1;
			window.setTimeout("Fu_Ler_RetornoG()",2000);
 		}
 }	
 
 /*function para Leitura quando a opera��o for "Ler_Cart�o".*/
function Fu_Ler_RetornoL()
{		
		this.Fso =  new ActiveXObject("Scripting.FileSystemObject");
		if (this.Fso.FileExists(path_nykon + "Finalop.Txt"))
		{	
  			var arq =  this.Fso.GetFile(path_nykon + "Retorno.Txt");
			var arquivoEnvio = arq.OpenAsTextStream(1);
		
			/*O retorno tem que ser vazio, caso contrario retorno msg de erro.*/
			
			var retErro = arquivoEnvio.ReadLine();
			
			if (retErro == "PDErro - N�o foi poss�vel ler o Cart�o")
			{
				arquivoEnvio.close();
				var blConfirm = (msgBox("N�o foi poss�vel ler o cart�o.Verifique se o mesmo encontra - se posicionado no leitor.\nTentar novamente ? ",null,"SIM","NAO") == 0) ? true : false;
				
				if(blConfirm)
				{	
					main("callBaseComAgain");
				} 			
			}
			else//Lido com sucesso.
			{	arquivoEnvio = this.Fso.OpenTextFile(path_nykon + "Retorno.Txt",1,false)			
				
				if(validarLeituraCartao(nrFac,idCliente,idFilialCliente))
				{
					main("cartaoLido",arquivoEnvio.ReadAll());	
					arquivoEnvio.close();
				}
			}
 		 }
 	   else
 	   {
 		window.setTimeout("Fu_Ler_RetornoL()",2000);
 	   }
 }	
 
 
 function  validarLeituraCartao(nrFac,idCliente,idFilCliente)
 {
				
		if (this.Fso.FileExists(path_nykon + "Retorno.Txt"))
		{
  			var arq =  this.Fso.GetFile(path_nykon + "Retorno.Txt");
			var arquivoEnvio = arq.OpenAsTextStream(1);
			var infoPedClie  = arquivoEnvio.ReadLine();
			/*
			  ##################################
			  #	INFORMA��ES GRAVADAS NO CART�O #
			  ##################################
			*/
			var cFac	 = infoPedClie.substr(2,5);
			var cIdClie  = infoPedClie.substr(7,7);
			var cIdFil   = infoPedClie.substr(14,3);
			var cDsClie  = infoPedClie.substr(18,8);
			var cPlaca   = infoPedClie.substr(25,7);
					
			if ((idCliente != cIdClie) || (idFilCliente != cIdFil))
			{
				msgBox("CART�O INCORRETO:\n - Cliente =  " + cDsClie);
				return false;
			}
			
			
			if ((nrFac != cFac)|| (placa != cPlaca))
			{
				msgBox("CART�O INCORRETO:\n - FAC = " + cFac + "\n - Placa =  " + cPlaca);
				return false;
			}
		}
		else
		{	window.setTimeout("Fu_Ler_RetornoL()",2000);
		}
	return true;		
 }

  
 
function Fu_MskZ(vlField,lenMask)
{	
	var str_base = "";	
	
	switch(lenMask)
	{
		case "1":
			str_base = "0";
			break;
		case "2":
			str_base = "00";
			break;
		case "3":
			str_base = "000";
			break;
		case "4":
			str_base = "0000";
			break;
		case "5":
			str_base = "00000";
			break;
		case "6":
			str_base = "000000";
			break;
		case "7":
			str_base = "0000000";
			break;
	
	}
	
	if(vlField.length <= str_base.length)
	    return  str_base.slice(0, (str_base.length - vlField.length)) + vlField;
	else
	    return  vlField.substr(vlField.length - str_base.length, vlField.length);
} 

function callBaseCom(appName)
{
     try
     {	
	  	var  WshShell = new ActiveXObject("WScript.Shell");
		//msgBox("FUNCTION:callBaseCom(app) SKIPPED \nTODO: Quando for para produ��o remover o comentario da linha que chama o Basecom.exe");
		WshShell.Run(appName); //TODO Remover qdo for para produ��o.
     }
     catch(excpt){}

}



function retornoToArray()
{
	var fs = new ActiveXObject("Scripting.FileSystemObject");
	var  f = fs.OpenTextFile(path_nykon + "Retorno.Txt",1)
	var arr = new Array(20);
	var count = -2;

	while (f.AtEndOfStream == false)
	{
		count ++;
		arr[count] = f.ReadLine();
	}
	f.close();
	return arr;
}











