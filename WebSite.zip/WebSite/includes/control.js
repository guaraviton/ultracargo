//****************************************
//Vari�veis de Sess�o
//****************************************
var sLoginAtu = null;
var sIdEntidade = null;
var sIdFilial = null;
var sDsUsuario = null;
var sDsLogin = null;
var sInCategoria = null;
var sInPortaria = null;
var sInLeitoraCartao = null;
var sInPesagemIndependente = null;
//****************************************
//Vari�veis de Controle de Mensagem.
//****************************************
var sCodMensagem_ultm   = null    // C�digo		da ultima mensagem, da fun��o que exibe mensagem.
var sDesMensagem_ultm   = null    // Descri��o	da ultima mensagem, da fun��o que exibe mensagem.
//////////////////////////////////////////INICIO DE DEFINI��O DE M�TODOS////////////////////////////////////
function retUltmMensagem(paTipo)
{
	//***********************************************************
	// Programador:
	// Marco Sotto (28/06/2005)
	//-----------------------------------------------------------
	// Defini��o
	// Retorna o C�digo ou Descri��o da ultima chamada da fun��o
	// exibirMensagem();
	//-----------------------------------------------------------
	// Par�metros:
	// 1-)	paTipo:
	//		paTipo = 1 => Retorna o C�digo da Mensagem.
	//		paTipo = 2 => Retorna a Descri��o da Mensagem.
	//-----------------------------------------------------------
	// Retornos:
	// C�digo da Mensagem.
	// Descri��o da Mensagem.
	switch(parseInt(paTipo)) 
	{
		case 1:  
			return  sCodMensagem_ultm; 
			break;  
		case 2:
			return  sDesMensagem_ultm;
			break;
		default: 
			alert('[DESENVOLVEDOR] Tipo informado deve ser 1 ou 2.');
			return null; 
			break;  
	}
	sCodMensagem_ultm  = null; 
	sDesMensagem_ultm  = null; 
}
function limUltmMensagem()
{
	sCodMensagem_ultm  = null;
	sDesMensagem_ultm  = null;
}
function abrePopUp(paPagPop,paXML,paWidth,paHeight,paScroll)
{
	//*******************************************
	// Defini��o de vari�veis.
	//*******************************************
	var vwUrl			= null;
	var vwRespPopUp		= null;
	//*******************************************
	// Valida os par�metros principais.
	//*******************************************
	if(paPagPop == '' || paPagPop  ==  null)
	{
		alert('[Ao Desenvolvedor] P�gina para abertura do POP-UP n�o informada.');
		return '';
	}
	paWidth  =  (paWidth	!= null) ? paWidth:655;
	paHeight =  (paHeight	!= null) ? paHeight:385;
	paScroll =  (paScroll !=null) ? (paScroll == true) ? "yes":"no":"yes";
	paXML    =  (paXML == null) ? '' : paXML; 
	//*******************************************
	// Monta URL B�sica.
	//*******************************************
	vwUrl = self.location.toString().substring(0,(self.location.toString().lastIndexOf("/") + 1));
	//*******************************************
	// Chama o Pop-UP. 
	//*******************************************
	var vwXML  = new Array();
	vwXML[0] = paXML;

	vwRespPopUp = showModalDialog(vwUrl + paPagPop ,vwXML,"center=yes;dialogWidth=" + paWidth + "px;dialogHeight=" + paHeight + "px;status=no;scroll=" + paScroll);
	if(vwRespPopUp == null  || vwRespPopUp  == undefined)
	{
		vwRespPopUp = '';
	}
	return vwRespPopUp;
}


function startSession() 
{
	var vwObjHttpSS		= new ActiveXObject("Microsoft.XMLHTTP");
	var vwobjXmlSS		= new ActiveXObject("MSXML2.DOMDocument");
	var vwRespSS		= null; 
	var vwPathPrc		= parent.top.location.toString();
	var vwasHost = vwPathPrc.split("//");
	
	vwPathPrc  = (vwasHost[0] + "//");
	vwasHost = vwasHost[1].split("/");
	for (var iH = 0; iH < 2; iH++) 
	{
		vwPathPrc += (vwasHost[iH] + "/");
	}
	vwPathPrc = vwPathPrc.substring(0,(vwPathPrc.length - 1));
	
	vwObjHttpSS.open("POST",vwPathPrc + '/prc/prc_ultracargoSession.asp', false);
	vwObjHttpSS.send('');
	while(vwObjHttpSS.readyState != 4)
	{
		continue;
	}
	vwRespSS  = vwObjHttpSS.responseText;
	vwobjXmlSS.loadXML(vwRespSS)
	if(! TrataErroXML(vwobjXmlSS,'startSession'))
	{
		return false;
	}
	sLoginAtu = vwobjXmlSS.selectSingleNode("//loginatu").getAttribute("value");
	sIdEntidade = vwobjXmlSS.selectSingleNode("//loginentidade").getAttribute("value");
	sIdFilial = vwobjXmlSS.selectSingleNode("//loginfilial").getAttribute("value");		
	sDsUsuario = vwobjXmlSS.selectSingleNode("//dsusuario").getAttribute("value");
	sDsLogin = vwobjXmlSS.selectSingleNode("//dslogin").getAttribute("value");
	sInCategoria = vwobjXmlSS.selectSingleNode("//incategoria").getAttribute("value");
	sInPortaria = vwobjXmlSS.selectSingleNode("//inportaria").getAttribute("value");
	sInLeitoraCartao = vwobjXmlSS.selectSingleNode("//inleitoracartao").getAttribute("value");
	sInPesagemIndependente = vwobjXmlSS.selectSingleNode("//inpesagemindependente").getAttribute("value");
}


function validarObrigatorios(paForm, paOperacao)
{
	//***********************************************************
	// Programador:
	// Marco Sotto (20/06/2005)
	//-----------------------------------------------------------
	// Defini��o:
	// Valida os objetos que possuam o atributo label e que
	// possuam os seus valores igual a nada, exigindo o seu
	// preenchimento obrigat�rio.
	//-----------------------------------------------------------
	// Par�metros:
	// 1-)	paForm= Nome do formul�rio no qual os objetos
	//		ser�o validados, se n�o informado, a valida��o
	//		ser� realizada em todos os forms do documento.
	// 2-)	paOperacao=  Opera��o que ser� v�lidada, se n�o 
	//		informado, a opera��o todos objetos n�o ser� 
	//		considerada.
	//-----------------------------------------------------------
	// Retorno:
	// True:  Valida��o ok, mensagem n�o ser� mostrada.
	// False: Valida��o nok, mensagem ser� mostrada.
	//***********************************************************
	//Defini��o de vari�veis e objetos deste escopo
	//***********************************************************
	var vwObjsForm		= null;
	var vwBoolAux		= null;
	var vwObjsElem		= null;
	var vwCamposObrg    = '';
	var vwOperacoes		= '';
	vwObjsForm  = document.getElementsByTagName("FORM");
	if(vwObjsForm != null)
	{
		for(var vwi=0;vwi<=vwObjsForm.length-1;vwi++)
		{
			vwBoolAux  = false;
			if(paForm == '' || paForm == null)
			{
				vwBoolAux  = true;
			}
			else
			{
				if(paForm == vwObjsForm[vwi].id)
				{
					vwBoolAux  = true;
				}
			}
			if(vwBoolAux ==  true)
			{
				vwObjsElem  = vwObjsForm[vwi].elements;
				for(var vwb=0;vwb<=vwObjsElem.length-1;vwb++)
				{
					if(vwObjsElem[vwb].lbl != undefined)
					{
						if(vwObjsElem[vwb].lbl != ''  && vwObjsElem[vwb].lbl != null)
						{
							vwBoolAux  = false;
							if(paOperacao == '' || paOperacao == null)
							{
								vwBoolAux  =  true;
							}
							else
							{
								if (vwObjsElem[vwb].operation  != undefined)
								{
									vwOperacoes  =   vwObjsElem[vwb].operation.split(',');
									for(var vwi = 0 ;vwi<=vwOperacoes.length-1;vwi++)
									{
										if(vwOperacoes[vwi] ==  paOperacao)
										{
											vwBoolAux  =  true;
											vwi  = vwOperacoes.length+1;
										}
									}
								} 
								else
								{
									vwBoolAux  =  true;
								}  
							}
							
							if(vwBoolAux == true && vwObjsElem[vwb].value == '')
							{
								vwCamposObrg  += vwObjsElem[vwb].lbl + ',\n'
							}
							
						} 
					}
				}
				vwCamposObrg  =  vwCamposObrg.substr(0,vwCamposObrg.length-2);
			}
		}
	}
	//******************************************
	//Exibe a mensagem.  
	//******************************************
	if(vwCamposObrg != '')
	{
		msgBoxG(" - Necess�rio informar os seguintes campos:\n" + vwCamposObrg);
		return false;
	}
	return true;
}  

function obterXML(paForm,paOperacao,paTipoXML)
{
	//***********************************************************
	// Programador: 
	// Marco Sotto (09/06/2005)
	//-----------------------------------------------------------
	// Defini��o:
	// Retorna string XML com os objetos da p�gina que
	// perten�am ao formul�rio(paForm)
	// e possuam o atributo operation(paOperacao)
	//-----------------------------------------------------------
	// Par�metros: 
	// 1-) paForm= Cria XML dos objetos que pertencam
	// ao form informado, caso contr�rio, retorna
	// objetos de todos os forms.
	// 2-) paOperacao= Cria XML dos objetos que pertencam
	// a opera��o informada, caso contr�rio, retorna 
	// todos os objetos independente da opera��o.
	// 3-) paTipoXML = Define qual o tipo de XML de retorno
	// ser� montado pelo VB.  
	//      3.1-) Form
	//      3.2-) Table
	//-----------------------------------------------------------
	// Retorno:
	// Retorna uma string XML.
	//***********************************************************
	//Defini��o de vari�veis e objetos deste escopo
	//***********************************************************
	var vwobjXml		= new ActiveXObject("MSXML2.DOMDocument");
	var vwNodeAux		= null;
	var vwBooAux		= null;
	var vwNodeNew		= null;
	var vwObjsForm		= null;
	var vwobjEle		= null;
	var vwi				= null;
	var vwj				= null; 
	var vwTipoXML		= null;
	var vwOperacoes		= null;
	//******************************************
	//Prepara abertura do obj XML
	//******************************************
	vwobjXml.loadXML('<root></root>')
	vwObjsForm  = document.getElementsByTagName("FORM");
	if(vwObjsForm != null)
	{
		if(paTipoXML == null || paTipoXML == '')
		{
			vwTipoXML  =  'form';
		}
		else
		{
			vwTipoXML  = paTipoXML;  
			if(paTipoXML != 'table' && paTipoXML != 'form')
			{
				alert('Tipo de XML retorno informado � inv�lido: table|form.')
				return ''; 
			} 
		}  
	
	
		if(vwObjsForm.length > 0)
		{
			for(vwi=0;vwi<=vwObjsForm.length-1;vwi++)
			{
				vwBooAux = false;
				if(paForm == null || paForm == '')
				{
					vwBooAux  = true;
				}
				else
				{
					if(vwObjsForm[vwi].id == paForm)
					{
						vwBooAux =  true;
					}
				}
				if(vwBooAux == true)
				{
					vwNodeAux  = vwobjXml.selectSingleNode('root');
					//***********************************************
					//Para cada formul�rio encontrado, Cria um Node
					//do tipo formul�rio.
					//***********************************************
					vwNodeNew  =  vwobjXml.createNode(1,vwObjsForm[vwi].id,"");
					//Atributos
					vwNodeNew.setAttribute('tipo',vwTipoXML);
					vwNodeAux.appendChild(vwNodeNew);
					//***********************************************
					//Para cada item/objeto encontrado no form,  
					//cria um node.
					//***********************************************
					vwobjEle  =  vwObjsForm[vwi].elements;
					if(vwobjEle!= null )
					{
						if(vwobjEle.length >0)
						{
							for(vwj=0;vwj<=vwobjEle.length-1;vwj++)
							{
								vwBooAux   = false;
								if(paOperacao == null || paOperacao == '')
								{
									vwBooAux   = true; 
								}
								else
								{
									if(vwobjEle[vwj].operation != undefined)
									{
										vwOperacoes  = vwobjEle[vwj].operation.split(',');
										for(var vwv=0;vwv<=vwOperacoes.length-1;vwv++)
										{
											if(vwOperacoes[vwv]  == paOperacao)
											{
												vwBooAux = true;
												vwv  =  vwOperacoes.length + 1;
											}
										}
									} 
								}
								if(vwBooAux == true)
								{
									vwNodeAux  = vwobjXml.selectSingleNode('root/' + vwObjsForm[vwi].id);
									vwNodeNew  =  vwobjXml.createNode(1,vwobjEle[vwj].id,"");
									vwNodeNew.setAttribute('value',escape(vwobjEle[vwj].value));
									vwNodeNew.setAttribute('server_value',escape(vwobjEle[vwj].value));
									vwNodeAux.appendChild(vwNodeNew)
								}
							}
						}
					}
				}
			}
		}
	}
	//******************************************
	//  Retorna uma String XML 
	//******************************************
	return  vwobjXml.xml;
	//******************************************
	//  Elimina as vari�veis e objetos
	//******************************************
	vwobjXml	= null;
	vwNodeAux	= null;
	vwBooAux	= null;
	vwNodeNew   = null;
	vwObjsForm	= null;
	vwobjEle	= null;
	vwi			= null;
	vwj			= null;
	
}

function carregarFormulario(paStringXML,paForm,paPathXML)
{
	//*********************************************************************
	// Programador: 
	// Marco Sotto (09/06/2005)
	//-------------------------------------------------
	// Defini��o:
	// Popula os objetos do formul�rio(paForm) 
	// com os valores do xml, nos objetos 
	// que possuam o id com valor igual ao nome  
	// do node do xml.
	//-------------------------------------------------
	// Par�metros: 
	// 1-) paStringXML=  String que ser�
	// utilizada para abrir o XML  que 
	// vai popular os objetos do form informado. 
	// 2-) paOperacao= Nome do form que ter� os 
	// objetos populados
	//-------------------------------------------------
	// Retorno: 
	// true		= Nenhum problema encontrado ao carregar formul�rio.
	// false	= Problema encontrado ao carregar formul�rio.
	//*********************************************************************
	//Defini��o de vari�veis e objetos deste escopo.
	//*********************************************************************
	var vwobjXmlAux			= new ActiveXObject("MSXML2.DOMDocument");
	var vwObjsForm			= null;
	var vwObjEle			= null;
	var vwNodeForm			= null;
	var vwNodes				= null;
	var vwValorNode			= null;
	var vwNodeName			= null;
	var vwi					= null;
	var vwj					= null;
	var vwk					= null;
	var vwTipoObjeto		= null;
	var vwPathXML			= null;
	var vwNomeObjeto		= null;
	//************************************************
	//Verifica se a string XML foi informada.
	//************************************************
	if(paStringXML == '' || paStringXML == null)
	{
		return;
	}
	//************************************************
	//Carrega o Form.
	//************************************************
	vwObjsForm  = document.getElementById(paForm);
	if(vwObjsForm == null)
	{
		alert('Formul�rio informado n�o foi encontrado!');
		return false;
	}
	//************************************************
	//Valida e Monta o Caminho do XML. 
	//************************************************
	vwPathXML  =  'root/'+ paForm;
	if(paPathXML != '' && paPathXML != null)
	{
		vwPathXML  = paPathXML; 
	}
	//************************************************
	//Seleciona os elementos do objeto form criado.
	//************************************************
	vwObjEle  =  vwObjsForm.elements;
	//************************************************
	//Abre o XML informado e v�lida o mesmo.
	//************************************************
	vwobjXmlAux.loadXML(paStringXML);
	if(! TrataErroXML(vwobjXmlAux,'carregarFormul�rio'))
	{
		return false;
	}
	vwNodeForm  = vwobjXmlAux.selectSingleNode(vwPathXML);
	if(vwNodeForm != null)
	{
		vwNodes =     vwNodeForm.selectNodes('*');
		if(vwNodes != null)
		{
			for(vwi=0;vwi<=vwNodes.length-1;vwi++)
			{
				vwNodeName			= vwNodes[vwi].nodeName;
				vwValorNode			= vwNodes[vwi].getAttribute('value');
				if(vwValorNode == null)
				{
					vwValorNode = '';
				}
				vwValorNode  = unescape(vwValorNode);
				//*******************************************
				//Procura no array de objetos pelo objeto
				//que possua o id com o mesmo node name
				//*******************************************
				if(vwObjEle != null)
				{
					for(vwj=0;vwj<=vwObjEle.length-1;vwj++)
					{
						if(vwObjEle[vwj].alias != undefined)
						{
							vwNomeObjeto    =  vwObjEle[vwj].alias;
						}
						else
						{
							vwNomeObjeto    =  vwObjEle[vwj].id;
						}
					
						if(vwNomeObjeto == vwNodeName)
						{
							vwTipoObjeto  = vwObjEle[vwj].type;
							vwTipoObjeto  = vwTipoObjeto.toLowerCase();
							
							switch(vwTipoObjeto)
							{
								case 'text':
								case 'hidden':
								case 'textarea':
									vwObjEle[vwj].value  = vwValorNode;
									break;
								case 'select-one':
								case 'select-multiple':
									for(var vwk=0;vwk<=vwObjEle[vwj].length-1;vwk++)
									{
										if(vwObjEle[vwj][vwk].value == vwValorNode)
										{
											vwObjEle[vwj].selectedIndex		= vwk;
											vwk  = vwObjEle[vwj].length		+  1;
										}
									}
									break;
								case 'checkbox':
									vwObjEle[vwj].checked = false
									if(vwValorNode == 'S')
									{
										vwObjEle[vwj].checked  = true;
									}
									vwObjEle[vwj].value  = vwValorNode;
									break;
								case 'radio':
									vwObjEle[vwj].checked = false
									if(vwValorNode == 'S')
									{
										vwObjEle[vwj].checked  = true;
									}
									vwObjEle[vwj].value  = vwValorNode;
									break;	
							}
						}
					}
				}
			}
		}
	}
	//******************************************
	//  Elimina as vari�veis e objetos
	//******************************************
	vwobjXmlAux			= null;
	vwObjsForm			= null;
	vwObjEle			= null;
	vwNodeForm			= null;
	vwNodes				= null;
	vwValorNode			= null;
	vwNodeName			= null;
	vwi					= null;
	vwj					= null;
	vwk					= null;
	vwTipoObjeto		= null;
	//************************************
	// Processamento ok...retorna true
	//************************************
	return true;
}
function carregarCampo(paStringXML,paNode,paCampo,paPathXML)
{
	//****************************************************************
	// Programador:
	// Marco Sotto (10/06/2005)
	//-------------------------------------------------
	// Defini��o:
	// Popula o campo do formul�rio com o valor do 
	// node (paNode) do xml.  
	//--------------------------------------------------
	// Par�metros: 
	// 1-) paStringXML=  String que ser� utilizada para abrir 
	// o XML  que  vai popular o campo informado.
	// 2-) paNode= Nome do N� que dever� popular o campo.  
	// paCampo=Objeto que ter� sua propriedade 
	// value preenchida.
	// 3-) paPathXML= Caso este par�metro seja informado
	// a sele��o dos nodes ser� realizada a partir  
	// deste par�metro, caso contr�rio, pegar� do
	// root padr�o
	//-------------------------------------------------
	// Retorno: 
	// true		= Nenhum problema encontrado ao carregar formul�rio.
	// false	= Problema encontrado ao carregar formul�rio.
	//****************************************************************
	//
	//Defini��o de vari�veis e objetos deste escopo
	var vwobjXmlCC			= new ActiveXObject("MSXML2.DOMDocument");
	var vwNode				= null;
	var vwPathXML			= null;
	var vwValorNode			= null;
	//************************************************
	// Abre e v�lida XML informado. 
	//************************************************
	vwobjXmlCC.loadXML(paStringXML);
	if(! TrataErroXML(vwobjXmlCC,'carregarCampo'))
	{
		return  false; 	
	}
	//************************************************
	// Monta path padr�o. 
	//************************************************
	vwPathXML = 'root/*/'  + paNode;
	if(paPathXML != null && paPathXML != '')
	{
		vwPathXML  =  paPathXML  + paNode;
	}
	//************************************************
	// Seleciona o node a partir de do path montado
	// anteriormente.
	//************************************************
	
	vwNode  = vwobjXmlCC.selectSingleNode(vwPathXML);
	if(vwNode != null)
	{
		vwValorNode =  vwNode.getAttribute('value');
		if(paCampo != undefined && paCampo != null)
		{
			paCampo.value  = '';
			if(vwValorNode != null)
			{
				paCampo.value   =  vwValorNode;
			}
		} 	
	}
	//******************************************
	//  Elimina as vari�veis e objetos
	//******************************************
	vwobjXmlCC			= null;
	vwNode				= null;
	vwPathXML			= null;
	vwValorNode			= null;
	//******************************************
	// Processamento ok...retorna true
	//******************************************
	return true;
}
function TrataErroXML(paObjXML,paFuChamadora)
{
	//*****************************************************************
	// Programador: 
	// Marco Sotto (10/06/2005)
	//-----------------------------------------------------------------
	// Defini��o: 
	// Trata erro de objetos do tipo XML, mostrando 
	// uma mensagem pr�-definida(padr�o) para este tipo 
	// de objeto.
	//-----------------------------------------------------------------
	// Par�metros:
	// 1-) paObjXML		 = Objeto XML que ser� analisado.
	// 2-) paFuChamadora = Nome da  fun��o onde o Objeto foi criado
	//-----------------------------------------------------------------
	// Retornos:
	// true		= Nenhum problema no objeto xml informado.
	// false	= Problemas ao validar objeto XML, mensagem ser� 
	// exibida  para o programador.
	//-----------------------------------------------------------------
	// Obs.:
	// Est� mensagem � exibida para an�lise do 
	// programador, sendo que a vers�o liberada 
	// para o cliente, n�o poder� chamar esta fun��o, j� que ser� 
	// caracterizado um erro do programador. 
	//*****************************************************************
	if(paObjXML.parseError != 0)
	{
		var vwMensagem  = 'N�mero do Erro XML:' +  paObjXML.parseError + '\n';
			vwMensagem += 'Descri��o do erro :' +  paObjXML.parseError.reason + '\n';
			vwMensagem += 'Fun��o Chamadora:'   +  paFuChamadora;
			alert(vwMensagem);
		return false;
	}
	return true;
}

function prepTipoObjetos()
{
	var vwObjsForm			= null;
	var vwObjEle			= null;
	var vwi					= null;
	var vwk					= null;
	var vwTipo				= null;
	var vwSubTipo			= null;
	var vwElemento			= null;
	var vwPos1				= null;
	var vwPos2				= null;
	var vwParaTipo			= null;
	var vwsBlur				= null;

	vwObjsForm  = document.getElementsByTagName("FORM");
	if(vwObjsForm != null)
	{ 
		for(vwi = 0;vwi<= vwObjsForm.length -1;vwi++)
		{
			vwObjEle  =  vwObjsForm[vwi].elements;
			if(vwObjEle != null)
			{
				for(vwk = 0;vwk <= vwObjEle.length -1;vwk++)
				{
					vwTipo  = vwObjEle[vwk].tipo;
					vwElemento  = vwObjEle[vwk]
					if(vwTipo != undefined)
					{
						vwSubTipo  = vwTipo.substr(0,3);
						vwPos1   = vwTipo.indexOf('(');
						vwPos2   = vwTipo.indexOf(')');
						vwPos2  = vwPos2 - vwPos1 
						vwParaTipo  = vwTipo.substr(vwPos1 +1 ,vwPos2-1)
						//**************************************************
						//Realiza chamada adicionais ao evento onblur. 
						//**************************************************
						vwsBlur = null;  
						if(vwElemento.sonblur != undefined )
						{
							vwsBlur  =  vwElemento.sonblur;
						}
						switch(vwSubTipo.toLowerCase()) 
						{
							case "str":
								vwElemento.maxlength  =  Math.floor(vwParaTipo);
								vwElemento.onkeypress =  new Function("digitarUpper(this)");
								break;
							case "dec":
								//Pega os Par�mentros necess�rios
								var vwNrInteiros	= vwParaTipo.split(",")[0]; 
								var vwNrDecimais	= vwParaTipo.split(",")[1]; 
								var vwSepDec		= vwParaTipo.split(",")[2];
								if(vwSepDec == 'p' || vwSepDec == 'P')
								{
									vwSepDec = '.';
								}
								else
								{
										vwSepDec = ',';
								}
								vwElemento.onkeypress	= new Function("return maskDec_Type(event,this,"  + vwNrInteiros +  "," + vwNrDecimais + ",'" + vwSepDec + "'" + ")");
								vwElemento.onblur		= new Function("maskDec_TypeBlur(this,"  + vwNrInteiros +  "," + vwNrDecimais + ",'" + vwSepDec + "'" + ")");
								vwElemento.onkeyup		= new Function("maskDec_TypeKeyUp(this,"  + vwNrInteiros +  "," + vwNrDecimais + ",'" + vwSepDec + "'" + ")");
								break; 
							case "dat":
								
								vwElemento.onkeypress	= new Function("return Fu_DigData_keypress(this);");
								vwElemento.onblur		= new Function("Fu_ValidaData_blur(this);");
								//vwElemento.onkeyup		= new Function("Fu_FormataData_keyup(this);");
								vwElemento.maxLength	= 10;
								break;
							case "tim":
								vwElemento.onkeypress = new Function("return maskHour_Type(event,this);");
								vwElemento.onblur = new Function("maskHour(this);");
								vwElemento.maxLength = 5;
								break;
							case "int":
								var vwNrInteiros	= vwParaTipo.split(",")[0];
								var vwNrDecimais	= 0
								var vwSepDec   =  ','
								vwElemento.onkeypress = new Function("onlyNumeric(this,"  + vwNrInteiros +  "," + vwNrDecimais + ",'" + vwSepDec + "'" + ")");
								vwElemento.maxLength = vwNrInteiros; 
								break;
							case "lng":
								var vwNrInteiros	= vwParaTipo.split(",")[0];
								var vwNrDecimais	= vwParaTipo.split(",")[1];
								var vwSepDec		=  ',';
								
								vwElemento.onkeypress = new Function("return maskDec_Type_lng(event,this,"  + vwNrInteiros +  "," + vwNrDecimais + ",'" + vwSepDec + "'" + ")");
								
								if(vwsBlur == ''  || vwsBlur == null)
								{
									vwElemento.onblur = new Function("maskDec_TypeBlur_lng(this,"  + vwNrInteiros +  "," + vwNrDecimais + ",'" + vwSepDec + "'" + ")");
								}
								else
								{
									vwElemento.onblur = new Function("maskDec_TypeBlur_lng(this,"  + vwNrInteiros +  "," + vwNrDecimais + ",'" + vwSepDec + "'" + ");" + vwsBlur);
								}  
								
								
								
								
								vwElemento.onkeyup = new Function("maskDec_TypeKeyUp_lng(this,"  + vwNrInteiros +  "," + vwNrDecimais + ",'" + vwSepDec + "'" + ")");
								break;
						}
					} 
				}
			}
		}
	}
	//************************************************
	// Elimina as vari�veis e objetos criados
	//************************************************
	vwObjsForm			= null;
	vwObjEle			= null;
	vwi					= null;
	vwk					= null;
	vwTipo				= null;
	vwSubTipo			= null;
	vwElemento			= null;
	vwPos1				= null;
	vwPos2				= null;
	vwParaTipo			= null;
}


function carregarCombo(paStringXML, paObjCombo, paNodeValue,paNodeDescricao,paPathXML)
{
	//**********************************************************************
	// Programador: 
	// Marco Sotto (10/06/2005)
	//---------------------------------------------------------------------
	// Defini��o: 
	// Popula o combo do formul�rio com os valores do paNodeValue e 
	// paNodeDescricao do XML.
	//---------------------------------------------------------------------
	// Par�metros:
	//1-)paStringXML	= String que ser� utilizada para carregar o combo. 
	//2-)paObjCombo		= Objeto como que ser� populado.
	//3-)paNodeValue	= Propriedade value do combo.
	//4-)paNodeDescricao= Descritivo do combo.
	//5-)paPathXML		= Caminha alternativo para sele��o dos nodes.
	//---------------------------------------------------------------------
	// Retornos:
	// true		= Nenhum problema
	// false	= Problemas ao carregar objetos
	//**********************************************************************
	var vwobjXmlCB			= new ActiveXObject("MSXML2.DOMDocument");
	var vwNode				= null;
	var vwPath				= null;
	var vwi					= null;
	var vwValorDesc			= null;
	var vwValorValue		= null;
	var vwsNode				= null;
	
	vwobjXmlCB.loadXML(paStringXML);
	if(! TrataErroXML(vwobjXmlCB,'carregarCombo'))
	{
		return false;
	}
	if(paPathXML != null && paPathXML != '')
	{
		vwPath =  paPathXML;
	}
	else
	{
		vwPath = 'root/*/row';
	}
	//*****************************************
	//Seleciona os n�s a partir do path.
	//*****************************************
	vwNode  =  vwobjXmlCB.selectNodes(vwPath);
	
	if(vwNode != null)
	{
		//****************************************************
		//Limpa e insere uma linha em branco;
		//****************************************************
		paObjCombo.options.length= 0;
		paObjCombo[paObjCombo.length] = new Option("","");
		for(vwi=0;vwi<=vwNode.length-1;vwi++)
		{
			//****************************************************
			//Seleciona o no de valor e valida o mesmo.
			//****************************************************
			vwsNode  = vwNode[vwi].selectSingleNode(paNodeValue);
			vwValorValue  = '';
			if(vwsNode != null)
			{
				vwValorValue  = vwsNode.getAttribute('value');
				if(vwValorValue == null)
				{
					vwValorValue = '';
				} 
			}
			//****************************************************
			//Seleciona o no de descricao e valida o mesmo.
			//****************************************************
			vwsNode  = vwNode[vwi].selectSingleNode(paNodeDescricao);
			vwValorDesc  = '';
			if(vwsNode != null)
			{
				vwValorDesc  = vwsNode.getAttribute('value');
				if(vwValorDesc ==null)
				{
					vwValorDesc = '';
				} 
			}
			//*************************************************
			//Insere os valores retornados nos
			//combos.
			//*************************************************
			paObjCombo[paObjCombo.length] = new Option(unescape(vwValorDesc),unescape(vwValorValue));
		}
	}
	//************************************************
	// Elimina as vari�veis e objetos criados.
	//************************************************
	vwobjXmlCB			= null;
	vwNode				= null;
	vwPath				= null;
	vwi					= null;
	vwValorDesc			= null;
	vwValorValue		= null;
	vwsNode				= null;
	return true;
}

function executar(paStringXML,paOperacao,paPrc)
{
	//**********************************************************************
	// Programador:
	// Marco Sotto (13/06/2005).
	//---------------------------------------------------------------------
	// Defini��o:
	// Realiza chamada a alguma fun��o da prc.
	//---------------------------------------------------------------------
	// Par�metros:
	// 1-)paStringXML	= String que ser� utilizada. 
	// 2-)paOperacao	= Operacao que ser� executada pela PRC. 
	// 3-)paPrc			= Nome da Prc que ser� executada.
	//---------------------------------------------------------------------
	// Retornos:
	// String retornada pela prc.
	//**********************************************************************
	//Defini��o de vari�veis e objetos deste escopo
	//************************************************
	var vwObjHttp		= new ActiveXObject("Microsoft.XMLHTTP");
	var vwobjXmlEX		= new ActiveXObject("MSXML2.DOMDocument");
	var vwRespHttp		= null;
	var vwNodeAux		= null;
	var vwNodeNew		= null;
	
	//************************************************
	//V�lida sess�o do usu�rio 
	//************************************************
	if (sLoginAtu  == '' || sLoginAtu == null)
	{
		msgBoxG("Sua sess�o expirou, por favor realize o Login novamente.")
		return '';
	}
	//************************************************
	//Prepara a StringXML para ser enviada pelo HTTP
	//************************************************
	vwobjXmlEX.loadXML(paStringXML);
	if(! TrataErroXML(vwobjXmlEX,'executar')) 
	{
		return ''; 
	}
	vwNodeAux  = vwobjXmlEX.selectSingleNode('root');
	vwNodeNew  =  vwobjXmlEX.createNode(1,'operation',"");
	vwNodeNew.setAttribute('value',paOperacao);
	vwNodeAux.appendChild(vwNodeNew);
	paStringXML	  =   vwobjXmlEX.xml;

	paStringXML = paStringXML.replace(/%20/g," ");
	//************************************************
	//Envia dados atrav�s do HTTP.
	//************************************************
	vwObjHttp.open("POST",paPrc, false);
	vwObjHttp.send(paStringXML);
	while(vwObjHttp.readyState != 4)
	{
		continue;
	}
	vwRespHttp = vwObjHttp.responseText;
	//************************************************
	// Retorna o o retorno da PRC.
	//************************************************
	return vwRespHttp;
}


function exibirMensagem(paXML,paExibirMensagem)
{
	var vwobjXmlMen			= new ActiveXObject("MSXML2.DOMDocument");
	var vwNode				= null;
	var vwCodigoMensagem	= null;
	
	
	vwobjXmlMen.loadXML(paXML);
	
	if(vwobjXmlMen.parseError  ==0)
	{
		vwNode = vwobjXmlMen.selectSingleNode('root/mensagem');
		if (vwNode == null)
		{
			vwNode = vwobjXmlMen.selectSingleNode('root/system/mensagem');
		}  
		
		if(vwNode != null)
		{
		
			
		
			if(paExibirMensagem == true || paExibirMensagem == null)
			{
				msgBoxG(vwNode.text);
			}
			else
			{
				if(paExibirMensagem == false)
				{
					return true;
				}   
			}  
			vwCodigoMensagem  = vwNode.getAttribute('value');
			sCodMensagem_ultm   = vwNode.getAttribute('value');
			sDesMensagem_ultm   = vwNode.text; 
			
			
			if(vwCodigoMensagem == null || vwCodigoMensagem == '')
			{
				return true;
			}
			else
			{
				//**************************************************
				// Tratamento diferenciado para mensagens classifi-
				// cadas como mensagem de aviso. 
				//**************************************************
				switch(parseInt(vwCodigoMensagem))
				{
					case 1:  //Registro Inserido com Sucesso.
					case 2:  //Registro Alterado com Sucesso.
					case 3:  //Registro Excluido com Sucesso.
					case 4:  //Opera��o realizada com Sucesso.
					case 5:  //Nenhum registro encontrado.
						return false;
						break;
					default:
						return true;
						break;
				}
			}
		}
	}
	return false;
}



function LimparObjForm(paForm)
{
	//**********************************************************************
	// Programador:
	// Marco Sotto (13/06/2005).
	//---------------------------------------------------------------------
	// Defini��o:
	// Limpa objetos de um form informado ou de todos os objetos, caso  
	// o form n�o seja informado 
	//---------------------------------------------------------------------
	// Par�metros:
	// 1-)paForm		= Nome do form que ser� limpo.
	//---------------------------------------------------------------------
	// Retornos:
	// Sem retorno (null)
	//**********************************************************************
	//Defini��o de vari�veis e objetos deste escopo
	//**********************************************************************
	var vwObjsForm			= null;
	var vwObjEle			= null;
	var vwBoolAux			= false;
	var vwTipoObjeto		= '';
	
	
	vwObjsForm  = document.getElementsByTagName("FORM");
	if (vwObjsForm == null)
	{
		alert('[Mensagem ao Desenvolvedor]Nenhum objeto do tipo Form foi encontrado neste documento.');
		return; 
	}
	
	
	for(var vwi=0;vwi<=vwObjsForm.length-1;vwi++)
	{
		vwBoolAux  = false;
		if(paForm == '' || paForm == null)
		{
			vwBoolAux  = true;
		}
		else
		{
			if(paForm == vwObjsForm[vwi].id)
			{
				vwBoolAux  = true;
			}
		}
		
		if(vwBoolAux == true)
		{
			vwObjEle   =   vwObjsForm[vwi].elements;
			
			for(var vwj=0;vwj<=vwObjEle.length-1;vwj++)
			{ 
				vwTipoObjeto  = vwObjEle[vwj].type;
				vwTipoObjeto  = vwTipoObjeto.toLowerCase();
				switch(vwTipoObjeto)
				{
					case 'text':
					case 'hidden':
					case 'textarea':
						vwObjEle[vwj].value  = '';
						break;
					case 'select-one':
					case 'select-multiple':
						vwObjEle[vwj].selectedIndex		= 0;
						break;
					case 'checkbox':
						vwObjEle[vwj].checked = false;
						vwObjEle[vwj].value  = '';
						break;
					case 'radio':
						vwObjEle[vwj].checked = false;
						vwObjEle[vwj].value  = '';
						break;
				}
			}
		}
	}
}
