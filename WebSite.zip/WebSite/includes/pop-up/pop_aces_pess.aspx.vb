#Region "Imports"
Imports SAM.AE.Presentacion.Comun
Imports System.Data
Imports Utilidades
Imports Utilidades.Funcoes
Imports wbIntegra
Imports Utilidades.Constantes
Imports System.Web.Services.Protocols
#End Region

Partial Class pop_aces_pess
    Inherits Controles.PageBaseIntegra

#Region "Eventos da p�gina"
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        AjaxPro.Utility.RegisterTypeForAjax(GetType(pop_aces_pess))
    End Sub
#End Region

#Region "M�todos AJAX"
    <AjaxPro.AjaxMethod()> _
    Public Function obter_PessoaFiltro(ByVal strP As String) As String

        'Instancia os objetos de acesso da fun��o
        Dim objWS As New WebService.Portaria.clsWSPortaria
        Dim objDS As New DataSet
        Dim strReturn As String
        Dim intCont As Integer

        Try

            'chama o m�todo do web service
            objDS = objWS.obter_pessoaFiltro(strP)

            'Reordena os elementos a serem exibidos no grid
            objDS.Tables(0).Columns("PIN").SetOrdinal(0)
            objDS.Tables(0).Columns("NOME").SetOrdinal(1)
            objDS.Tables(0).Columns("CATEGORIA").SetOrdinal(2)
            objDS.Tables(0).Columns.Add("INDICELINHA")

            intCont = 0
            For Each objRow As DataRow In objDS.Tables(0).Rows
                objRow(objDS.Tables(0).Columns.Count - 1) = intCont
                intCont += 1
            Next

            strReturn = Funcoes.Gerais.convertDStoAJAX(0, objDS)

        Catch ex As Exception
            Throw New RegraApresentacaoException(Configuracoes.APLICACAO, Erros.M4, ex)
        Finally
            'Desistancia os Objetos.
            objWS.Dispose()
            strP = ""
        End Try

        'converte o DataSet para uma string XML e o usa como retorno da fun��o
        Return strReturn

    End Function

#End Region

End Class