#Region "Imports"

Imports SAM.AE.Presentacion.Comun
Imports System.Data
Imports CrystalDecisions.Shared
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.ReportSource
Imports CrystalDecisions.Web.Services
Imports Utilidades.Funcoes
Imports System.IO

#End Region

Partial Class includes_pop_up_pop_imprimir_viewer
    Inherits Controles.PageBaseIntegra

    Protected paperOrientation As String = "1"
    Protected paperSize As String = "1"
    Protected objRelatorioDS As ReportDocument

    Public Sub New()
        AddHandler Me.Unload, AddressOf PageUnload
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim strReportFileName As String = ""
        Try
            Dim strDadosImpressao() As String = Page.Session("dadosImpressao")
            Dim dsDocumento As New DataSet
            Dim objLeitor As New IO.StringReader(strDadosImpressao(0))
            Dim strReportPath As String = Request.MapPath("~/" & strDadosImpressao(1))
            Dim objRelatorio As New ReportDocument
            objRelatorioDS = New ReportDocument
            Dim intCont As Integer

            strReportFileName = ConfigurationManager.AppSettings("DirGeracaoArquivos")
            strReportFileName = strReportFileName & "\" & GetNewFileName(strReportPath)
            strReportFileName = strReportFileName.Replace("\\", "\")

            Try
                Dim strFiles As String() = Directory.GetFiles(ConfigurationManager.AppSettings("DirGeracaoArquivos"), "*_??????????????_*.rpt")
                For Each strFile As String In strFiles
                    If File.GetCreationTime(strFile) <= Date.Now.AddMinutes(-15) Then
                        Try
                            File.Delete(strFile)
                        Catch
                        End Try
                    End If
                Next
            Catch
            End Try

            dsDocumento.ReadXml(objLeitor)

            objRelatorio.Load(strReportPath)
            objRelatorio.SetDataSource(dsDocumento)
            paperOrientation = objRelatorio.PrintOptions.PaperOrientation & ""
            paperSize = objRelatorio.PrintOptions.PaperSize & ""

            If (strDadosImpressao.Length > 2) Then
                For intCont = 2 To strDadosImpressao.Length - 1
                    If (strDadosImpressao(intCont).Split(",")(0).Length > 0) Then
                        objRelatorio.DataDefinition.FormulaFields(strDadosImpressao(intCont).Split(",")(0)).Text = strDadosImpressao(intCont).Split(",")(1)
                    Else
                        objRelatorio.DataDefinition.FormulaFields(strDadosImpressao(intCont).Split(",")(0)).Text = "'B'"
                    End If
                Next
            End If

            'objRelatorio.SaveAs(strReportFileName, True)
            objRelatorio.ExportToDisk(ExportFormatType.CrystalReport, strReportFileName)
            objRelatorio.Dispose()

            objRelatorioDS.Load(strReportFileName, OpenReportMethod.OpenReportByDefault)

            CRV.ReportSource = objRelatorioDS
        Catch ex As Exception
            Dim exLog As New RegraApresentacaoException(ex.Message, ex)
            Response.Write("<script>window.returnValue = false;window.close();</script>")
        End Try
    End Sub

    Public Function GetNewFileName(ByVal strFileName As String) As String
        Return Path.GetFileNameWithoutExtension(strFileName) & "_" & Date.Now.ToString("yyyyMMddHHmmss") & "_" & Session.SessionID & Path.GetExtension(strFileName)
    End Function

    Protected Sub PageUnload(ByVal sender As Object, ByVal e As EventArgs)
        Try
            If objRelatorioDS IsNot Nothing Then
                objRelatorioDS.Close()
                objRelatorioDS.Dispose()
            End If
            CRV.Dispose()
        Catch ex As Exception
        End Try
    End Sub
End Class