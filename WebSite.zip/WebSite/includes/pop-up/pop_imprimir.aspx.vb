Imports SAM.AE.Presentacion.Comun

Partial Class pop_imprimir
    Inherits Controles.PageBaseIntegra

    Protected Sub btnImprimir_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnImprimir.Click
        Dim str As String = txhXML.Text
        Dim strDadosImpressao() As String
        Dim intCont as Integer

        str = str.Replace("@#$%", "<")

        If txhFRML.Text.Length > 0 Then
            ReDim strDadosImpressao(2 + txhFRML.Text.Split("|").Length - 1)

            For intCont = 0 To txhFRML.Text.Split("|").Length - 1
                strDadosImpressao(intCont + 2) = txhFRML.Text.Split("|")(intCont)
            Next

        Else
            ReDim strDadosImpressao(1)
        End If


        strDadosImpressao(0) = str
        strDadosImpressao(1) = txhRPT.Text



        Page.Session("dadosImpressao") = strDadosImpressao
        Response.Redirect("pop_imprimir_viewer.aspx")
    End Sub
End Class