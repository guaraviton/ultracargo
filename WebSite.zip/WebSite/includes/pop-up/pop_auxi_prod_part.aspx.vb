#Region "Imports"
Imports SAM.AE.Presentacion.Comun
Imports System.Data
Imports Utilidades
Imports Utilidades.Funcoes
Imports wbIntegra
Imports Utilidades.Constantes
Imports System.Web.Services.Protocols
#End Region

Partial Class INCLUDES_pop_up_pop_auxi_prod_part
    Inherits Controles.PageBaseIntegra

#Region "Eventos da p�gina"
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Ajax.Utility.RegisterTypeForAjax(GetType(INCLUDES_pop_up_pop_auxi_prod_part))
        rbtInicio.Attributes.Add("onClick", "selecionarRadioButton(1)") 'registra fun��es no client script que controla a sele��o dos RadioButtons
        rbtQQParte.Attributes.Add("onClick", "selecionarRadioButton(2)")
    End Sub
#End Region

#Region "M�todos AJAX"
    <Ajax.AjaxMethod()> _
        Public Function obter_ProdutoFiltro(ByVal strP As String, ByVal pstrStatus As String) As String
        Dim strParam() As String = strP.Split(",")
        Dim clsConverteXml As New ConverteXml
        Dim objCPlusOperacionalProd As New COMPlusOperacionalProduto
        Dim objWSOperacionalProd As New OperacionalProduto.STFCAOperacionalProduto
        Dim strXML As String
        Dim dsObter As New DataSet
        Dim strReturn As String
        Dim strStatus As String = "Ativo','Ativo Transporte','Ativo Armazem','Incompleto" 'filtro fixo que ser� passado para a cl�usula IN da procedure

        'objWSOperacionalProd.Url = ConfigurationManager.AppSettings("Integra.WB") & "/STFCAOperacionalProduto.asmx"

        If pstrStatus <> "" Then
            strStatus = "Ativo','Ativo Transporte"
        End If

        'atribui os par�metros para o COM+
        With objCPlusOperacionalProd
            .DSNOMEFANTASIA = strParam(0).Replace("'", "�")
            .DSNOMEFANTASIAPRODUTO = strParam(0).Replace("'", "�")
            .STATUS = strStatus
            .NRROTAMAPT = strParam(1)
            .NRONU = strParam(2)
            .TIPOCONS = strParam(3)
        End With

        clsConverteXml.firstNode = "idproduto" 'primeiro node que ser� retornado no XML
        clsConverteXml.xmlWs = objCPlusOperacionalProd.psrXml_obter_ProdutoFiltro

        Try
            strXML = objWSOperacionalProd.obter_ProdutoFiltroPopUp(clsConverteXml.xmlWs)
            clsConverteXml.xmlWs = Funcoes.Gerais.trocaHexaToAscii(strXML)

            If strXML.IndexOf("<mensagem value=") > -1 Then
                Return Nothing
            End If

            dsObter = clsConverteXml.cvtXml2Ds 'converte o XML para DataSet

            'verifica se h� dados no DataSet
            If dsObter.Tables.Count > 0 Then
                If dsObter.Tables(0).Rows.Count > 0 Then
                    strReturn = Funcoes.Gerais.convertDStoAJAX(0, dsObter)
                    strReturn = strReturn.Replace(",", ".")
                    Return strReturn 'retorna o XML
                End If
            End If

        Catch excepcionNegocio As SoapException
            Dim ex1 As Exception = Nothing
            SAMExceptionWSHelper.UnwrapSAMException(excepcionNegocio, ex1)
            Throw ex1
        Finally
            objWSOperacionalProd.Dispose()
            dsObter.Dispose()
            clsConverteXml = Nothing
            objCPlusOperacionalProd = Nothing
        End Try

        'retorna vazio se n�o houver dados para a pesquisa
        Return Nothing
    End Function



#End Region

End Class