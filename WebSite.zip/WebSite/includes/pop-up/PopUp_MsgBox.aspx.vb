
Partial Class includes_pop_up_PopUp_MsgBox
    Inherits System.Web.UI.Page

End Class
