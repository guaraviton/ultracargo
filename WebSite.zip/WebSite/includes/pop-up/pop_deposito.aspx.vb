#Region "Includes"
Imports System
Imports System.Data
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports SAM.AE.Presentacion.Comun
Imports SAM.AE.Presentacion.Controles
Imports SAM.AE.Entorno
Imports SAM.AE.Nucleo.Errores
Imports SAM.AE
Imports SAM.AE.GestionInformacion.ExportacionDatos
Imports Utilidades
Imports WebService
Imports DTO

Imports System.Web.Services.Protocols
Imports SAM.AE.GestionInformacion.Datos
Imports Utilidades.Funcoes
Imports Utilidades.Constantes
#End Region

Partial Class pop_deposito
    Inherits Controles.PageBaseIntegra


    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load, Me.Load
        AjaxPro.Utility.RegisterTypeForAjax(GetType(pop_deposito))
    End Sub


#Region "Fun��es de Pesquisa"
    <AjaxPro.AjaxMethod()> _
    Public Function obter_DepositoFiltro(ByVal value As String, ByVal strIdFilialTerminal As String) As String
        'Ser� executado quando o campo produto perder o foco
        Dim strXML As String
        Dim dsRetorno As New DataSet
        Dim clsConverteXML As New ConverteXml()
        Dim objCPlusDeposito As New COMPlusArmazemDeposito
        Dim objWS As New wbIntegra.ArmazemDeposito.STFCAArmazemDeposito


        Try
            'atribui os par�metros para o COM+
            With objCPlusDeposito
                .CDDEPOSITO = value
                '.IDTERMINAL = intIdTerminal
                .IDFILIALTERMINAL = strIdFilialTerminal
                '.INSTATUS = strInStatus
            End With

            clsConverteXML.firstNode = "iddeposito" 'primeiro node que ser� retornado no XML
            clsConverteXML.xmlWs = objCPlusDeposito.pstrXml_obter_DepositoFiltro

            strXML = objWS.obter_DepositoFiltro(clsConverteXML.xmlWs)
            strXML = Funcoes.Gerais.trocaHexaToAscii(strXML)
            clsConverteXML.xmlWs = strXML
            dsRetorno = clsConverteXML.cvtXml2Ds 'converte o XML para DataSet

            If dsRetorno.Tables(0).Rows.Count <= 0 Then
                Throw New RegraApresentacaoException(Configuracoes.APLICACAO, Erros.M4, Nothing)
            ElseIf dsRetorno.Tables(0).Columns(0).ColumnName = "mensagem" Then
                Throw New RegraApresentacaoException(Configuracoes.APLICACAO, Erros.M4, Nothing)
            End If

            With dsRetorno.Tables(0)
                .Columns("iddeposito").SetOrdinal(0)
                .Columns("cddeposito").SetOrdinal(1)
                .Columns("instatus").SetOrdinal(2)
            End With
        Catch ex As Exception
            Throw ex
        Finally
            'Desalocando vari�veis no sistema
            clsConverteXML = Nothing
            objCPlusDeposito = Nothing
            objWS.Dispose()
        End Try

        Return Gerais.convertDStoAJAX(0, dsRetorno)
    End Function
#End Region
End Class