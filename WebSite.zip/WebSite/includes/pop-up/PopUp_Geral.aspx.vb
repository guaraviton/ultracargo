Imports System
Imports System.Data
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports SAM.AE.Presentacion.Comun
Imports SAM.AE.Presentacion.Controles
Imports SAM.AE.Entorno
Imports SAM.AE.Nucleo.Errores
Imports SAM.AE
Imports SAM.AE.GestionInformacion.ExportacionDatos
Imports Utilidades
Imports WebService
Imports DTO

Imports System.Web.Services.Protocols
Imports SAM.AE.GestionInformacion.Datos
Imports Utilidades.Funcoes
Imports Utilidades.Constantes

Partial Class PopUp_Geral
    Inherits Controles.PageBaseIntegra

    Protected Sub Page_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Init

    End Sub

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load, Me.Load
        Ajax.Utility.RegisterTypeForAjax(GetType(PopUp_Geral))
    End Sub

    Public Function envia_DTOPopulado(ByVal pObjDTOPopUpGeral As clsDTOPopUpGeral) As clsDTOPopUpGeral
        'Objetivo: Retorna para o JavaScript o DTO principal do PopUp
        Return pObjDTOPopUpGeral
    End Function

    <Ajax.AjaxMethod()> _
    Public Function executa_LinkPesquisar(ByVal pXMLDTOPopUpGeral As String) As String
        'Objetivo: Executa as fun��es que retornam os dados para o PopUp.
        Dim pObjDTOPopUpGeral As New clsDTOPopUpGeral
        Dim strClasse, strMetodo, strTipoPesquisa As String
        Dim objCOMPlusPessoa As New COMPlusPessoaPessoa
        Dim objCOMPlusPessoaCondutor As New COMPlusPessoaCondutor
        Dim objDTOPlusComercialRotas As New Rotas.clsDTOContratoRota
        Dim objDTOPlusRotasFichaFrete As New Rotas.clsDTORotasFichaFrete
        Dim objDTOPontoOperacional As New PontoOperacional.clsDTOPontoOperacional
        Dim objDTOContratoTransporte As New ContratoTransporte.clsDTOContratoTransporte
        Dim objDTODeslocamento As New Deslocamento.clsDTODeslocamento
        Dim objCOMPlusEquipamentoEquipamento As New COMPlusEquipamentoEquipamento()
        Dim objDTOMovtoEquip As New MvtoEquip.clsDTOMovtoEquip
        Dim objClsAdapRotas As New Rotas.clsWSRotas
        Dim objWSDeslocamento As New Deslocamento.clsWSDeslocamento
        Dim strXMLRetorno As String
        Dim objConvert As New Funcoes.ConverteXml
        Dim dsRetorno As New DataSet
        Dim strReturn As String
        Dim dsRetornoFunc As New DataSet
        Dim wbPessoas As New wbIntegra.PessoaPessoa.STFCAPessoaPessoa
        Dim objWSContratoTransporte As New WebService.ContratoTransporte.clsWSContratoTransporte
        Dim objWBPontoOperacional As New WebService.PontoOperacional.clsWSPontoOperacional
        Dim objWBEquipamento As New wbIntegra.EquipamentoEquipamento.STFCAEquipamentoEquipamento
        Dim objWSMovtoEquip As New WebService.MvtoEquip.clsWSMovtoEquip
        Dim intCont, intValor As Integer
        Dim blnExcluirColuna As Boolean

        'Define Dinamicamente o Caminho do WS.
        ''objWSContratoTransporte.Url = ConfigurationManager.AppSettings("Integra.WS") & ".WebService/clsWSContratoTransporte.asmx"
        'wbPessoas.Url = ConfigurationManager.AppSettings("Integra.WB") & "/STFCAPessoaPessoa.asmx"
        ''objWBPontoOperacional.Url = ConfigurationManager.AppSettings("Integra.WS") & ".WebService/clsWSPontoOperacional.asmx"
        'objClsAdapRotas.Url = ConfigurationManager.AppSettings("Integra.WS") & ".WebService/clsWSRotas.asmx"
        ''objWBEquipamento.Url = ConfigurationManager.AppSettings("Integra.WB") & "/STFCAEquipamentoEquipamento.asmx"
        ''objWSMovtoEquip.Url = ConfigurationManager.AppSettings("Integra.WS") & ".WebService/clsWSMovtoEquip.asmx"

        DTOBase.XMLToDTO(pXMLDTOPopUpGeral, GetType(clsDTOPopUpGeral), pObjDTOPopUpGeral)

        strClasse = pObjDTOPopUpGeral.NOME_DA_CLASSE
        strMetodo = pObjDTOPopUpGeral.NOME_DO_METODO

        strReturn = ""

        If Trim(pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(0)) <> "" Then pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(0) = Replace(pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(0), "'", "�")
        If Trim(pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(1)) <> "" Then pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(1) = Replace(pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(1), "'", "�")

        'Verifica o tipo de pesquisa selecionado
        If pObjDTOPopUpGeral.TIPOPESQUISA = 0 Then strTipoPesquisa = "" Else strTipoPesquisa = "%"

        Select Case strClasse
            Case "clsCCPessoa" 'Para PopUp Remetente, Destinat�rio e cliente

                If strMetodo = "obter_FilialFiltro" Then

                    Select Case pObjDTOPopUpGeral.NOME_POPUP
                        Case "REMETENTE", "DESTINATARIO", "SAIDA", "CHEGADA"
                            objCOMPlusPessoa.pCOMPlusObterFilialFiltro.inNomeFantasia = IIf(Trim(pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(0)) <> "", strTipoPesquisa & Trim(pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(0)) & strTipoPesquisa, "")
                            objCOMPlusPessoa.pCOMPlusObterFilialFiltro.inNomeFantasiaFilial = IIf(Trim(pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(1)) <> "", strTipoPesquisa & Trim(pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(1)) & strTipoPesquisa, "")
                            objCOMPlusPessoa.pCOMPlusObterFilialFiltro.inCliente = pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(2)

                            If Trim(pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(3)) <> "" Then
                                objCOMPlusPessoa.pCOMPlusObterFilialFiltro.infilialultra = pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(3)
                            End If

                            objCOMPlusPessoa.pCOMPlusObterFilialFiltro.inPontoOperacional = pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(4)
                            If Trim(pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(5)) <> "" Then
                                objCOMPlusPessoa.pCOMPlusObterFilialFiltro.inTerminal = pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(5)
                            End If

                            If Not pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(8) Is Nothing Then
                                objCOMPlusPessoa.pCOMPlusObterFilialFiltro.nrCNPJCPF = pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(8).Replace(".", "")
                            End If

                            If Not pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(9) Is Nothing Then objCOMPlusPessoa.pCOMPlusObterFilialFiltro.nrComplCNPJ = pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(9)

                            objCOMPlusPessoa.pCOMPlusObterFilialFiltro.inStatus = "Ativo"

                        Case "CLIENTE"
                            objCOMPlusPessoa.pCOMPlusObterFilialFiltro.inCliente = Trim(pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(2))
                            objCOMPlusPessoa.pCOMPlusObterFilialFiltro.inNomeFantasia = IIf(Trim(pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(0)) <> "", strTipoPesquisa & Trim(Trim(pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(0))) & strTipoPesquisa, "")
                            objCOMPlusPessoa.pCOMPlusObterFilialFiltro.inNomeFantasiaFilial = IIf(Trim(pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(1)) <> "", strTipoPesquisa & Trim(pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(1)) & strTipoPesquisa, "")
                            objCOMPlusPessoa.pCOMPlusObterFilialFiltro.inStatus = Trim(pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(3))

                        Case "TRANSPORTADORA"
                            objCOMPlusPessoa.pCOMPlusObterFilialFiltro.inNomeFantasia = IIf(Trim(pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(0)) <> "", strTipoPesquisa & Trim(Trim(pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(0))) & strTipoPesquisa, "")
                            objCOMPlusPessoa.pCOMPlusObterFilialFiltro.inNomeFantasiaFilial = IIf(Trim(pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(1)) <> "", strTipoPesquisa & Trim(pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(1)) & strTipoPesquisa, "")
                            objCOMPlusPessoa.pCOMPlusObterFilialFiltro.inTransportadora = IIf(Trim(pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(2)) <> "", strTipoPesquisa, "") & Trim(pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(2))

                        Case "SUBCONTRATADO"
                            objCOMPlusPessoa.pCOMPlusObterFilialFiltro.inSubcontratado = "S"
                            objCOMPlusPessoa.pCOMPlusObterFilialFiltro.inNomeFantasia = IIf(Trim(pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(0)) <> "", strTipoPesquisa & Trim(Trim(pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(0))) & strTipoPesquisa, "")
                            objCOMPlusPessoa.pCOMPlusObterFilialFiltro.inNomeFantasiaFilial = IIf(Trim(pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(1)) <> "", strTipoPesquisa & Trim(pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(1)) & strTipoPesquisa, "")
                            objCOMPlusPessoa.pCOMPlusObterFilialFiltro.inStatus = "Ativo"
                    End Select

                    Try
                        strXMLRetorno = wbPessoas.obter_FilialFiltro(objCOMPlusPessoa.pCOMPlusObterFilialFiltro.psrXml_obter_FilialFiltro_PopUp)

                        If strXMLRetorno <> "" Then
                            objConvert.firstNode = "dsnomefantasiaent"
                            objConvert.xmlWs = Funcoes.Gerais.trocaHexaToAscii(strXMLRetorno)
                            dsRetornoFunc = objConvert.cvtXml2Ds

                            If dsRetornoFunc.Tables(0).Columns(0).ColumnName = "mensagem" Then
                                Return dsRetornoFunc.Tables(0).Rows(0)(0)
                            End If

                            If dsRetornoFunc.Tables(0).Rows.Count = 0 Then Return ""

                            'Remove as Colunas que n�o Interessam para a Visualiza��o.
                            For intValor = 0 To dsRetornoFunc.Tables(0).Columns.Count - 1

                                If intValor = dsRetornoFunc.Tables(0).Columns.Count Then Exit For

                                If (dsRetornoFunc.Tables(0).Columns(intValor).ColumnName.ToUpper <> "DSNOMEFANTASIAENT") _
                                And (dsRetornoFunc.Tables(0).Columns(intValor).ColumnName.ToUpper <> "DSCONCATENADO") _
                                And (dsRetornoFunc.Tables(0).Columns(intValor).ColumnName.ToUpper <> "NRCNPJFORMATADO") _
                                And (dsRetornoFunc.Tables(0).Columns(intValor).ColumnName.ToUpper <> "IDCLIENTE") _
                                And (dsRetornoFunc.Tables(0).Columns(intValor).ColumnName.ToUpper <> "IDDESTINATARIO") _
                                And (dsRetornoFunc.Tables(0).Columns(intValor).ColumnName.ToUpper <> "IDREMETENTE") _
                                And (dsRetornoFunc.Tables(0).Columns(intValor).ColumnName.ToUpper <> "IDFILIALCLIENTE") _
                                And (dsRetornoFunc.Tables(0).Columns(intValor).ColumnName.ToUpper <> "IDFILIALDESTINATARIO") _
                                And (dsRetornoFunc.Tables(0).Columns(intValor).ColumnName.ToUpper <> "IDFILIALREMETENTE") Then
                                    dsRetornoFunc.Tables(0).Columns.Remove(dsRetornoFunc.Tables(0).Columns(intValor).ColumnName)
                                    intValor -= 1

                                End If
                            Next

                            If dsRetornoFunc.Tables(0).Columns(0).ColumnName <> "mensagem" Then
                                dsRetornoFunc.Tables(0).Columns.Add("IDPK", Type.GetType("System.String"))

                                If dsRetornoFunc.Tables(0).Rows.Count > 0 Then
                                    For intCont = 0 To dsRetornoFunc.Tables(0).Rows.Count - 1
                                        dsRetornoFunc.Tables(0).Rows(intCont)("IDPK") = intCont
                                    Next
                                Else
                                    Return ""
                                End If

                                strReturn = Funcoes.Gerais.convertDStoAJAX(9, dsRetornoFunc)
                                strReturn = strReturn.Replace("%2E", ".")
                            Else
                                Return ""
                            End If
                        End If
                    Catch ex As SoapException
                        Dim exRegra As Exception = Nothing
                        SAMExceptionWSHelper.UnwrapSAMException(ex, exRegra)
                        Throw New RegraApresentacaoException(exRegra.Message, Nothing)
                    Catch ex As Exception
                        Throw New RegraApresentacaoException(Configuracoes.APLICACAO, Erros.M0, ex)
                    Finally
                        dsRetornoFunc.Dispose()
                    End Try

                    ' Para o campo Afretador-Empresa do relat�rio de Performance
                ElseIf strMetodo = "obter_EntidadeFilt" Then

                    objCOMPlusPessoa.pCOMPlusObterFilialFiltro.inCliente = Trim(pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(2))
                    objCOMPlusPessoa.pCOMPlusObterFilialFiltro.inNomeFantasia = IIf(Trim(pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(0)) <> "", strTipoPesquisa & Trim(Trim(pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(0))) & strTipoPesquisa, "")
                    objCOMPlusPessoa.pCOMPlusObterFilialFiltro.inNomeFantasiaFilial = IIf(Trim(pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(1)) <> "", strTipoPesquisa & Trim(pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(1)) & strTipoPesquisa, "")
                    objCOMPlusPessoa.pCOMPlusObterFilialFiltro.inStatus = Trim(pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(3))

                    Try
                        strXMLRetorno = wbPessoas.obter_EntidadeFilt(objCOMPlusPessoa.pCOMPlusObterFilialFiltro.psrXml_obter_FilialFiltro)

                        If strXMLRetorno <> "" Then
                            objConvert.firstNode = "dsnomefantasiaent"
                            objConvert.xmlWs = Funcoes.Gerais.trocaHexaToAscii(strXMLRetorno)
                            dsRetornoFunc = objConvert.cvtXml2Ds

                            If dsRetornoFunc.Tables(0).Columns(0).ColumnName = "mensagem" Then Return ""

                            If dsRetornoFunc.Tables(0).Rows.Count = 0 Then Return ""

                            'Remove as Colunas que n�o Interessam para a Visualiza��o.
                            For intValor = 0 To dsRetornoFunc.Tables(0).Columns.Count - 1

                                If intValor = dsRetornoFunc.Tables(0).Columns.Count Then Exit For

                                If (dsRetornoFunc.Tables(0).Columns(intValor).ColumnName.ToUpper <> "IDCLIENTE") _
                                And (dsRetornoFunc.Tables(0).Columns(intValor).ColumnName.ToUpper <> "DSNOMEFANTASIAENT") _
                                And (dsRetornoFunc.Tables(0).Columns(intValor).ColumnName.ToUpper <> "NRCNPJFORMATADO") _
                                And (dsRetornoFunc.Tables(0).Columns(intValor).ColumnName.ToUpper <> "IDFILIALCLIENTE") Then
                                    dsRetornoFunc.Tables(0).Columns.Remove(dsRetornoFunc.Tables(0).Columns(intValor).ColumnName)
                                    intValor -= 1

                                End If
                            Next

                            If dsRetornoFunc.Tables(0).Columns(0).ColumnName <> "mensagem" Then
                                dsRetornoFunc.Tables(0).Columns.Add("IDPK", Type.GetType("System.String"))

                                If dsRetornoFunc.Tables(0).Rows.Count > 0 Then
                                    For intCont = 0 To dsRetornoFunc.Tables(0).Rows.Count - 1
                                        dsRetornoFunc.Tables(0).Rows(intCont)("IDPK") = intCont
                                    Next
                                Else
                                    Return ""
                                End If

                                strReturn = Funcoes.Gerais.convertDStoAJAX(3, dsRetornoFunc)
                                strReturn = strReturn.Replace("%2E", ".")
                            Else
                                Return ""
                            End If
                        End If
                    Catch ex As Exception
                        Throw New RegraApresentacaoException(Configuracoes.APLICACAO, Erros.M0, ex)
                    Finally
                        dsRetornoFunc.Dispose()
                    End Try

                ElseIf strMetodo = "obter_FilialFiltroPop" Then
                    Select Case pObjDTOPopUpGeral.NOME_POPUP
                        Case "POSTO"
                            objCOMPlusPessoa.pCOMPlusObterFilialFiltro.inNomeFantasia = IIf(Trim(pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(0)) <> "", strTipoPesquisa & Trim(Trim(pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(0))) & strTipoPesquisa, "")
                            objCOMPlusPessoa.pCOMPlusObterFilialFiltro.inNomeFantasiaFilial = IIf(Trim(pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(1)) <> "", strTipoPesquisa & Trim(pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(1)) & strTipoPesquisa, "")
                            objCOMPlusPessoa.pCOMPlusObterFilialFiltro.inPosto = IIf(Trim(pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(2)) <> "", strTipoPesquisa, "") & Trim(pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(2))
                    End Select

                    Try
                        strXMLRetorno = wbPessoas.obter_FilialFiltroPop(objCOMPlusPessoa.pCOMPlusObterFilialFiltro.psrXml_obter_FilialFiltro_PopUp)

                        If strXMLRetorno <> "" Then
                            objConvert.firstNode = "dsnomefantasiaent"
                            objConvert.xmlWs = Funcoes.Gerais.trocaHexaToAscii(strXMLRetorno)
                            dsRetornoFunc = objConvert.cvtXml2Ds

                            If dsRetornoFunc.Tables(0).Columns(0).ColumnName = "mensagem" Then
                                Return dsRetornoFunc.Tables(0).Rows(0)(0)
                            End If

                            If dsRetornoFunc.Tables(0).Rows.Count = 0 Then Return ""

                            'Remove as Colunas que n�o Interessam para a Visualiza��o.
                            For intValor = 0 To dsRetornoFunc.Tables(0).Columns.Count - 1

                                If intValor = dsRetornoFunc.Tables(0).Columns.Count Then Exit For
                                With dsRetornoFunc.Tables(0).Columns(intValor)
                                    If (.ColumnName.ToUpper <> "DSNOMEFANTASIAENT") _
                                    And (.ColumnName.ToUpper <> "DSNOMECONCATENADO") _
                                    And (.ColumnName.ToUpper <> "NRCNPJFORMATADO") _
                                    And (.ColumnName.ToUpper <> "IDENTIDADE") _
                                    And (.ColumnName.ToUpper <> "IDFILIAL") _
                                    And (.ColumnName.ToUpper <> "INTIPOJF") _
                                    And (.ColumnName.ToUpper <> "NRCNPJCPF") _
                                    And (.ColumnName.ToUpper <> "INPOSTO") Then
                                        dsRetornoFunc.Tables(0).Columns.Remove(.ColumnName)
                                        intValor -= 1

                                    End If
                                End With
                            Next

                            If dsRetornoFunc.Tables(0).Columns(0).ColumnName <> "mensagem" Then
                                dsRetornoFunc.Tables(0).Columns.Add("IDPK", Type.GetType("System.String"))

                                If dsRetornoFunc.Tables(0).Rows.Count > 0 Then
                                    For intCont = 0 To dsRetornoFunc.Tables(0).Rows.Count - 1
                                        dsRetornoFunc.Tables(0).Rows(intCont)("IDPK") = intCont
                                    Next
                                Else
                                    Return ""
                                End If

                                strReturn = Funcoes.Gerais.convertDStoAJAX(8, dsRetornoFunc)
                                strReturn = strReturn.Replace("%2E", ".")
                            Else
                                Return ""
                            End If
                        End If
                    Catch ex As SoapException
                        Dim exRegra As Exception = Nothing
                        SAMExceptionWSHelper.UnwrapSAMException(ex, exRegra)
                        Throw New RegraApresentacaoException(exRegra.Message, Nothing)
                    Catch ex As Exception
                        Throw New RegraApresentacaoException(Configuracoes.APLICACAO, Erros.M0, ex)
                    Finally
                        dsRetornoFunc.Dispose()
                    End Try

                End If

            Case "clsCCRotas" 'Para PopUp de Carga e Descarga

                If strMetodo = "filtrar_ContratoOrigem" Then

                    Select Case pObjDTOPopUpGeral.NOME_POPUP
                        Case "CARGA"
                            objDTOPlusComercialRotas.IDCLIENTE = pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(2)
                            objDTOPlusComercialRotas.IDFILIALCLIENTE = pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(3)
                            objDTOPlusComercialRotas.DSNOMEFANTASIAORIGEM = IIf(Trim(pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(0)) <> "", strTipoPesquisa & Trim(pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(0)) & strTipoPesquisa, "")
                            objDTOPlusComercialRotas.DSNOMEFANTASIAFILIALORIGEM = IIf(Trim(pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(1)) <> "", strTipoPesquisa & Trim(pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(1)) & strTipoPesquisa, "")
                            objDTOPlusComercialRotas.IDPRODUTO = pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(5)
                            objDTOPlusComercialRotas.DSTIPOPESQUISA = IIf(strTipoPesquisa = "", "INICIO", "QQPARTE")

                            If pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC.Length = 7 Then
                                If Not pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(6) Is Nothing Then
                                    If pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(6) <> "" Then
                                        objDTOPlusComercialRotas.INTROCANOTA = pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(6)
                                    End If
                                End If
                            End If

                            If Not pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(8) Is Nothing Then
                                objDTOPlusComercialRotas.NRCNPJRAIZ = pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(8)

                                objDTOPlusComercialRotas.NRCNPJRAIZ = objDTOPlusComercialRotas.NRCNPJRAIZ.Replace(".", "")
                            End If

                            If Not pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(9) Is Nothing Then objDTOPlusComercialRotas.NRCNPJCOMPLEMENTO = pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(9)

                            Try
                                dsRetornoFunc = objClsAdapRotas.filtrar_ContratoOrigem(objDTOPlusComercialRotas)

                                If dsRetornoFunc.Tables(0).Rows.Count = 0 Then Return ""

                                If dsRetornoFunc.Tables(0).Columns(0).ColumnName = "mensagem" Then Return ""

                                dsRetornoFunc.Tables(0).Columns.Add("IDPK", Type.GetType("System.String"))

                                For intCont = 0 To dsRetornoFunc.Tables(0).Rows.Count - 1
                                    dsRetornoFunc.Tables(0).Rows(intCont)("IDPK") = intCont
                                Next

                                strReturn = Funcoes.Gerais.convertDStoAJAX(5, dsRetornoFunc)
                                strReturn = strReturn.Replace("%2E", ".")
                            Catch ex As SoapException
                                Dim exRegra As Exception = Nothing
                                SAMExceptionWSHelper.UnwrapSAMException(ex, exRegra)
                                Throw New RegraApresentacaoException(exRegra.Message, Nothing)
                            Catch ex As Exception
                                Throw New RegraApresentacaoException(Configuracoes.APLICACAO, Erros.M0, ex)
                            Finally
                                dsRetornoFunc.Dispose()
                            End Try
                    End Select
                End If

                If strMetodo = "filtrar_ContratoDestino" Then

                    Select Case pObjDTOPopUpGeral.NOME_POPUP

                        Case "DESCARGA"
                            objDTOPlusComercialRotas.IDCLIENTE = pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(2)
                            objDTOPlusComercialRotas.IDFILIALCLIENTE = pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(3)
                            objDTOPlusComercialRotas.DSNOMEFANTASIADESTINO = IIf(Trim(pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(0)) <> "", strTipoPesquisa & Trim(pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(0)) & strTipoPesquisa, "")
                            objDTOPlusComercialRotas.DSNOMEFANTASIAFILIALDESTINO = IIf(Trim(pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(1)) <> "", strTipoPesquisa & Trim(pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(1)) & strTipoPesquisa, "")
                            objDTOPlusComercialRotas.IDPONTOORIGEM = pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(4)
                            objDTOPlusComercialRotas.IDFILIALORIGEM = pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(5)
                            objDTOPlusComercialRotas.IDPRODUTO = pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(6)
                            objDTOPlusComercialRotas.INTROCANOTA = pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(7)
                            objDTOPlusComercialRotas.DSTIPOPESQUISA = IIf(strTipoPesquisa = "", "INICIO", "QQPARTE")

                            If Not pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(8) Is Nothing Then
                                objDTOPlusComercialRotas.NRCNPJRAIZ = pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(8)

                                objDTOPlusComercialRotas.NRCNPJRAIZ = objDTOPlusComercialRotas.NRCNPJRAIZ.Replace(".", "")
                            End If

                            If Not pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(9) Is Nothing Then objDTOPlusComercialRotas.NRCNPJCOMPLEMENTO = pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(9)

                            Try
                                dsRetornoFunc = objClsAdapRotas.filtrar_ContratoDestino(objDTOPlusComercialRotas)

                                If dsRetornoFunc.Tables(0).Columns(0).ColumnName <> "mensagem" Then
                                    If dsRetornoFunc.Tables(0).Rows.Count > 0 Then

                                        dsRetornoFunc.Tables(0).Columns.Add("IDPK", Type.GetType("System.String"))

                                        For intCont = 0 To dsRetornoFunc.Tables(0).Rows.Count - 1
                                            dsRetornoFunc.Tables(0).Rows(intCont)("IDPK") = intCont
                                        Next

                                        strReturn = Funcoes.Gerais.convertDStoAJAX(5, dsRetornoFunc)
                                        strReturn = strReturn.Replace("%2E", ".")
                                    Else
                                        Return ""
                                    End If
                                Else
                                    Return ""
                                End If
                            Catch ex As SoapException
                                Dim exRegra As Exception = Nothing
                                SAMExceptionWSHelper.UnwrapSAMException(ex, exRegra)
                                Throw New RegraApresentacaoException(exRegra.Message, Nothing)
                            Catch ex As Exception
                                Throw New RegraApresentacaoException(Configuracoes.APLICACAO, Erros.M0, ex)
                            Finally
                                dsRetornoFunc.Dispose()
                            End Try

                    End Select
                End If

                If strMetodo = "filtrar_contratorem" Then

                    objDTOPlusComercialRotas.IDCLIENTE = pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(2)
                    objDTOPlusComercialRotas.IDFILIALCLIENTE = pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(3)
                    objDTOPlusComercialRotas.IDPONTOORIGEM = pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(4)
                    objDTOPlusComercialRotas.IDFILIALORIGEM = pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(5)
                    objDTOPlusComercialRotas.IDPRODUTO = pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(6)
                    objDTOPlusComercialRotas.DSNOMEFANTASIAORIGEM = IIf(Trim(pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(0)) <> "", strTipoPesquisa & Trim(pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(0)) & strTipoPesquisa, "")
                    objDTOPlusComercialRotas.DSNOMEFANTASIAFILIALORIGEM = IIf(Trim(pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(1)) <> "", strTipoPesquisa & Trim(pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(1)) & strTipoPesquisa, "")
                    objDTOPlusComercialRotas.DSTIPOPESQUISA = IIf(strTipoPesquisa = "", "INICIO", "QQPARTE")

                    If pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC.Length = 7 Then
                        If Not pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(6) Is Nothing Then
                            If pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(6) <> "" Then
                                objDTOPlusComercialRotas.INTROCANOTA = pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(6)
                            End If
                        End If
                    End If

                    If Not pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(8) Is Nothing Then
                        objDTOPlusComercialRotas.NRCNPJRAIZ = pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(8)

                        objDTOPlusComercialRotas.NRCNPJRAIZ = objDTOPlusComercialRotas.NRCNPJRAIZ.Replace(".", "")
                    End If

                    If Not pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(9) Is Nothing Then objDTOPlusComercialRotas.NRCNPJCOMPLEMENTO = pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(9)

                    objDTOPlusComercialRotas.IDPONTODESTINO = pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(10)
                    objDTOPlusComercialRotas.IDFILIALDESTINO = pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(11)

                    Try
                        dsRetornoFunc = objClsAdapRotas.filtrar_contratorem(objDTOPlusComercialRotas)

                        If dsRetornoFunc.Tables(0).Columns(0).ColumnName <> "mensagem" Then
                            If dsRetornoFunc.Tables(0).Rows.Count > 0 Then

                                dsRetornoFunc.Tables(0).Columns.Add("IDPK", Type.GetType("System.String"))

                                For intCont = 0 To dsRetornoFunc.Tables(0).Rows.Count - 1
                                    dsRetornoFunc.Tables(0).Rows(intCont)("IDPK") = intCont
                                Next

                                strReturn = Funcoes.Gerais.convertDStoAJAX(4, dsRetornoFunc)
                                strReturn = strReturn.Replace("%2E", ".")
                            Else
                                Return ""
                            End If
                        Else
                            Return ""
                        End If
                    Catch ex As SoapException
                        Dim exRegra As Exception = Nothing
                        SAMExceptionWSHelper.UnwrapSAMException(ex, exRegra)
                        Throw New RegraApresentacaoException(exRegra.Message, Nothing)
                    Catch ex As Exception
                        Throw New RegraApresentacaoException(Configuracoes.APLICACAO, Erros.M0, ex)
                    Finally
                        dsRetornoFunc.Dispose()
                    End Try

                End If

                If strMetodo = "filtrar_contratodes" Then

                    objDTOPlusComercialRotas.IDCLIENTE = pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(2)
                    objDTOPlusComercialRotas.IDFILIALCLIENTE = pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(3)
                    objDTOPlusComercialRotas.IDPONTOORIGEM = pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(4)
                    objDTOPlusComercialRotas.IDFILIALORIGEM = pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(5)
                    objDTOPlusComercialRotas.IDPRODUTO = pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(6)
                    objDTOPlusComercialRotas.IDREMETENTE = pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(10)
                    objDTOPlusComercialRotas.IDFILIALREMETENTE = pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(11)
                    objDTOPlusComercialRotas.DSNOMEFANTASIAORIGEM = IIf(Trim(pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(0)) <> "", strTipoPesquisa & Trim(pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(0)) & strTipoPesquisa, "")
                    objDTOPlusComercialRotas.DSNOMEFANTASIAFILIALORIGEM = IIf(Trim(pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(1)) <> "", strTipoPesquisa & Trim(pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(1)) & strTipoPesquisa, "")
                    objDTOPlusComercialRotas.DSTIPOPESQUISA = IIf(strTipoPesquisa = "", "INICIO", "QQPARTE")
                    objDTOPlusComercialRotas.IDPONTODESTINO = pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(12)
                    objDTOPlusComercialRotas.IDFILIALDESTINO = pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(13)

                    Try
                        dsRetornoFunc = objClsAdapRotas.filtrar_contratodes(objDTOPlusComercialRotas)

                        If dsRetornoFunc.Tables(0).Columns(0).ColumnName <> "mensagem" Then
                            If dsRetornoFunc.Tables(0).Rows.Count > 0 Then

                                dsRetornoFunc.Tables(0).Columns.Add("IDPK", Type.GetType("System.String"))

                                For intCont = 0 To dsRetornoFunc.Tables(0).Rows.Count - 1
                                    dsRetornoFunc.Tables(0).Rows(intCont)("IDPK") = intCont
                                Next

                                strReturn = Funcoes.Gerais.convertDStoAJAX(4, dsRetornoFunc)
                                strReturn = strReturn.Replace("%2E", ".")
                            Else
                                Return ""
                            End If
                        Else
                            Return ""
                        End If
                    Catch ex As SoapException
                        Dim exRegra As Exception = Nothing
                        SAMExceptionWSHelper.UnwrapSAMException(ex, exRegra)
                        Throw New RegraApresentacaoException(exRegra.Message, Nothing)
                    Catch ex As Exception
                        Throw New RegraApresentacaoException(Configuracoes.APLICACAO, Erros.M0, ex)
                    Finally
                        dsRetornoFunc.Dispose()
                    End Try

                End If

            Case "clsCCPontoOperacional"
                Select Case pObjDTOPopUpGeral.NOME_POPUP
                    Case "CARGA", "DESCARGA"

                        objDTOPontoOperacional.DSNOMEFANTASIAENTIDADE = IIf(Trim(pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(0)) <> "", strTipoPesquisa & Trim(pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(0)) & strTipoPesquisa, "")
                        objDTOPontoOperacional.DSNOMEFANTASIAFILIAL = IIf(Trim(pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(1)) <> "", strTipoPesquisa & Trim(pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(1)) & strTipoPesquisa, "")
                        objDTOPontoOperacional.IDENTIDADE = pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(2)
                        objDTOPontoOperacional.IDFILIAL = pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(3)
                        objDTOPontoOperacional.INPONTOCARGA = IIf(pObjDTOPopUpGeral.NOME_POPUP = "CARGA", pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(4), Nothing)
                        objDTOPontoOperacional.INPONTODESCARGA = IIf(pObjDTOPopUpGeral.NOME_POPUP = "DESCARGA", pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(4), Nothing)

                        If Not pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(8) Is Nothing Then
                            objDTOPontoOperacional.nrCNPJCPF = pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(8).Replace(".", "")
                        End If

                        If Not pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(9) Is Nothing Then objDTOPontoOperacional.nrComplCNPJ = pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(9)

                        Try
                            dsRetornoFunc = objWBPontoOperacional.obter_TipoPontoFiltro(objDTOPontoOperacional)

                            If dsRetornoFunc.Tables(0).Columns(0).ColumnName = "mstr_Mensagem" Then dsRetornoFunc.Tables(0).Columns(0).ColumnName = "mensagem"

                            If dsRetornoFunc.Tables(0).Columns(0).ColumnName <> "mensagem" Then

                                dsRetornoFunc.Tables(0).Columns.Add("IDPK", Type.GetType("System.String"))

                                If dsRetornoFunc.Tables(0).Rows.Count > 0 Then

                                    For intCont = 0 To dsRetornoFunc.Tables(0).Rows.Count - 1
                                        dsRetornoFunc.Tables(0).Rows(intCont)("IDPK") = CStr(intCont)
                                        dsRetornoFunc.Tables(0).Rows(intCont)(6) = dsRetornoFunc.Tables(0).Rows(intCont)(5) & "/" & dsRetornoFunc.Tables(0).Rows(intCont)(6)
                                    Next

                                    strReturn = Funcoes.Gerais.convertDStoAJAX(7, dsRetornoFunc)
                                    strReturn = strReturn.Replace("%2E", ".")
                                Else
                                    Return ""
                                End If
                            Else
                                Return ""
                            End If
                        Catch ex As SoapException
                            Dim exRegra As Exception = Nothing
                            SAMExceptionWSHelper.UnwrapSAMException(ex, exRegra)
                            Throw New RegraApresentacaoException(exRegra.Message, Nothing)
                        Catch ex As Exception
                            Throw New RegraApresentacaoException(Configuracoes.APLICACAO, Erros.M0, ex)
                        Finally
                            dsRetornoFunc.Dispose()
                        End Try
                End Select


            Case "clsCCContratoTransporte"  'PopUp de Produto com Contrato

                Select Case pObjDTOPopUpGeral.NOME_POPUP

                    Case "PRODUTO"
                        objDTOContratoTransporte.DSNOMEFANTASIAPROD = IIf(Trim(pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(0)) <> "", strTipoPesquisa & Trim(pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(0)) & strTipoPesquisa, "")
                        objDTOContratoTransporte.IDCLIENTE = pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(2)
                        objDTOContratoTransporte.IDFILIALCLIENTE = pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(3)

                        Try
                            dsRetornoFunc = objWSContratoTransporte.obter_ProdutosContratoFiltro(objDTOContratoTransporte)

                            If dsRetornoFunc.Tables(0).Rows.Count = 0 Then Return ""

                            If Not dsRetornoFunc Is Nothing Then
                                If dsRetornoFunc.Tables(0).Columns(0).ColumnName <> "mensagem" Then
                                    strReturn = Funcoes.Gerais.convertDStoAJAX(0, dsRetornoFunc)
                                    strReturn = strReturn.Replace("%2E", ".")
                                    strReturn = strReturn.Replace(",", ".")
                                Else
                                    Return ""
                                End If
                            Else
                                Return ""
                            End If
                        Catch ex As SoapException
                            Dim exRegra As Exception = Nothing
                            SAMExceptionWSHelper.UnwrapSAMException(ex, exRegra)
                            Throw New RegraApresentacaoException(exRegra.Message, Nothing)
                        Catch ex As Exception
                            Throw New RegraApresentacaoException(Configuracoes.APLICACAO, Erros.M0, ex)
                        Finally
                            dsRetornoFunc.Dispose()
                        End Try
                End Select
            Case "clsCCDeslocamento"
                Select Case pObjDTOPopUpGeral.NOME_POPUP
                    Case "CARGA"
                        objDTODeslocamento.DTOContratoDeslocamento = New Deslocamento.clsDTOContratoDeslocamento

                        With objDTODeslocamento.DTOContratoDeslocamento
                            .IDCLIENTE = pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(2)
                            .IDFILIALCLIENTE = pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(3)
                            .DSNOMEFANTASIAORIGEM = IIf(Trim(pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(0)) <> "", strTipoPesquisa & Trim(pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(0)) & strTipoPesquisa, "")
                            .DSNOMEFANTASIAFILIALORIGEM = IIf(Trim(pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(1)) <> "", strTipoPesquisa & Trim(pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(1)) & strTipoPesquisa, "")
                            .DSTIPOPESQUISA = IIf(strTipoPesquisa = "", "INICIO", "QQPARTE")
                        End With

                        Try
                            dsRetornoFunc = objWSDeslocamento.filtrar_ContratoOrigem(objDTODeslocamento)

                            If dsRetornoFunc.Tables(0).Columns(0).ColumnName <> "mensagem" Then
                                If dsRetornoFunc.Tables(0).Rows.Count > 0 Then

                                    dsRetornoFunc.Tables(0).Columns.Add("IDPK", Type.GetType("System.String"))

                                    For intCont = 0 To dsRetornoFunc.Tables(0).Rows.Count - 1
                                        dsRetornoFunc.Tables(0).Rows(intCont)("IDPK") = intCont
                                    Next

                                    strReturn = Funcoes.Gerais.convertDStoAJAX(4, dsRetornoFunc)
                                    strReturn = strReturn.Replace("%2E", ".")
                                Else
                                    Return ""
                                End If
                            Else
                                Return ""
                            End If
                        Catch ex As SoapException
                            Dim exRegra As Exception = Nothing
                            SAMExceptionWSHelper.UnwrapSAMException(ex, exRegra)
                            Throw New RegraApresentacaoException(exRegra.Message, Nothing)
                        Catch ex As Exception
                            Throw New RegraApresentacaoException(Configuracoes.APLICACAO, Erros.M0, ex)
                        Finally
                            dsRetornoFunc.Dispose()
                        End Try
                    Case "DESCARGA"
                        objDTODeslocamento.DTOContratoDeslocamento = New Deslocamento.clsDTOContratoDeslocamento

                        With objDTODeslocamento.DTOContratoDeslocamento
                            .IDCLIENTE = pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(2)
                            .IDFILIALCLIENTE = pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(3)
                            .DSNOMEFANTASIADESTINO = IIf(Trim(pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(0)) <> "", strTipoPesquisa & Trim(pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(0)) & strTipoPesquisa, "")
                            .DSNOMEFANTASIAFILIALDESTINO = IIf(Trim(pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(1)) <> "", strTipoPesquisa & Trim(pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(1)) & strTipoPesquisa, "")
                            .IDPONTOORIGEM = pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(4)
                            .IDFILIALORIGEM = pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(5)
                            .DSTIPOPESQUISA = IIf(strTipoPesquisa = "", "INICIO", "QQPARTE")
                        End With

                        Try
                            dsRetornoFunc = objWSDeslocamento.filtrar_ContratoDestino(objDTODeslocamento)

                            If dsRetornoFunc.Tables(0).Columns(0).ColumnName <> "mensagem" Then
                                If dsRetornoFunc.Tables(0).Rows.Count > 0 Then

                                    dsRetornoFunc.Tables(0).Columns.Add("IDPK", Type.GetType("System.String"))

                                    For intCont = 0 To dsRetornoFunc.Tables(0).Rows.Count - 1
                                        dsRetornoFunc.Tables(0).Rows(intCont)("IDPK") = intCont
                                    Next

                                    strReturn = Funcoes.Gerais.convertDStoAJAX(4, dsRetornoFunc)
                                    strReturn = strReturn.Replace("%2E", ".")
                                Else
                                    Return ""
                                End If
                            Else
                                Return ""
                            End If
                        Catch ex As SoapException
                            Dim exRegra As Exception = Nothing
                            SAMExceptionWSHelper.UnwrapSAMException(ex, exRegra)
                            Throw New RegraApresentacaoException(exRegra.Message, Nothing)
                        Catch ex As Exception
                            Throw New RegraApresentacaoException(Configuracoes.APLICACAO, Erros.M0, ex)
                        Finally
                            dsRetornoFunc.Dispose()
                        End Try
                End Select

            Case "clsCCEquipamento"
                If strMetodo = "obter_EquipamentoFiltro" Then
                    With objCOMPlusEquipamentoEquipamento
                        .IdEmpProprietaria = pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(2)
                        .IdFilialProprietaria = pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(3)
                        .inCaracteristica = pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(5)
                        If Not pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(0) Is Nothing Then
                            If pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(0).Trim() <> "" Then
                                .dsFrota = strTipoPesquisa & pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(0) & strTipoPesquisa
                            End If
                        End If
                        .OrderBy = pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(4)
                    End With

                    Try

                        strXMLRetorno = objWBEquipamento.obter_EquipamentoFiltro(objCOMPlusEquipamentoEquipamento.psrXml_Obter_EquipamentoFiltroPopUpVeiculo)

                        If strXMLRetorno <> "" Then
                            objConvert.firstNode = "idequipamento"
                            objConvert.xmlWs = Funcoes.Gerais.trocaHexaToAscii(strXMLRetorno)
                            dsRetorno = objConvert.cvtXml2Ds

                            If dsRetorno.Tables(0).Rows.Count > 0 Then
                                If dsRetorno.Tables(0).Columns.Count > 1 Then
                                    dsRetorno.Tables(0).Columns.Add("dsFamiliaCategoria", GetType(String))
                                    For intValor = 0 To dsRetorno.Tables(0).Rows.Count - 1
                                        dsRetorno.Tables(0).Rows(intValor)("dsFamiliaCategoria") = dsRetorno.Tables(0).Rows(intValor)("dsFamilia") & "-" & dsRetorno.Tables(0).Rows(intValor)("dsCategoria")
                                    Next

                                    intValor = 0
                                    While intValor < dsRetorno.Tables(0).Columns.Count
                                        blnExcluirColuna = True
                                        For Each strNomeColuna As String In pObjDTOPopUpGeral.CAMPO_COLUNA
                                            If dsRetorno.Tables(0).Columns(intValor).ColumnName.ToUpper.Equals(strNomeColuna.ToUpper) Then
                                                blnExcluirColuna = False
                                            End If
                                        Next
                                        If blnExcluirColuna Then
                                            dsRetorno.Tables(0).Columns.RemoveAt(intValor)
                                            intValor -= 1
                                        End If
                                        intValor += 1
                                    End While
                                    strReturn = Funcoes.Gerais.convertDStoAJAX(0, dsRetorno)
                                    strReturn = strReturn.Replace("%2E", ".")
                                Else
                                    strReturn = ""
                                End If
                            Else
                                strReturn = ""
                            End If
                        End If
                    Catch ex As SoapException
                        Dim exRegra As Exception = Nothing
                        SAMExceptionWSHelper.UnwrapSAMException(ex, exRegra)
                        Throw New RegraApresentacaoException(exRegra.Message, Nothing)
                    Catch ex As Exception
                        Throw New RegraApresentacaoException(Configuracoes.APLICACAO, Erros.M0, ex)
                    Finally
                        dsRetorno.Dispose()
                    End Try
                End If
            Case "clsCCMovtoEquip"
                If strMetodo = "obter_EquipViagemUsuario" Then
                    With objDTOMovtoEquip
                        .SubContratado_idEmpresa = pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(2)
                        .SubContratado_idFilialEmpresa = pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(3)
                        .Cliente_idEmpresa = pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(4)
                        .Cliente_idFilialEmpresa = pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(5)
                        .Destinatario_idRemetente = pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(6)
                        .Destinatario_idFilialRemetente = pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(7)
                        .Destinatario_idEmpresa = pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(8)
                        .Destinatario_idFilialEmpresa = pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(9)
                        If Not pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(0) Is Nothing Then
                            If pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(0).Trim() <> "" Then
                                .DsFrota = strTipoPesquisa & pObjDTOPopUpGeral.CONTEUDO_CAMPO_PROC(0)
                            End If
                        End If
                    End With
                    Try
                        dsRetorno = objWSMovtoEquip.obter_EquipViagemUsuario(objDTOMovtoEquip)
                        If dsRetorno.Tables(0).Columns(0).ColumnName <> "mensagem" Then
                            If dsRetorno.Tables(0).Rows.Count > 0 Then
                                strReturn = Funcoes.Gerais.convertDStoAJAX(0, dsRetorno)
                                strReturn = strReturn.Replace("%2E", ".")
                            Else
                                strReturn = ""
                            End If
                        Else
                            strReturn = ""
                        End If
                    Catch ex As SoapException
                        Dim exRegra As Exception = Nothing
                        SAMExceptionWSHelper.UnwrapSAMException(ex, exRegra)
                        Throw New RegraApresentacaoException(exRegra.Message, Nothing)
                    Catch ex As Exception
                        Throw New RegraApresentacaoException(Configuracoes.APLICACAO, Erros.M0, ex)
                    Finally
                        dsRetornoFunc.Dispose()
                    End Try
                End If
        End Select

        'Desalocando Inst�ncias
        dsRetorno.Dispose()
        pObjDTOPopUpGeral = Nothing
        objCOMPlusPessoa = Nothing
        objCOMPlusPessoaCondutor = Nothing
        objDTOPlusComercialRotas = Nothing
        objCOMPlusEquipamentoEquipamento = Nothing
        objClsAdapRotas.Dispose()
        objConvert = Nothing
        wbPessoas.Dispose()
        objWBEquipamento.Dispose()
        objWSMovtoEquip.Dispose()

        Return strReturn

    End Function

    <Ajax.AjaxMethod()> _
    Public Function cria_DataSetComposicao() As String
        'Cria o dataset vazio para o Grid de Composi��o
        Dim dsCria As New DataSet
        dsCria.Tables.Add("Table1")
        dsCria.Tables(0).Columns.Add("C0", Type.GetType("System.String"))
        dsCria.Tables(0).Columns.Add("C1", Type.GetType("System.String"))
        dsCria.Tables(0).Columns.Add("C2", Type.GetType("System.String"))
        dsCria.Tables(0).Columns.Add("C3", Type.GetType("System.String"))
        dsCria.Tables(0).Columns.Add("C4", Type.GetType("System.String"))
        dsCria.Tables(0).Columns.Add("C5", Type.GetType("System.String"))
        dsCria.Tables(0).Columns.Add("C6", Type.GetType("System.String"))
        dsCria.Tables(0).Columns.Add("C7", Type.GetType("System.String"))
        dsCria.Tables(0).Columns.Add("C8", Type.GetType("System.String"))
        dsCria.Tables(0).Columns.Add("C9", Type.GetType("System.String"))
        dsCria.Tables(0).Columns.Add("C10", Type.GetType("System.String"))
        dsCria.Tables(0).Columns.Add("C11", Type.GetType("System.String"))
        dsCria.Tables(0).Columns.Add("C12", Type.GetType("System.String"))
        dsCria.Tables(0).Columns.Add("C13", Type.GetType("System.String"))
        dsCria.Tables(0).Columns.Add("C14", Type.GetType("System.String"))
        dsCria.Tables(0).Columns.Add("C15", Type.GetType("System.String"))

        Dim strReturn As String = Funcoes.Gerais.convertDStoAJAX(15, dsCria)

        Return strReturn
    End Function

    Protected Sub rbtPesqInicio_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles rbtPesqInicio.Init
        'Executado quando for trocado o tipo de pesquisa da tela para Inicio
        rbtPesqInicio.Attributes.Add("onClick", "Altera_TipoPesquisa('0')")
    End Sub

    Protected Sub rbtPesqQQParte_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles rbtPesqQQParte.Init
        'Executado quando for trocado o tipo de pesquisa da tela para QQParte
        rbtPesqQQParte.Attributes.Add("onClick", "Altera_TipoPesquisa('1')")
    End Sub
End Class
