var obj_Timer = null;
var bln_Timer = false;
var vwNr_NivelPath;

var Tini;
var Tfim;
var time_diff;
//1
function setTini(){
	Tini = new Date();
}
//2
function setTfim(){
	Tfim = new Date();
	time_diff = Tfim.getTime() - Tini.getTime();
}
//3
function getTdif(){
		
	var time_hour = Math.floor(time_diff / (1000 * 60 * 60)); 
	time_diff -= time_hour * (1000 * 60 * 60);
	var time_min = Math.floor(time_diff / (1000 * 60));
	time_diff -= time_min * (1000 * 60);
	var time_sec = Math.floor(time_diff / 1000);
		
	time_diff -= time_sec * 1000;
	var time_msec = Math.floor(time_diff);
		
	alert(time_hour + ":" + time_min + ":" + time_sec + ":" + time_msec)
	
	delete Tini;
	delete Tfim;
	delete time_hour;
	delete time_min;
	delete time_msec;
}
//4
function callShortcut(){
	if (parent.top.frm_rodape != null){
		
		var obj_div = document.getElementsByTagName("DIV");
		var qtGridsVisible = 0;
		var bln_GridVivible = false;
		for (var int_cont = 0; int_cont < obj_div.length;int_cont++){
			//Div tem que ter nome, estar vis�vel (style = "" ou block) e tem que conter pelo menos um iframe
			if (obj_div[int_cont].getAttribute("id") != "" && (obj_div[int_cont].style.display == "" || obj_div[int_cont].style.display == "block") && obj_div[int_cont].getElementsByTagName("IFRAME").length >= 1){
				bln_GridVivible = true;
				break;
			}
		}
		
		//Abre grid - Ctrl + Shift + G
		if (bln_GridVivible){
			var str_NameGrid = obj_div[int_cont].getElementsByTagName("IFRAME")[0].getAttribute("id")
			
			if (event.keyCode == 7){
				main(str_NameGrid + "_lst");
			}
		}
		//Pesquisa - Ctrl + Shift + P
		var sBtn = new String(parent.top.frm_rodape.getButton());
		if (sBtn.indexOf("P") != -1){
			if (event.keyCode == 16){
				main("qry");
			}
		}
		//Novo - Ctrl + Shift + N
		if (sBtn.indexOf("N") != -1){
			if (event.keyCode == 14){
				main("new");
			}
		}
		//Cancelar - Ctrl + Shift + esc
		if (sBtn.indexOf("X") != -1){
			
			if (event.keyCode == 27){
				main("ext");
			}
		}
		//Inserir - Ctrl + Shift + S
		if (sBtn.indexOf("S") != -1){
			if (event.keyCode == 19){
				main("ins");
			}
		}
	}
}

// Atualiza e retorna hora atual...
function timeAdd(int_Minutes)
{
	
	// Inicializa vari�veis...
	var obj_date    = new Date();
	var int_hours   = obj_date.getHours();
	var int_minutes = obj_date.getMinutes();
	
	// Atualiza valores do obj...
	int_minutes = int_minutes + (eval(int_Minutes));
	obj_date.setMinutes(int_minutes);
	
	// Atualiza valores das vari�veis e retorna nova data...
	int_hours   = obj_date.getHours(); int_minutes = obj_date.getMinutes(); delete obj_date;
	if(int_minutes < 10){int_minutes = "0" + int_minutes.toString();}
	if(int_hours < 10)  {int_hours = "0" + int_hours.toString();}
	return int_hours + ":" + int_minutes;

}

// Define modo de tela para Browse...
function browseMode(objForm)
{
	parent.top.frm_rodape.setButton("X"); //Bot�o cancelar...
	var tamForm = objForm.length; // Qntd de obj no form...
	var activeMode = (arguments[1] != null) ? arguments[1] : true; // Habilita ou des. objetos...
	for(var i=0; i < tamForm; i++){objForm.item(i).disabled = activeMode;} // Executa a��o...
}

function getHost()
{
	var str_Host, astr_Host, str_Host_Origem;
    
	if (opener != null) {
		str_Host = self.opener.parent.top.location.toString().toLowerCase();
		str_Host = substring(0,lastIndexOf("/"));
	}
	else {    	
		str_Host = parent.top.location.toString().toLowerCase();	
		str_Host_Origem = str_Host;
		astr_Host = str_Host.split("//");
		str_Host = (astr_Host[0] + "//");
		astr_Host = astr_Host[1].split("/");
		
		//Verifica se existe um diret�rio virtual.
		if (astr_Host[1].lastIndexOf("integra") != -1)
		{
			for (var iH = 0; iH < 2; iH++) {
				str_Host += (astr_Host[iH] + "/");
			}
		}
		else
		{
			for (var iH = 0; iH < 1; iH++) {
				str_Host += (astr_Host[iH] + "/");
			}
		}

		str_Host = str_Host.substring(0,(str_Host.length - 1));
	}
	return str_Host;
}

function Fu_TrocaSepDec(paValor,paSep)
{
	var vwSepTroca			= '';
	var vwValorRetorno		= '';
	


	if(paSep == '' || paSep == null)
	{
		paSep  =  '.'
	}
	
	
	if(paSep == '.')
	{
		vwSepTroca  =  ','
	}
	else
	{
		vwSepTroca  = '.'
	}
	vwValorRetorno  =  paValor.replace(vwSepTroca,paSep)
	
	return vwValorRetorno;
	
}

////////////////////////////////////////////////////////////////////////////////////////////////////
// Fun��o para atualizar Single Nodes,
// de uma string XML, e retorna a 
// string Atualizada. 
// Obs.: Altera propriedades somente
// dos XML's que estiverem dentro 
// da estrutura do integra.
//
// Explica��o dos par�metros
//
// paXMLString:  String XML que 
// dever� ser alterada.
//
// paPathNodes: Caminho dos nodes seleciona
// dos.
//
// paNodeAtu: nome do node que dever� 
// ser atualizado.
//
// paValorAtu: 
//
// paValorAtu: valor que ser� atribuido
// para os atributos value e server_value
// do node
//******************************************
function Fu_AtuaValueNodesXML(paXMLString, paPathNodes, paNodeAtu,paValorAtu)
{
	var vwobjXml = new ActiveXObject("MSXML2.DOMDocument");
	var vwNodes  = null; 
	var vwSNode  = null;
	vwobjXml.loadXML(paXMLString)
	
	if(vwobjXml.parseError  != 0)
	{
		alert('Erro ao tentar abrir o XML para atualiza��o de valores de Nodes!')
		return  ''
	}
	vwNodes  =  vwobjXml.selectNodes(paPathNodes); 
	if(vwNodes != null)
	{
		for(var vwi = 0;vwi<=vwNodes.length-1;vwi++)
		{
			vwSNode  =   vwNodes[vwi].selectSingleNode(paNodeAtu); 
			if(vwSNode!= null)
			{
				vwSNode.setAttribute('value',escape(paValorAtu));
				vwSNode.setAttribute('server_value',escape(paValorAtu));
			}
		}
	}
	return vwobjXml.xml;
}
///////////////////////////////////////////Fu_AtuaValueNodesXML//////////////////////////////
function Fu_SendReceXML(paXML,paPrc)
{
		var vwobj_XHttp = new ActiveXObject("Microsoft.XMLHTTP");
		vwobj_XHttp.open("POST",'./prc/' + paPrc, false);
		paXML = paXML.replace(/%20/g," ");
		vwobj_XHttp.send(paXML);
		while(vwobj_XHttp.readyState != 4)
		{
			continue;
		}
		var vwsResp = vwobj_XHttp.responseText;
		return vwsResp; 
}

function msgBoxG() 
{
		var sHost; 
		var asHost;
		var sMsg;
		var iImg;
		var iCont; 
		var iHeight;
		var sResp ;
		var iMsg;

		sHost = getHost();
		sMsg = (arguments[0] != null) ? arguments[0] : "";
		iImg = (arguments[1] != null) ? arguments[1] : -1;
		iImg = (isNaN(parseInt(iImg))) ? -1 : parseInt(iImg);
		
		var asFeatures = new Array();
		
		asFeatures[0] = sMsg;
		asFeatures[1] = iImg;
		iCont = 0;
		
		while(sMsg.indexOf("\n") != -1) 
		{
			sMsg = sMsg.replace("\n","");
			iCont++;
		}
		
		iCont = (1 + parseInt(((sMsg.length + (45 * iCont)) / 45)));
		iHeight = 155 + (8 * iCont);
		if (arguments[2] != null) 
		{
			for (iMsg = 2; iMsg < arguments.length; iMsg++) {
				if (arguments[iMsg] != null) {
					asFeatures[asFeatures.length] = arguments[iMsg];
				}
			}
		}
		else 
		{
			asFeatures[2] = "OK";
		}
		sResp = window.showModalDialog(sHost + "/includes/mensagem.asp",asFeatures,"dialogHeight:" + iHeight + "px;dialogWidth:350px;center:yes;help:no;resizable:no;status:no;scroll:no");
		if (sResp != null) 
		{
			if (sResp.toString() == "true") 
			{
				return true;
			}
			else if (sResp.toString() == "false") 
			{
				return false;
			}
			else 
			{
				return sResp.toString();
			}
		}
		else 
		{
			return null;
		}
}

//************FUNCOES DE APOIO AO ULTRACARGO JS************
function Fu_NoSubmit(paEvento)
{
	var tecla = event.keyCode;
	if(tecla ==13)
	{
		return false;
	} 
	else
	{
		return true; 
	}
}

//**************************************************
// Fun��o para Digita��o de PA
//**************************************************
function Fu_DigPA_keypress(paObj)
{
	var temp;
	var digito = paObj.value;
	
	if(event.keyCode < 47 || event.keyCode >=58 )
	{
		return false;
	}
	else if((event.keyCode == 47 && digito.search('/') != -1) || (event.keyCode == 47 && digito.length<1)){
			return false;
	}
	else if((digito.indexOf('/') == -1) && (digito.length >= 8) && (event.keyCode != 47) ){
		return false;
	}
	else if((digito.indexOf('/') != -1)){
		vwPos = digito.indexOf('/');
		
		if( digito.length > digito.substr(0,vwPos).length + 3 ){
			return false;
		}else{
			return true;		
		}
	}
	else{
		return true;
	}
}

function Fu_DigDI_keyup(pobj)
{
	var str_Data = (pobj != null) ? pobj.value : "";
	
	if (event.keyCode != 8) {
		var int_Data = str_Data.length;
		if (int_Data > 14)
		{
		  pobj.value = str_Data.substring(0, 14);
		  event.returnValue = false;
		  return;
		}  
		
		str_Data = str_Data.replace("-","");
		
		int_Data = str_Data.length;
		var int_Ini = (int_Data < 2) ? 1 : 2;
		var int_Meio = (int_Data < 10) ? 9 : 10;
		var int_Fim = 11;
		
		var str_Ini = str_Data.substring(0, int_Ini);
		var str_Meio = str_Data.substring(3,int_Meio);
		var str_Fim = str_Data.substring(int_Meio, int_Fim);
		
		str_Data = str_Ini;
		if (int_Data >= 2) {
			str_Data += "/";
		}
		
		str_Data += str_Meio;
		if (int_Data >= 10) {
			str_Data += "-" ;
		}
		
		str_Fim = str_Fim.replace("-","");
		str_Data += str_Fim;
		pobj.value = str_Data;
	}
	
	event.returnValue = false;
}

function onlyNum(){
	
	if ((event.keyCode < 48 || event.keyCode > 57) && event.keyCode != 45){
		event.cancelBubble = true;
		event.returnValue = false;
	}
}

//**************************************************
// Fun��es para Digita��o e Valida��o de Datas 
//**************************************************
function Fu_DigData_keypress(paObj){

	var data   = paObj.value;
	var mydata = '';
	var vwPos; 
	var vwMes;
	var vwPosBarDia;
	var vwPosBarMes; 
	mydata = mydata + data;
	
	if(event.keyCode <= 47 || event.keyCode >=58 ){
		return false;
	}
	
	//Dia
	if (mydata.length == 2){
		vwPos  =  mydata.indexOf('/');
		if(vwPos == 1){
			paObj.value  =  mydata.substr(0,vwPos);
			return;
		}
		if(parseInt(mydata) > 31){
			paObj.value  =  '';
			return;
		}
		paObj.value = mydata + '/'; 
		return;
	}
              
	if (mydata.length == 5){
		vwPos  =  mydata.indexOf('/');
		vwMes  =  mydata.substr(vwPos+1,2);
				
		if(vwMes.length != 2){
			paObj.value  =  mydata.substr(0,vwPos+1);
			return;
		} 
				
		if(parseInt(vwMes) > 12 ){
			paObj.value  =  mydata.substr(0,vwPos+1);
			return;
		}
				
		vwPosBarDia  = mydata.indexOf('/');
		vwPosBarMes  = mydata.lastIndexOf('/');
				
		if (vwPosBarMes == vwPosBarDia){
			vwPosBarMes  = mydata.length  -vwPosBarDia;
		}
		vwMes =     mydata.substr(vwPosBarDia+1,  vwPosBarMes-1);
		vwPos =  vwMes.indexOf('/');
		if(vwPos != -1){
			vwMes  = vwMes.substr(0,vwPos);
			paObj.value  = paObj.value.substr(0,paObj.value.length-1);
		}
		if(vwMes.length == 2){
			paObj.value = mydata + '/';
		}
		return;
	}
	//Verifica se a quantidade de caracteres informados para o mes est� correta
	if (mydata.length >= 5){
		vwPosBarDia  = mydata.indexOf('/');
		vwPosBarMes  = mydata.lastIndexOf('/');
		vwMes =     mydata.substr(vwPosBarDia+1,  (vwPosBarMes - vwPosBarDia)-1);
		if(vwMes.length > 2){
			paObj.value  =  mydata.substr(0,vwPosBarDia+1);
			return;
		}else{
			if(vwMes.length == 1){
				paObj.value  =  mydata.substr(0,vwPosBarDia+2);
				return;
			}
		}
		
		if(parseInt(vwMes) > 12 ){
			paObj.value  =  mydata.substr(0,vwPosBarDia+1);
			return;
		}
	}
}

function Fu_FormataData_keyup(paObj)
{
	var data   = paObj.value;
	var mydata = '';
	var vwPos; 
	var vwMes;
	var vwPosBarDia;
	var vwPosBarMes; 
	mydata = mydata + data;
              
	if (mydata.length == 2)//Dia
	{
		vwPos  =  mydata.indexOf('/');
		if(vwPos == 1)
		{
			paObj.value  =  mydata.substr(0,vwPos);
			return;
		}
		if(parseInt(mydata) > 31)
		{
			paObj.value  =  '';
			return;
		}
		paObj.value = mydata + '/'; 
		return;
	}
              
	if (mydata.length == 5)
	{
		vwPos  =  mydata.indexOf('/');
		vwMes  =  mydata.substr(vwPos+1,2);
				
		if(vwMes.length != 2)
		{
			paObj.value  =  mydata.substr(0,vwPos+1);
			return;
		} 
				
		if(parseInt(vwMes) > 12 )
		{
			paObj.value  =  mydata.substr(0,vwPos+1);
			return;
		}
				
		vwPosBarDia  = mydata.indexOf('/');
		vwPosBarMes  = mydata.lastIndexOf('/');
				
		if (vwPosBarMes == vwPosBarDia)
		{
			vwPosBarMes  = mydata.length  -vwPosBarDia;
		}
		vwMes =     mydata.substr(vwPosBarDia+1,  vwPosBarMes-1);
		vwPos =  vwMes.indexOf('/');
		if(vwPos != -1)
		{
			vwMes  = vwMes.substr(0,vwPos);
			paObj.value  = paObj.value.substr(0,paObj.value.length-1);
		}
		if(vwMes.length == 2)
		{
			paObj.value = mydata + '/';
		}
		return;
	}
	//Verifica se a quantidade de caracteres informados para o mes est� correta
	if (mydata.length >= 5)
	{
		vwPosBarDia  = mydata.indexOf('/');
		vwPosBarMes  = mydata.lastIndexOf('/');
		vwMes =     mydata.substr(vwPosBarDia+1,  (vwPosBarMes - vwPosBarDia)-1);
		if(vwMes.length > 2)
		{
			paObj.value  =  mydata.substr(0,vwPosBarDia+1);
			return;
		}
		else
		{
			if(vwMes.length == 1)
			{
				paObj.value  =  mydata.substr(0,vwPosBarDia+2);
				return;
			}
		}
		
		if(parseInt(vwMes) > 12 )
		{
			paObj.value  =  mydata.substr(0,vwPosBarDia+1);
			return;
		}
	}
}

function Fu_ValidaData_blur(paObj) 
{
	var vwDataValor   =  trim(paObj.value);
	if(vwDataValor == '')
	{
		return; 
	}
	var vwPosBarDia  = vwDataValor.indexOf('/');
	var vwPosBarMes  = vwDataValor.lastIndexOf('/');
		
	var dia = vwDataValor.substr(0,vwPosBarDia);
	var mes = vwDataValor.substr(vwPosBarDia +1,(vwPosBarMes - vwPosBarDia)-1); 
	var ano = vwDataValor.substr(vwPosBarMes +1,vwDataValor.lenght); 
	if(ano.length == 0)
	{
		msgBoxG('Ano informado � inv�lido!');
		paObj.focus(); 
		return;
	}

	if(ano.length < 4)
	{
		if(ano.length == 3 || ano.length == 1)
		{
			msgBoxG('O Ano informado � inv�lido!');
			paObj.focus(); 
			return; 
		}
		if(ano.length == 2)
		{
			if(parseInt(ano) >= 0 && parseInt(ano) <= 50)
			{
				paObj.value = dia + '/' + mes + '/' + '20' + ano; 
				ano  =  '20' + ano;
			}
		
			if(parseInt(ano) >= 51 && parseInt(ano) <= 99)
			{
				paObj.value = dia + '/' + mes + '/' + '19' + ano;
				ano  =  '19' + ano;
			}
		} 
	}
	situacao = ""; 
	// verifica o dia valido para cada mes 
	if ((dia < 01)||(dia < 01 || dia > 30) && (  mes == 04 || mes == 06 || mes == 09 || mes == 11 ) || dia > 31) 
	{ 
		situacao = "falsa"; 
	} 

	// verifica se o mes e valido 
	if (mes < 01 || mes > 12 ) 
	{ 
		situacao = "falsa"; 
	} 

	// verifica se e ano bissexto 
	if (mes == 2 && ( dia < 01 || dia > 29 || ( dia > 28 && (parseInt(ano / 4) != ano / 4)))) 
	{ 
		situacao = "falsa"; 
	} 

	if (paObj.value == "") 
	{ 
		situacao = "falsa"; 
	} 

	if (situacao == "falsa")
	{ 
		msgBoxG("Data inv�lida!");
		paObj.value= ''; 
		paObj.focus();
		return;  
	} 
}
//**************************************************

function Fu_CarregaFiltroFromIns(paFormOrigem,paFormDestino)
{

	if(paFormOrigem =='' || paFormOrigem ==null)
	{
		paFormOrigem = 'frm_detalhe';
	}
	if(paFormDestino =='' || paFormDestino ==null)
	{
		paFormDestino = 'frm_filtro';
	}

	var objOrigem	= document.getElementById(paFormOrigem); 
	var objDestino	= document.getElementById(paFormDestino);
	var vwAtributo; 
	var vwValor; 
	//Varre os objetos de origem tentando encontrar a tag filtro_ins
	for(var i = 0; i<= objOrigem.length-1;i++)
	{
		vwAtributo  = objOrigem[i].getAttribute('filtro_ins');
		vwValor		= objOrigem[i].value;
		
		if(vwAtributo != null && vwAtributo != '')
		{
			for(var j = 0; j<= objDestino.length-1;j++)
			{
				if(objDestino[j].id == vwAtributo)
				{
					//************************************************************************************
					// De acordo com o tipo de objeto de destino, o valor � populado
					//************************************************************************************
					if(objDestino[j].type == 'text' || objDestino[j].type == 'hidden') 
					{
						objDestino[j].value  = vwValor; 
					} 
					
					if(objDestino[j].type == 'select-one')
					{
						for(var k = 0;k<=objDestino[j].length -1; k++)
						{
							
							if(objDestino[j][k].value == vwValor)
							{
								objDestino[j].selectedIndex = k
							}  
						}
					}
				} 
			} 
		} 
	}
}

function Fu_LimpaPaginador(paTabela)
{
		obj_Ultra.createTableFooter_ini(paTabela);
}

function Fu_ClearLnkHid(paForm, paObjeto,paSempre)
{
	var vwObjetos	=  document.getElementById(paForm);
	var vwObjetoID	=  paObjeto.id;
	
	
	
	for(var i = 0; i <= vwObjetos.length-1;i++)
	{
		if(vwObjetos[i].linkhidden != undefined)
		{
			if(vwObjetos[i].linkhidden == vwObjetoID)
			{
				if(paSempre == null || paSempre == '')
				{
					vwObjetos[i].value  = ''; 
				}
				else
				{
					vwObjetos[i].value  = ''; 
				}
			}
		}
	}
}
//************************************************
//Fun��o para digita��o de Valores com decimais
//************************************************
function maskDec_TypeBlur(paObjeto,paNrInteiros, paNrDecimais,paSepDecimais)
{
	var vwString = new String();
	var vwPos;
	vwString = paObjeto.value;
	if(vwString == '')
	{
		return true; 
	} 
	
	vwPos  =  vwString.indexOf(paSepDecimais ,0);
	if(vwPos == -1) // N�o Possui Zeros, completa com decimais
	{
		paObjeto.value = paObjeto.value + paSepDecimais;
		for(var i = 0;i<=parseInt(paNrDecimais)-1;i++)
		{
			paObjeto.value = paObjeto.value  + '0';
		}
	}
	else
	{
		var vwInt;
		var vwDec;
		var vwValor  = new String();  
		vwValor = paObjeto.value;
		vwInt = vwValor.substr(0,vwPos); 
		vwDec = vwValor.substr(vwPos+1,vwValor.length);
		vwInt
		for(i = 0 ; i<= parseInt(paNrDecimais) -1;i++)
		{
			vwDec = vwDec  +  '0';
		}
		paObjeto.value  = vwInt + paSepDecimais  + vwDec.substr(0,paNrDecimais);
	} 
}

function maskDec_TypeKeyUp(paObjeto,paNrInteiros, paNrDecimais,paSepDecimais)
{
	var vwString  = new String() ;
	vwString = paObjeto.value;
	
	
	var vwPos1 = vwString.indexOf(paSepDecimais + paSepDecimais,0);
	if(vwPos1 != -1)
	{
		var vwStringSep = new String(); 
		vwStringSep =   paObjeto.value; 
		vwStringSep = vwStringSep.substr(0,vwStringSep.length-1);  
		paObjeto.value = vwStringSep;
	}
	
	var vwPos  =  vwString.indexOf(paSepDecimais ,0);
	var vwDec; 
	var vwInt;
	if(vwPos != -1)
	{
		vwDec  =  vwString.substr(vwPos+1,vwString.length);
		if(vwDec.length > parseInt(paNrDecimais)) // Se estourar o numero de decimais, n�o deixa digitar
		{
			vwInt  =  vwString.substr(0,vwPos);
			vwDec  =  vwString.substr(vwPos+1,paNrDecimais);
			paObjeto.value  =   vwInt + paSepDecimais + vwDec;
		}
		
		var vwStringTemp  = vwString.substr(0,vwPos);
		if(vwStringTemp.length > parseInt(paNrInteiros))
		{
			vwInt  =  vwString.substr(0,vwPos-1);
			vwDec  =  vwString.substr(vwPos+1,paNrDecimais);
			paObjeto.value  =   vwInt + paSepDecimais  + vwDec;
		}
	}
}

function maskDec_Type(paEvento,paObjeto,paNrInteiros, paNrDecimais,paSepDecimais)
{
	var tecla = event.keyCode;
	var vwString = new String();
	var vwInt;
	var vwPos; 
	var vwDec; 
	vwString  = paObjeto.value;
	if (paSepDecimais != ',' && paSepDecimais != '.')
	{
		alert('O Separador de Decimal informado � inv�lido.')
	} 
	
	if((tecla > 47 && tecla < 58) || (tecla == 44 || tecla == 46)) 
	{
		if(tecla == 44 && paSepDecimais=='.')
		{
			return false; 
		}
		
		if(tecla == 46 && paSepDecimais==',')
		{
			return false; 
		}
	
		if(tecla == 46 || tecla == 44)  // Verifica se o separador j� foi informado.
		{
			vwPos  =  vwString.indexOf(paSepDecimais,0);
			if(vwPos != -1)
			{
				return false;
			} 
		}
		
		//Verifica o N�mero de Inteiros
		if(vwString.length == parseInt(paNrInteiros))
		{
			vwPos  =  vwString.indexOf(paSepDecimais ,0);
			if(vwPos == -1)
			{
				paObjeto.value   = paObjeto.value  + paSepDecimais;
			}
		}
		else
		{
			vwPos  =  vwString.indexOf(paSepDecimais ,0);
			if(vwPos == -1)
			{
				if(vwString.length > parseInt(paNrInteiros))
				{
					return false;
				}
			} 
			else
			{
				var vwStringTemp  = vwString.substr(0,vwPos);
				if(vwStringTemp.length > parseInt(paNrInteiros))
				{
					return false;
				}
			} 
		} 
		//Verifica a quantidade de decimais informados
		vwPos  =  vwString.indexOf(paSepDecimais ,0);
		if(vwPos != -1)
		{
			vwDec  =  vwString.substr(vwPos+1,vwString.length);
			if(vwDec.length > parseInt(paNrDecimais)) // Se estourar o numero de decimais, n�o deixa digitar
			{
				return false;
			}
		}
		return true;
	}
	else
	{
		return false;
	}
}
//***************************************************
// Fun��o para informar valores com decimais
// Obs.: Esta fun��o foi criada para manter 
// compatibilidade com o tipo lng j� existente
//***************************************************
function maskDec_TypeBlur_lng(paObjeto,paNrInteiros, paNrDecimais,paSepDecimais)
{
	var vwString = new String();
	var vwPos;
	vwString = paObjeto.value;
	if(vwString == '')
	{
		return true; 
	} 
	
	vwPos  =  vwString.indexOf(paSepDecimais ,0);
	if(vwPos == -1) // N�o Possui Zeros, completa com decimais
	{
		paObjeto.value = paObjeto.value + paSepDecimais;
		for(var i = 0;i<=parseInt(paNrDecimais)-1;i++)
		{
			paObjeto.value = paObjeto.value  + '0';
		}
	}
	else
	{
		var vwInt;
		var vwDec;
		var vwValor  = new String();  
		vwValor = paObjeto.value;
		vwInt = vwValor.substr(0,vwPos); 
		vwDec = vwValor.substr(vwPos+1,vwValor.length);
		for(i = 0 ; i<= parseInt(paNrDecimais) -1;i++)
		{
			vwDec = vwDec  +  '0';
		}
		if(parseInt(paNrDecimais)!= 0)
		{
			 paObjeto.value  = vwInt + paSepDecimais  + vwDec.substr(0,paNrDecimais);
		}
	} 
	
	var vwFirstChar = paObjeto.value.substr(0,1);
	paObjeto.value = (vwFirstChar == paSepDecimais) ? "0" + paObjeto.value : paObjeto.value;
	
}

function maskDec_TypeKeyUp_lng(paObjeto,paNrInteiros, paNrDecimais,paSepDecimais)
{
	var vwString  = new String() ;
	vwString = paObjeto.value;
	
	
	var vwPos1 = vwString.indexOf(paSepDecimais + paSepDecimais,0);
	if(vwPos1 != -1)
	{
		var vwStringSep = new String(); 
		vwStringSep =   paObjeto.value; 
		vwStringSep = vwStringSep.substr(0,vwStringSep.length-1);  
		paObjeto.value = vwStringSep;
	}
	
	var vwPos  =  vwString.indexOf(paSepDecimais ,0);
	var vwDec; 
	var vwInt;
	if(vwPos != -1)
	{
		vwDec  =  vwString.substr(vwPos+1,vwString.length);
		if(vwDec.length > parseInt(paNrDecimais)) // Se estourar o numero de decimais, n�o deixa digitar
		{
			vwInt  =  vwString.substr(0,vwPos);
			vwDec  =  vwString.substr(vwPos+1,paNrDecimais);
			paObjeto.value  =   vwInt + paSepDecimais + vwDec;
		}
		
		var vwStringTemp  = vwString.substr(0,vwPos);
		if(vwStringTemp.length > parseInt(paNrInteiros))
		{
			vwInt  =  vwString.substr(0,vwPos-1);
			vwDec  =  vwString.substr(vwPos+1,paNrDecimais);
			paObjeto.value  =   vwInt + paSepDecimais  + vwDec;
		}
	}
}

function maskDec_Type_lng(paEvento,paObjeto,paNrInteiros, paNrDecimais,paSepDecimais,pstr_Escala)
{
	var tecla = event.keyCode;
	var vwString = new String();
	var vwInt;
	var vwPos; 
	var vwDec; 
	
	this.str_Escala = (pstr_Escala != null) ? pstr_Escala : "" ;
	
	vwString  = paObjeto.value;
	if (paSepDecimais != ',' && paSepDecimais != '.')
	{
		alert('O Separador de Decimal informado � inv�lido.')
	} 
	
	if((tecla > 47 && tecla < 58) || (tecla == 44 || tecla == 46 || tecla == 45)) 
	{
		if(tecla == 44 && paSepDecimais=='.')
		{
			return false; 
		}
		
		if(tecla == 46 && paSepDecimais==',')
		{
			return false; 
		}
		
		if (this.str_Escala != "NP" && tecla == 45){
			return false;
		}
		//alert("tecla : " + tecla + "\nstr_Escala : " + this.str_Escala + "\nvalue : " + paObjeto.value + "\n" + paObjeto.value.indexOf("-") + "\n" + paObjeto.value.length)
		if (tecla == 45 && this.str_Escala == "NP" && (paObjeto.value.indexOf("-") != -1 || paObjeto.value.length != 0)){
			return false;
		}
		
		if(tecla == 46 || tecla == 44)  // Verifica se o separador j� foi informado.
		{
			vwPos  =  vwString.indexOf(paSepDecimais,0);
			if(vwPos != -1)
			{
				return false;
			} 
		}
		
		//Verifica o N�mero de Inteiros
		if(vwString.length == parseInt(paNrInteiros))
		{
			vwPos  =  vwString.indexOf(paSepDecimais ,0);
			if(vwPos == -1)
			{
				paObjeto.value   = paObjeto.value  + paSepDecimais;
			}
		}
		else
		{
			vwPos  =  vwString.indexOf(paSepDecimais ,0);
			if(vwPos == -1)
			{
				if(vwString.length > parseInt(paNrInteiros))
				{
					return false;
				}
			} 
			else
			{
				var vwStringTemp  = vwString.substr(0,vwPos);
				if(vwStringTemp.length > parseInt(paNrInteiros))
				{
					return false;
				}
			} 
		} 
		//Verifica a quantidade de decimais informados
		vwPos  =  vwString.indexOf(paSepDecimais ,0);
		if(vwPos != -1)
		{
			vwDec  =  vwString.substr(vwPos+1,vwString.length);
			if(vwDec.length > parseInt(paNrDecimais)) // Se estourar o numero de decimais, n�o deixa digitar
			{
				return false;
			}
		}
		return true;
	}
	else
	{
		return false;
	}
}

//************************************************
//Fun��o para retornar valores de um XML a partir 
//de um XML e N� informado. 
//************************************************
function Fu_AutoCompletar(paObject,paXml,paNo)
{
	//***************************************************
	//Defini��o da Funcao: Esta fun��o tem a finalidade
	//de preencher a propriedade valor(text,hidden),
	//a partir de um XML v�lido informado.
	//
	//Explica��o dos par�metros:
	//-----------------------------------------------
	//paObject: Objeto a ser populado
	//-----------------------------------------------
	//paXml: XML que contem o valor que vai popular
	//Obs.: Ap�s a execu��o do m�todo obj_ultra.send,
	//o mesmo sempre guarda o ultimo Xml na pripriedade
	//obj_ultra.Xml();
	//-----------------------------------------------
	//paNo: Nome do n� que contem o valor
	//****************************************************
	var objXML  =  new ActiveXObject("MSXML2.FreeThreadedDOMDocument");
	var objNodes
	var objFill
	objXML.loadXML(paXml)
	if(objXML.parseError != 0) // Erro  
	{
		alert('Erro na leitura do XML informado.')
		return false;
	}
	//Seleciona o conjunto Row
	objNodes  = objXML.selectNodes("root/*/" + paNo)
	if(objNodes.length != 1) 
	{
		return false;
	}
	if(objNodes[0].getAttribute("value") != null) 
	{
		// Verifica se o objeto existe
		if(paObject != undefined)
		{
			paObject.value  =  unescape(objNodes[0].getAttribute("value"));
			
		} 
	}
	else
	{
		if(paObject != undefined)
		{
			paObject.value  =  '';
		}
	}
}

function checkCPFCNPJ(pobj_text){
	var str_dac = ""; //digito de auto-confer�ncia
	var str_number = "";
	var bln_check = false;
	
	try{
		if (pobj_text.value == "") return false;		
		if (pobj_text.type == undefined) return false;
		
		if (!validarCPFCNPJ(pobj_text.value)){
			msgBox("CNPJ Raiz / CPF � inv�lido\n");
			return false;
		}
		
		str_number = getNumbers(pobj_text.value);
		
		if (str_number == "") return false;
		if (arguments[1] == "CPF"){
			if (str_number.length != 11){
				msgBox("CPF � inv�lido\n");
				//pobj_text.focus();
				return false;
			}	
		}else if (arguments[1] == "CNPJ"){
			if (str_number.length != 14){			
				msgBox("CNPJ � inv�lido\n");
				//pobj_text.focus();
				return false;
			}	
		}else{
			if (str_number.length < 11 || str_number.length > 14){			
				msgBox("CNPJ Raiz / CPF � inv�lido\n");
				//pobj_text.focus();
				return false;
			}			
			if (str_number.length > 11 && str_number.length < 14){			
				msgBox("CNPJ Raiz / CPF � inv�lido\n");
				//pobj_text.focus();
				return false;
			}			
		}	
		
		str_dac = str_number.substr(str_number.length - 2, 2);
		str_number = str_number.substr(0, str_number.length - 2);
		
		if (str_number == "000000000"){
			msgBox("CNPJ Raiz / CPF � inv�lido\n");
			//pobj_text.focus();
			return false;
		}
		bln_check = isCPF_CNPJ(str_number, str_dac);
		
		if (!bln_check) {
			if (arguments[1] == undefined){
				msgBox("CNPJ Raiz / CPF � inv�lido\n");				
			}else{
				msgBox(arguments[1] + " � inv�lido\n");				
			}
			//pobj_text.focus();
			return false;
		}
		return true;
	}
	catch(obj_Error){
		showMessageError("checkCPFCNPJ", obj_Error);
	}
}
function isCPF_CNPJ(pstr_Number, pstr_Dac){
	var dbl_Soma = 0;
	var int_fator = 1;
	var int_limFator;
	var str_ConDac = "";	
	var int_digito = 0;
	int_limFator = pstr_Number.length > 9 ? 9: 11;
	try{
		// verifica��o do primeiro digito do DAC		
		for (var int_cont = pstr_Number.length-1; int_cont >= 0; int_cont--){
			int_fator = (int_fator == int_limFator) ? 2: ++int_fator;
			dbl_Soma += parseInt(int_fator * Number(pstr_Number.substr(int_cont, 1)));
		}		
		dbl_Soma /= 11;
		int_digito = Math.round(11 * (dbl_Soma - Math.floor(dbl_Soma)));
		int_digito = int_digito > 1 ? 11 - int_digito: 0;
		// uma vez calculado o primeiro digito do dac,
		// concatena-o a vari�vel de verifica��o str_ConDac
		str_ConDac = int_digito.toString();
		// verifica��o do segundo digitio do DAC
		// primeiro, concatena-se o primeiro digito encontrado
		// ao par�metro pstr_Number.
		pstr_Number = pstr_Number.concat(int_digito);
		int_fator = 1;
		dbl_Soma = 0;
		for (var int_cont = pstr_Number.length-1; int_cont >= 0; int_cont--){
			int_fator = (int_fator == int_limFator) ? 2: ++int_fator;
			dbl_Soma += parseInt(int_fator * Number(pstr_Number.substr(int_cont, 1)));
		}		
		dbl_Soma /= 11;
		int_digito = Math.round(11 * (dbl_Soma - Math.floor(dbl_Soma)));
		int_digito = int_digito > 1 ? 11 - int_digito: 0;
		// uma vez calculado o segundo digito do dac,
		// concatena-o a vari�vel de verifica��o str_ConDac
		str_ConDac = str_ConDac.concat(int_digito);
		return (pstr_Dac == str_ConDac);
	}
	catch(obj_Error){
		showMessageError("isCPF", obj_Error);
	}
}

function validarCPFCNPJ(pstr_Value){
	try{
		if(pstr_Value == null || 
		   pstr_Value == '' || 
		   pstr_Value == 'undefined') return true;
	
		var str_ValPossiveis = "0123456789.-/";
		for (var int_cont = 0; int_cont < pstr_Value.length; int_cont++){			
			if (str_ValPossiveis.indexOf(pstr_Value.substr(int_cont, 1)) == -1){	
				return false;
				break;
			}
		}
		return true;
	}
	catch(obj_Error){
		showMessageError("validarCPFCNPJ", obj_Error);
	}
}

function getNumbers(pstr_Value){
	try{
		if(pstr_Value == null || 
		   pstr_Value == '' || 
		   pstr_Value == 'undefined') return '';
	
		var str_num = "0123456789";
		var str_buffer = "";
		for (var int_cont = 0; int_cont < pstr_Value.length; int_cont++){			
			if (str_num.indexOf(pstr_Value.substr(int_cont, 1)) > -1){				
				str_buffer += pstr_Value.substr(int_cont, 1);
			}
		}
		return str_buffer;
	}
	catch(obj_Error){
		showMessageError("getNumbers", obj_Error);
	}
}

function onlyNumeric(pobj_Field,plng_Integer,plng_Decimal,pstr_Decimal,pstr_Escala) { //,pstr_LatLong) {
  try
  {
    this.bln_Verify = true;
    this.bln_IsDecimal = (plng_Decimal != null) ? (plng_Decimal > 0) ? true : false : false;
    this.str_Decimal = (pstr_Decimal != null) ? pstr_Decimal : "," ;
	
    this.str_Escala = (pstr_Escala != null) ? pstr_Escala : "" ;
    
    if (this.bln_Verify)
    {
	  
	  if (event.keyCode >= 48 && event.keyCode <= 57) 
      {
		this.bln_Verify = false;
	  }
      //Aceita virgula
	  if (event.keyCode == 45 && this.str_Escala == "NP" && pobj_Field.value.indexOf("-") == -1){
		this.bln_Verify = false;
	  }
    }
    
    if (this.bln_IsDecimal)
    {
      if (event.keyCode == this.str_Decimal.charCodeAt())
      {
		if (pobj_Field.getAttribute("value").indexOf(this.str_Decimal) == -1) 
		{
			this.bln_Verify = false;
		}   
      }
    }
    
    if (this.bln_Verify)
    {
      event.cancelBubble = true;
      event.returnValue = false;
    }
  }
  catch(obj_Exception) {
    exception(obj_Exception,"General[onlyNumeric]");
  }
  finally {
    this.bln_Verify = null;
    this.bln_IsDecimal = null;
    this.str_Decimal = null;
    this.bln_Verify = null;
  }
}

function validarSinalNeg_TypeKeyUp(pobjField)
{
	if(event.keyCode == 189 && pobjField.value.substr(0,1) != "-"){
		pobjField.value = pobjField.value.substr(0,pobjField.value.length - 1);
	}
}

function onlyInteiros(pobj_Field)
{
      if (event.keyCode < 48 || event.keyCode > 57) 
      {
        return false;
      }
}

function getCurrentDate(){
  try{
    //obtendo data corrente    
    var obj_Data, str_Data = "";           
    obj_Data = new Date();
    str_Data += ((obj_Data.getDate() + "/").length > 2) ? obj_Data.getDate() + "/" : "0" + obj_Data.getDate() + "/" ;
��� str_Data += (((obj_Data.getMonth()+1) + "/").length > 2) ? (obj_Data.getMonth()+1) + "/" : "0" + (obj_Data.getMonth()+1) + "/" ;
��� str_Data += obj_Data.getYear();    
    return str_Data;
  } 
  catch(obj_Exception) {
    exception(obj_Exception,"General[maskNumeric]");
  }
  finally {
    obj_Data = null;
    str_Data = null;
  }
}

function verificarDataInicialMaiorCnh(dataInicial,dataFinal){
  try {
   
    var str_DataInicial, str_DataFinal, str_Data=false;           
    var str_Dia, arr_Data, str_Mes, str_Ano, str_DiaTotal, str_DataMot        
    var str_ultimoDiaMes;
    
    str_DataMot = dataInicial;
	arr_Data = str_DataMot.split("/");
	
	str_Mes			 = arr_Data[1];
	str_ultimoDiaMes = verificaUltimoDiaMes(str_Mes);
	str_Ano			 = arr_Data[2];
			
	str_Dia		 = arr_Data[0];	
	str_Dia		 = parseInt(str_Dia);
	str_DiaTotal = str_Dia;	
	
	for (var i=0; i < str_ultimoDiaMes; i++) {		
		if (str_DiaTotal == 30) {
			var str_Sobra = parseInt(str_ultimoDiaMes) - parseInt(i);			
			if (str_Sobra == 0) {
				str_Dia = "01";							
				} else {
				str_Dia = str_Sobra;
				}
				
			str_Mes = parseInt(str_Mes) + 1;
			if (str_Mes == 13) {
				str_Mes = "01";
				str_Ano = parseInt(str_Ano) + 1;
				}						
			break;
			} else {
			str_DiaTotal = str_DiaTotal + 1;			
			}		
		}//for (var i=0; i < str_ultimoDiaMes; i++) {
		
	if (str_Dia.toString().length == 1) {		
		str_Dia = "0" + str_Dia;
		}	
	
	str_DataMot = str_Dia + "/" + str_Mes + "/" + str_Ano;		  
    str_DataMot = new Date(ANSIDate(str_DataMot));            
    str_DataFinal = new Date(ANSIDate(dataFinal));

    if (str_DataMot > str_DataFinal) {    
		str_Data=true;
		}	
    return str_Data;
  } 
    catch(obj_Exception) {
		exception(obj_Exception,"General[data error]");		
  }
  finally {
  }
}

function verificarDataInicialMaior(dataInicial,dataFinal) {
  try {
    
    var str_DataInicial, str_DataFinal, str_Data=false;           
    str_DataInicial = new Date(ANSIDate(dataInicial));

    str_DataFinal = new Date(ANSIDate(dataFinal));
	
    if (str_DataInicial > str_DataFinal)
    {
	str_Data=true;
    }	
    return str_Data;
  } 
    catch(obj_Exception) {
		exception(obj_Exception,"General[data error]");		
  }
  finally {
  }
}

function verificaUltimoDiaMes(mes) {	
	var dataAtual = new Date();
	var anoAtual  = dataAtual.getYear();
	var anoBissexto = parseInt(anoAtual) / 4;		
    var resto = anoBissexto.toString().split(".");	
	var restante = resto[1];				
	switch (mes) {
		case "2":		
			if (restante != undefined) {				
				return "28";
				} else {					
				return "29";
				}
			break;	
		case "4,6,9,11":			
			return "30";
			break;	
		default:		
			return "31";
			break;								
		}	
	}

function ANSIDate(pstr_Data){
  try{
	var arr_Data = pstr_Data;
	arr_Data = arr_Data.split("/");
	return arr_Data[2] + "/" + arr_Data[1] + "/" + arr_Data[0];
		
  }
    catch(obj_Exception) {
		exception(obj_Exception,"General[verificarDataInicialMaior]");		
  }
  finally {
  }
}

function FORMA(num){
Resp=""
if(num<10){
Resp="0"
}
Resp=Resp+num
return Resp
}
function getCurrentTime(){
agora=new Date();
hora=agora.getHours();
minu=agora.getMinutes();
texto=FORMA(hora)+ ":" + FORMA(minu);
return texto;
}


function maskNumeric(pobj_Field,plng_Integer,plng_Decimal,pstr_Decimal)
{
  try
  {
    this.bln_IsDecimal = (plng_Decimal != null) ? (plng_Decimal > 0) ? true : false : false;
    //this.str_Decimal = (pstr_Decimal != null) ? pstr_Decimal : "," ;
    this.str_Decimal = (plng_Decimal = 0) ? pstr_Decimal : "," ;
    
    this.str_AcceptChr = "0123456789" + this.str_Decimal;
    
    this.str_FieldValue = "";
    this.str_NewValue = "";
    
    if (pobj_Field.getAttribute("value") != "")
    {
      for (var int_C = 0; int_C < pobj_Field.getAttribute("value").length; int_C++)
      {
        if (this.str_AcceptChr.indexOf(pobj_Field.getAttribute("value").charAt(int_C)) != -1)
        {
          this.str_FieldValue += pobj_Field.getAttribute("value").charAt(int_C);
        }
      }
    }
	
    /*
    if (this.str_FieldValue.indexOf(this.str_Decimal) != -1)
    {
      this.str_FieldValue = this.str_FieldValue.substring(
			(this.str_FieldValue.indexOf(this.str_Decimal) - plng_Integer),this.str_FieldValue.indexOf(this.str_Decimal))
			 + this.str_Decimal + this.str_FieldValue.substring(
					(this.str_FieldValue.indexOf(this.str_Decimal) + 1),(this.str_FieldValue.indexOf(this.str_Decimal) + 1) + plng_Decimal);
					
      if (this.str_FieldValue.charAt((this.str_FieldValue.length - 1)) == ",")
      {
        this.str_FieldValue = this.str_FieldValue.substring(0,(this.str_FieldValue.length - 1));
      }
    }
    else {
      if (!this.bln_IsDecimal) {
        this.str_FieldValue = this.str_FieldValue.substring(0,plng_Integer);
      }
      else
      {
        this.str_FieldValue = this.str_FieldValue.substring((this.str_FieldValue.length - plng_Integer),this.str_FieldValue.length);
      }
    }
    */
      
    //pobj_Field.setAttribute("value",this.str_FieldValue);
  }
  catch(obj_Exception) {
    exception(obj_Exception,"General[maskNumeric]");
  }
  finally {
    this.bln_IsDecimal = null;
    this.str_Decimal = null;
    this.str_AcceptChr = null;
    this.str_FieldValue = null;
    this.str_NewValue = null;
  }
}

function onlyDate(pobj_Field) {
  try {
    if (event.keyCode < 47 || event.keyCode > 57) {
      event.cancelBubble = true;
      event.returnValue = false;
    }
  }
  catch(obj_Exception) {
    exception(obj_Exception,"General[onlyDate]");
  }
}

function maskDate(pobj_Field) {
  try {
    if (pobj_Field.value.split("/").length > 2) {
      this.str_Date = new Date(pobj_Field.value.split("/")[2],(Math.floor(pobj_Field.value.split("/")[1])-1),pobj_Field.value.split("/")[0]);
      this.str_Day = ("00" + this.str_Date.getDate());
      this.str_Month = ("00" + (this.str_Date.getMonth() + 1));
      this.str_Year = ("0000" + this.str_Date.getFullYear());
      this.str_Day = this.str_Day.substring((this.str_Day.length - 2),this.str_Day.length);
      this.str_Month = this.str_Month.substring((this.str_Month.length - 2),this.str_Month.length);
      this.str_Year = this.str_Year.substring((this.str_Year.length - 4),this.str_Year.length);
      pobj_Field.value = (this.str_Day + "/" + this.str_Month + "/" + this.str_Year);
    }
    else {
      pobj_Field.value = "";
    }
  }
  catch(obj_Exception) {
    exception(obj_Exception,"General[maskDate]");
  }
  finally {
    this.str_Date = null;
    this.str_Day = null;
    this.str_Month = null;
    this.str_Year = null;
  }
}

function onlyTime(pobj_Field) {
  try {
    if (event.keyCode < 48 || event.keyCode > 58) {
      event.cancelBubble = true;
      event.returnValue = false;
    }
  }
  catch(obj_Exception) {
    exception(obj_Exception,"General[onlyTime]");
  }
}

function maskTime(pobj_Field) {
  try {
    this.str_Date = new Date(0,0,0,pobj_Field.value.split(":")[0],((pobj_Field.value.split(":")[1] != null) ? pobj_Field.value.split(":")[1] : "0"));
    this.str_Hour = ("00" + this.str_Date.getHours());
    this.str_Minute = ("00" + this.str_Date.getMinutes());
    this.str_Hour = this.str_Hour.substring((this.str_Hour.length - 2),this.str_Hour.length);
    this.str_Minute = this.str_Minute.substring((this.str_Minute.length - 2),this.str_Minute.length);
    pobj_Field.value = (this.str_Hour + ":" + this.str_Minute);
  }
  catch(obj_Exception) {
    exception(obj_Exception,"General[maskTime]");
  }
}

function maskHour_Type(paEvento,paObjeto)
{
	var tecla = event.keyCode;
	var vwString = new String();
		
	if(tecla > 47 && tecla < 58) 
	{
		vwString  = paObjeto.value 
		switch(vwString.length)
		{
			case 1:
				if (parseInt(paObjeto.value) > 2)
				{
					paObjeto.value = "";
					return false;
				}
			break;
			case 2:
				if (parseInt(paObjeto.value) > 23)
				{
					paObjeto.value = "";
					return false;
				}
				paObjeto.value   = paObjeto.value  + ':'
			break;
			case 4:
				if (parseInt(paObjeto.value.substring(paObjeto.value.length -1,paObjeto.value.length)) > 5)
				{
					paObjeto.value = paObjeto.value.substring(0,paObjeto.value.length-1);
					return false;
				}
			break;
		}
		return true;
	}
	else 
	{
		return false;
	}
}


function maskHour(paObj)
{
	// Verifica se o Usu�rio j� informou a Hora no formato correto
	var vwValor  = new String() 
	var vwPosi, vwTemp;  
	var vwHora, vwMinuto
	vwValor  =  paObj.value;
	vwValor = vwValor.substr(0,5)  
	if(paObj.value == '')
	{
		return;
	} 
	
	vwPosi  = vwValor.indexOf(":",1);
	if(vwPosi > -1)
	{
		vwTemp		=  vwValor.split(":");
		vwHora		=  vwTemp[0];
		vwMinuto	=  vwTemp[1];
	}
	else
	{
		vwValor = vwValor.substr(0,4)  
		vwHora  =  vwValor.substr(0,2);
		vwMinuto  =  vwValor.substr(2,2);
	}
	vwHora		=	'00' + vwHora;
	vwHora      =   vwHora.substr(vwHora.length-2,2);
	vwMinuto	=	'00' + vwMinuto;
	vwMinuto    =   vwMinuto.substr(vwMinuto.length-2,2);
	
	if(parseInt(vwHora) > 23 ||  parseInt(vwHora)  < -1) 
	{
		paObj.value  =  '23:59'
		return; 
	}  
	if(parseInt(vwMinuto) > 59 ||  parseInt(vwMinuto)  < -1) 
	{
		paObj.value  =  '23:59'
		return; 
	}  
	paObj.value  =  vwHora  + ':' + vwMinuto;
}


function calendar(pobj_Field) {
  try {
    if (!pobj_Field.disabled){
	    if (opener != null) {
	      this.str_URL = self.opener.parent.top.location.toString().substring(0,self.opener.parent.top.location.toString().lastIndexOf("/"));
	    }
	    else {
	      this.str_URL = parent.top.location.toString().substring(0,parent.top.location.toString().lastIndexOf("/"));
	    }
	    
	    if (document.URL.lastIndexOf("includes") > 0) {
	    	this.str_URL = document.URL.substring(0,document.URL.lastIndexOf("/includes"));
	    }
	    this.str_URL += "/includes/calendar.asp";
	    this.str_Result = showModalDialog(this.str_URL,"","center=yes;dialogWidth=321px;dialogHeight=192px;status=no");
	    if (this.str_Result != null) {
	      if (this.str_Result != "") {
	        pobj_Field.value = this.str_Result;
	        main('retData',pobj_Field,this.str_Result);
	      }
	      maskDate(pobj_Field);
	    }
    }
  }
  catch(obj_Exception) {
    exception(obj_Exception,"General[calendar]");
  }
  finally {
    this.str_URL = null;
    this.str_Result = null;
  }
}

function maxLength(pobj_Field,plng_Length) {
try 
{
    if (pobj_Field.value.length >= plng_Length) 
    {
      pobj_Field.value = pobj_Field.value.substring(0,plng_Length);
      event.cancelBubble = true;
      event.returnValue = false;
    }
}
catch(obj_Exception) 
{
    exception(obj_Exception,"General[maxLength]");
}

}

function clone(pobj_Field) {
  try {
    this.str_FieldId = (pobj_Field.getAttribute("id") != null) ? pobj_Field.getAttribute("id") : "";
    if (this.str_FieldId != "") {
      this.obj_Elements = document.all(this.str_FieldId);
      for (var int_E = 0; int_E < this.obj_Elements.length; int_E++) {
        if (pobj_Field.getAttribute("type") == this.obj_Elements[int_E].getAttribute("type")) {
          this.bln_Clone = (this.obj_Elements[int_E].getAttribute("clone") != null) ? ((this.obj_Elements[int_E].getAttribute("clone") == "true") ? true : false) : false;
          if (this.bln_Clone) {
            this.obj_Elements[int_E].value = pobj_Field.getAttribute("value");
          }
        }
      }
    }
  }
  catch(obj_Exception) {
    exception(obj_Exception,"General[clone]");
  }
  finally {
    this.str_FieldId = null;
    this.obj_Elements = null;
  }
}

function copyFormToForm() {
  try {
    this.str_FormIdFrom = (arguments[0] != null) ? arguments[0] : "";
    this.str_FormIdTo = (arguments[1] != null) ? arguments[1] : "";
    if (this.str_FormIdFrom != "" && this.str_FormIdTo != "") {
      this.obj_FormFrom = document.getElementById(this.str_FormIdFrom);
      this.obj_FormTo = document.getElementById(this.str_FormIdTo);
      if (this.obj_FormFrom != null && this.obj_FormTo != null) {
        this.obj_ElementsFrom = this.obj_FormFrom.elements;
        for (var int_F = 0; int_F < this.obj_ElementsFrom.length; int_F++) {
          this.str_ElementId = (this.obj_ElementsFrom[int_F].getAttribute("id") != null) ? this.obj_ElementsFrom[int_F].getAttribute("id") : "";
          if (this.str_ElementId != "") {
            if (this.obj_FormTo.item(this.str_ElementId) != null) {
              this.obj_FormTo.item(this.str_ElementId).setAttribute("value",((this.obj_ElementsFrom[int_F].getAttribute("value") != null) ? this.obj_ElementsFrom[int_F].getAttribute("value") : ""));
            }
          }
        }
      }
    }
  }
  catch(obj_Exception) {
    exception(obj_Exception,"General[copyFormToForm]");
  }
  finally {
    this.str_FormIdFrom = null;
    this.str_FormIdTo = null;
    this.obj_FormFrom = null;
    this.obj_FormTo = null;
    this.obj_ElementsFrom = null;
    this.str_ElementId = null;
  }
}

function showLayer(pstr_FieldId) {
  try {
    var bln_All = (arguments[1] != null) ? (arguments[1] == true) ? true : false : true;
    if (!bln_All) {
      if (document.getElementById(pstr_FieldId) != null) {
        document.getElementById(pstr_FieldId).style.display = "";
      }
    }
    else {
      var obj_Divs = document.all(pstr_FieldId);
      if (obj_Divs != null) {
        if (obj_Divs.length != null) {
          for (var int_D = 0; int_D < obj_Divs.length; int_D++) {
            if (obj_Divs[int_D].style.display != "") {
              obj_Divs[int_D].style.display = "";
            }
          }
        }
        else {
          if (obj_Divs.style.display != "") {
            obj_Divs.style.display = "";
          }
        }
      }
    }
  }
  catch(obj_Exception) {
    exception(obj_Exception,"General[showLayer]");
  }
  finally {
    delete bln_All;
    delete obj_Divs;
  }
}

function hideLayer(pstr_FieldId) {
  try {
    var bln_All = (arguments[1] != null) ? (arguments[1] == true) ? true : false : true;
    if (!bln_All) {
      if (document.getElementById(pstr_FieldId) != null) {
        document.getElementById(pstr_FieldId).style.display = "none";
      }
    }
    else {
      var obj_Divs = document.all(pstr_FieldId);
      if (obj_Divs != null) {
        if (obj_Divs.length != null) {
          for (var int_D = 0; int_D < obj_Divs.length; int_D++) {
            if (obj_Divs[int_D].style.display != "none") {
              obj_Divs[int_D].style.display = "none";
            }
          }
        }
        else {
          if (obj_Divs.style.display != "none") {
            obj_Divs.style.display = "none";
          }
        }
      }
    }
  }
  catch(obj_Exception) {
    exception(obj_Exception,"General[hideLayer]");
  }
  finally {
    delete bln_All;
    delete obj_Divs;
  }
}

var bln_Expand = false;

function setLayer(pstr_FieldId) {
  try {
    var bln_ExpandAll = (arguments[1] != null) ? (arguments[1] == true) ? true : false : false;
    expand(pstr_FieldId,true,bln_ExpandAll,true);
    var obj_Field = document.getElementById(pstr_FieldId);
    if (obj_Field != null) {
      var str_Src = obj_Field.getAttribute("src");
      if (str_Src.indexOf("mais.gif") != -1) {
        expand(pstr_FieldId,true,bln_ExpandAll,true);
      }
    }
  }
  catch(obj_Exception) {
    exception(obj_Exception,"General[setLayer]");
  }
  finally {
    delete bln_ExpandAll;
    delete obj_Field;
    delete str_Src;
  }
}

function setFocus(pstr_Id) {
  try {
    this.int_FocusIndex = (arguments[1] != null) ? arguments[1] : 0;
    this.obj_Element = document.getElementById(pstr_Id);
    if (this.obj_Element != null) {
      while(this.obj_Element.getAttribute("tagName") != "FORM") {
        this.obj_Element = this.obj_Element.parentElement;
      }
      this.int_Index = -1;
      for (var int_F = 0; int_F < document.forms.length; int_F++) {
        if (document.forms[int_F].getAttribute("id") == this.obj_Element.getAttribute("id")) {
          this.int_Index = int_F;
          break;
        }
      }
      if (this.int_Index == -1) {
        return;
      }
      this.int_Cont = 0;
      for (var int_E = 0; int_E < document.forms[this.int_Index].elements.length; int_E++) {
        this.obj_Element = document.forms[this.int_Index].elements[int_E];
        if (this.obj_Element.getAttribute("disabled") != true && this.obj_Element.getAttribute("readOnly") != true) {
          this.str_TagName = this.obj_Element.getAttribute("tagName");
          switch(this.str_TagName) {
            case "INPUT":
              this.str_TagName += "-" + this.obj_Element.getAttribute("type");
              break;
            case "SELECT":
              this.str_TagName = this.obj_Element.getAttribute("type");
              break;
          }
          this.str_TagName = this.str_TagName.toLowerCase();
          switch(this.str_TagName) {
            case "input-file":
            case "input-text":
            case "input-checkbox":
            case "input-radio":
            case "input-button":
            case "select-one":
            case "select-multiple":
            case "textarea":
              if (this.int_FocusIndex != 0) {
                if (this.int_Cont == this.int_FocusIndex) {
                  this.obj_Element.focus();
                  return;
                }
              }
              else {
                this.obj_Element.focus();
                return;
              }
              this.int_Cont++;
          }
        }
      }
    }
  }
  catch(obj_Exception) {
    exception(obj_Exception,"General[setFocus]");
  }
  finally {
    this.int_FocusIndex = null;
    this.obj_Element = null;
    this.int_Index = null;
    this.obj_Elements = null;
    this.bln_Exit = null;
    this.str_TagName = null;
  }
}

function expand(pstr_FieldId) 
{
	var vwNivelPath =  "../../";
	if(vwNr_NivelPath == 1)  
	{
		vwNivelPath  =  "../";
	} 
//  try {
    if (!bln_Expand) {
      this.bln_Show = (arguments[1] != null) ? ((arguments[1] == true) ? true : false) : false;
      this.bln_Expand = (!bln_Expand && arguments[2] != null) ? ((arguments[2] == true) ? true : false) : false;
      this.bln_Bar = (arguments[3] != null) ? ((arguments[3] == true) ? true : false) : false;
      if (!this.bln_Show) {
        return;
      }
    }
    this.obj_XmlDom = new ActiveXObject("MSXML2.FreeThreadedDOMDocument")
    this.obj_XmlDom.loadXML("<root/>");
    this.obj_Root = this.obj_XmlDom.documentElement;
    this.obj_Form = null;
    this.obj_Img = document.getElementById(pstr_FieldId);
    if (this.obj_Img != null) {
      this.str_ParentElement = "";
      while(this.obj_Form == null) {
        this.str_ParentElement += ".parentElement";
        if (eval("this.obj_Img" + this.str_ParentElement + ".tagName") == "FORM") {
          this.obj_Form = eval("this.obj_Img" + this.str_ParentElement);
        }
        if (eval("this.obj_Img" + this.str_ParentElement + ".tagName") == "BODY") {
          break;
        }
      }
      if (this.obj_Form != null) {
        this.str_FormId = (this.obj_Form.getAttribute("id") != null) ? this.obj_Form.getAttribute("id") : "";
        this.str_PK = (this.obj_Form.getAttribute("pk") != null) ? this.obj_Form.getAttribute("pk") : "";
        this.obj_Node = this.obj_XmlDom.createNode(1,this.str_FormId,"");
        this.obj_Node.setAttribute("pk",this.str_PK);
        this.obj_Root.appendChild(this.obj_Node);
      }
      this.obj_Div = document.getElementById("div"+pstr_FieldId.substring(3,pstr_FieldId.length));
      if (this.obj_Div != null) {
        if (this.obj_Img.src.indexOf("_menos") != -1) {
        
          this.obj_Img.src = vwNivelPath + "images_home/img_display/img_botoes/ultr_mais.gif";
          this.obj_Div.style.display = "none";
          this.bln_Hide = true;
        }
        else {
          this.obj_Img.src = vwNivelPath + "images_home/img_display/img_botoes/ultr_menos.gif";
          this.obj_Div.style.display = "";
          this.bln_Hide = false;
        }
        this.str_NivelOrigem = (this.obj_Div.getAttribute("nivel") != null) ? this.obj_Div.getAttribute("nivel") : "0";
        this.obj_Divs = document.getElementsByTagName("DIV");
        if (this.obj_Divs != null) {
          for (var int_D = 0; int_D < this.obj_Divs.length; int_D++) {
            this.str_Id = (this.obj_Divs[int_D].getAttribute("id") != null) ? this.obj_Divs[int_D].getAttribute("id") : "";
            this.str_Nivel = (this.obj_Divs[int_D].getAttribute("nivel") != null) ? this.obj_Divs[int_D].getAttribute("nivel") : "";
            this.obj_Img = document.getElementById("img"+this.obj_Divs[int_D].getAttribute("id").substring(3,this.obj_Divs[int_D].getAttribute("id").length));
            if (this.str_Id != "" && this.str_Nivel != "") {
              if (this.bln_Hide) {
                if (this.str_Id == ("div"+pstr_FieldId.substring(3,pstr_FieldId.length))) {
                  if (this.obj_Img != null) {
                    this.obj_Img.src = vwNivelPath +  "images_home/img_display/img_botoes/ultr_mais.gif";
                  }
                  this.obj_Divs[int_D].style.display = "none";
                }
              }
              else {
                if (this.str_Id == ("div"+pstr_FieldId.substring(3,pstr_FieldId.length))) {
                  if (this.obj_Img != null) {
                    this.obj_Img.src = vwNivelPath + "images_home/img_display/img_botoes/ultr_menos.gif";
                  }
                  this.obj_Divs[int_D].style.display = "";
                }
                else {
                  if (Math.floor(this.str_Nivel) >= Math.floor(this.str_NivelOrigem)) {
                    if (this.obj_Img != null) {
                      this.obj_Img.src = vwNivelPath + "images_home/img_display/img_botoes/ultr_mais.gif";
                    }
                    this.obj_Divs[int_D].style.display = "none";
                  }
                }
              }
            }
          }
        }
        if (this.obj_Form != null) {
          this.obj_Node = this.obj_XmlDom.selectSingleNode("root/operation");
          if (this.obj_Node == null) {
            this.obj_Node = this.obj_XmlDom.createNode(1,"operation","");
            this.obj_Root.appendChild(this.obj_Node);
          }
          this.obj_Node = this.obj_XmlDom.selectSingleNode("root/operation");
          if (this.bln_Hide) {
            this.obj_Node.setAttribute("value","save");
          }
          else {
            if (!this.bln_Bar) {
              this.obj_Node.setAttribute("value","save");
              main("forms",null,this.obj_XmlDom.xml);
            }
            this.obj_Node.setAttribute("value","load");
          }
          main("forms",null,this.obj_XmlDom.xml);
        }
      }
    }
//  }
//  catch(obj_Exception) {
//    exception(obj_Exception,"General[expand]");
//  }
//  finally {
    this.obj_XmlDom = null;
    this.obj_Root = null;
    this.obj_Form = null;
    this.obj_Img = null;
    this.str_ParentElement = null;
    this.str_FormId = null;
    this.str_PK = null;
    this.obj_Node = null;
    this.obj_Div = null;
    this.bln_Hide = null;
    this.str_NivelOrigem = null;
    this.obj_Divs = null;
    this.str_Id = null;
    this.str_Nivel = null;
//  }
}

function changeFolder(pobj_Collumn,pstr_DivsId,pint_Index) {
  try {
    this.obj_Cols = pobj_Collumn.parentElement.getElementsByTagName("TD")
    if (this.obj_Cols != null) {
      for (var int_C = 0; int_C < this.obj_Cols.length; int_C++) {
        this.obj_Cols[int_C].className = "abaroxa";
      }
      pobj_Collumn.className = "abaazulroll";
      this.obj_Divs = document.all(pstr_DivsId);
      if (this.obj_Divs != null) {
        for (var int_D = 0; int_D < this.obj_Divs.length; int_D++) {
          if (pint_Index == int_D) {
            this.obj_Divs[int_D].style.display = "block";
          }
          else {
            this.obj_Divs[int_D].style.display = "none";
          }
        }
      }
    }
  }
  catch(obj_Exception) {
    exception(obj_Exception,"General[changeFolder]");
  }
  finally {
    this.obj_Cols = null;
    this.obj_Divs = null;
  }
}

function exception(pobj_Exception,pstr_ClassMethod) {
  try {
    this.str_ExceptionBody = "";
    if (pobj_Exception != null)
    {
      if (pobj_Exception.number != 0) {
        this.str_ExceptionBody += "Erro: " + pstr_ClassMethod + "\n\n";
        this.str_ExceptionBody += "Descri��o : [" + pobj_Exception.number + "] ";
        this.str_ExceptionBody += pobj_Exception.name + " - ";
        this.str_ExceptionBody += pobj_Exception.description + "\n\n";
        this.str_ExceptionBody += self.location + "\n";
      }
      else {
        if (pobj_Exception.message != "" || pobj_Exception.description != "") {
          this.str_ExceptionBody = "\n" + pobj_Exception.description + "\n";
        }
      }
    }
    if (this.str_ExceptionBody != "") {
      this.str_ExceptionBody = "Favor reportar esta mensagem para o suporte do sitema, comentando\n"
        + "a opera��o que est� sendo executada.\n\n" + this.str_ExceptionBody;
      alert(this.str_ExceptionBody);
    }
  }
  catch(lobj_Exception) {
    alert("Exception: [" + pobj_Exception.number + "] " + lobj_Exception.description);
  }
  finally {
    this.str_ExceptionBody = "";
  }
}

function store(pobj_Field) {
  try {
    if (pobj_Field.createTextRange) {
      pobj_Field.caretPos = document.selection.createRange().duplicate();
    }
  }
  catch(obj_Exception) {
    exception(obj_Exception,"General[store]");
  }
  finally {
  }
}

function trim(pstr_Value) {
  try {
    var str_Result = pstr_Value;
    while(str_Result.indexOf("  ") != -1) {
      str_Result = str_Result.replace(/  /g," ");
    }
    if (str_Result.substring(0,1) == " ") {
      str_Result = str_Result.substring(1,str_Result.length);
    }
    if (str_Result.substring((str_Result.length - 1),str_Result.length) == " ") {
      str_Result = str_Result.substring(0,(str_Result.length - 1));
    }
    return str_Result;
  }
  catch(obj_Exception) {
    exception(obj_Exception,"General[trim]");
  }
  finally {
    delete str_Result;
  }
}

function omitirBarra(){		
	if(event.keyCode == 193 || event.keyCode == 111){
		event.returnValue = false;
	}
}

function lerMensagem(pstr_IdMensagem){
try {
    var obj_XML = new ActiveXObject("MSXML2.FreeThreadedDOMDocument");
    var obj_NXML;
    var str_DsMensagem = "";
    var str_Host, astr_Host;
    var arr_Param;
    
    str_Host = getHost();
    obj_XML.async = false;
    obj_XML.load(str_Host + "/includes/mensagem.xml");
    if (obj_XML.parseError == 0){		
	obj_NXML = obj_XML.selectSingleNode("//*[@value='" + pstr_IdMensagem.toUpperCase() + "']");		
	if (obj_NXML == null){
		str_DsMensagem = "Mensagem n�o encontrada";
	}else{
		str_DsMensagem = obj_NXML.text;
	}
   }	
   
   //Se encontrar [] concatena com par�metros informados em arguments[1]. Par�metros passados separados por "|"
   if (str_DsMensagem.indexOf("[") != -1 && arguments[1] != undefined){
   	var arr_Param = arguments[1].split("|");
   	for (var int_cont = 0; int_cont < arr_Param.length; int_cont++){
	   	var str_Param = str_DsMensagem.substr(str_DsMensagem.indexOf("["),str_DsMensagem.indexOf("]") + 1 -str_DsMensagem.indexOf("["));
		str_DsMensagem = str_DsMensagem.replace(str_Param,arr_Param[int_cont]);
	}
	
   }else if (str_DsMensagem.indexOf("[") != -1 && arguments[1] == undefined) {
   	str_DsMensagem = "Informar o(s) par�metro(s) da mensagem";
   }
   return unescape(str_DsMensagem);
}
	catch(obj_Exception) {
    	exception(obj_Exception,"General[lerMensagem]");
}finally {
	delete obj_XML;
    	delete obj_NXML;
	delete str_DsMensagem;    
  }
}


function mergeXMLSL(pstr_XMLServer,pstr_XMLLocal){
  try {
	var str_FormName = "";
	
	var str_XMLServer = "";	
	var obj_XMLServer = new ActiveXObject("MSXML2.DOMDocument");
	obj_XMLServer.loadXML(pstr_XMLServer);
	
	//No XML do servidor, elimina os n�s com status server
	var obj_NServer = obj_XMLServer.selectNodes("//row");	
	for(var int_conts=0; int_conts < obj_NServer.length; int_conts++){		
		if (obj_NServer[int_conts].getAttribute("status") == "server"){
			str_XMLServer += obj_NServer[int_conts].xml;
		}
	}
	
	var str_XMLLocal = "";	
	var obj_XMLLocal = new ActiveXObject("MSXML2.DOMDocument");
	obj_XMLLocal.loadXML(pstr_XMLLocal);
	
	//No XML do servidor, elimina os n�s com status server
	var obj_NLocal = obj_XMLLocal.selectNodes("//row");	
	for(var int_contl=0; int_contl < obj_NLocal.length; int_contl++){		
		if (obj_NLocal[int_contl].getAttribute("status") != "del"){
			str_XMLLocal += obj_NLocal[int_contl].xml;			
		}
	}
		
	var str_MergedXML = "<root><form tipo='table'>" + str_XMLLocal + str_XMLServer + "</form></root>";
	return str_MergedXML;
  }
  catch(obj_Exception) {
    exception(obj_Exception,"General[mergeXMLSL]");
  }
  finally {
    delete obj_XMLServer;
    delete obj_XMLLocal;
    delete obj_NServer;
    delete obj_NLocal;
  }
}

function separateEntFil(pstr_Field,pobj_Ent,pobj_Fil){
	try {
	   var str_separator = arguments[3];
	   if (str_separator == undefined){
	   	str_separator = "/";
	   }
	   if (pstr_Field != "") {	   	
	   	var dsentidade = pstr_Field.substr(0,pstr_Field.indexOf(str_separator));
	   	if (pstr_Field.indexOf(str_separator) >0) {
	   		pobj_Ent.value = trim(unescape(dsentidade));
	   		var dsfilial = pstr_Field.substr(pstr_Field.indexOf(str_separator) + 1, pstr_Field.length);
	   		pobj_Fil.value = trim(unescape(dsfilial));
	   	}
	   	else {
	   		pobj_Ent.value = pstr_Field;
	   		pobj_Fil.value = "";
	   	}
	  }else{
	  	pobj_Ent.value = "";
  	  	pobj_Fil.value = "";
	  }

	}
	catch(obj_Exception) {
		exception(obj_Exception,"General[separateEntFil]");
  	}
	finally {
		delete pstr_Field;
		delete pobj_Ent;
		delete pobj_Fil;
  	}
}

//Fun��o que cancela as teclas que passarmos separadas por pipe (atrav�s do event.keyCode)
function eliminatekeyboard(){
	try {
		var astr_KeyCode = arguments[0].split("|");
		
		for (var int_cont = 0; int_cont < astr_KeyCode.length; int_cont++){
			if (event.keyCode == astr_KeyCode[int_cont]){
				
				event.cancelBubble = true;
				event.returnValue = false;
			}
		}
	}
	catch(obj_Exception) {
		exception(obj_Exception,"General[eliminatekeyboard]");
	}
}

function digitarUpper(pobj)
{
	var aceitaMinusculo = (arguments[1] != null) ? arguments[1] : "N";	

	//Verifica se o usu�rio clicou em "�" ou "�"
	if(event.keyCode == 199 || event.keyCode == 231)
	{
		//Retira a string "� ou �"
		//Insere a string "C"
		event.keyCode = 67;
	}
	if (aceitaMinusculo == "N"){
		if (event.keyCode >= 97 && event.keyCode <= 122){
			event.keyCode = event.keyCode - 32
		}
	}
	
	//  Trocar os caracteres ������������������������ por AAAAAEEEEIIIIOOOOOUUUUCN
	
	if((event.keyCode>=192 && event.keyCode<=195)||(event.keyCode>=224 && event.keyCode <=227)){
		// A e a
		event.keyCode = 65;
	}
	else if((event.keyCode>=200 && event.keyCode <=203)||(event.keyCode>=232 && event.keyCode <=235)){
		// E
		event.keyCode = 69;
	}
	else if((event.keyCode>=204 && event.keyCode <=207)||(event.keyCode>=236 && event.keyCode <=239)){
		// I
		event.keyCode = 73;
	}
	else if((event.keyCode>=210 && event.keyCode <=214)||(event.keyCode>=242 && event.keyCode <=246)){
		// O
		event.keyCode = 79;
	}

	else if((event.keyCode>=217 && event.keyCode <=220)||(event.keyCode>=249 && event.keyCode <=252)){
		// U
		event.keyCode = 85;
	}
	else if(event.keyCode==209 || event.keyCode==241){
		// �
		event.keyCode = 78;
	}
	else if(event.keyCode==126 || event.keyCode==96 || event.keyCode==180 || event.keyCode==94){
		// n�o deve existir
		event.keyCode=13; // colocado o enter para n�o fazer nada quando digitato apenas os acentos
	}else if(event.keyCode==39){
		// n�o deve existir
		event.keyCode=00; // colocado o enter para n�o fazer nada quando digitato apenas os acentos
	}
	
	
	
	
}

function trim(pstr_Palavra) {
    var inicial=0;
    var final=pstr_Palavra.length;
    while (pstr_Palavra.charCodeAt(inicial)==32) {inicial++;}
    while (pstr_Palavra.charCodeAt(final-1)==32) {final--;}
    return(pstr_Palavra.substr(inicial,final-inicial));
}

// Fun��o que valida a formata��o de E-mail	
// Criado por Anderson Ikuo Nakamoto		
// Entrada: - pStr: Email a ser validado
//		    - pFmt: O Formato do Email	
//				- 1: Formato Livre (email para testes pr�prios de pesquisa)
//				- 2: Fechado (email para corpora��es nacionais)
//				- 3: Restrito (email padr�o Internacional)	
// Sa�da:   - True ou False


var reEmail1 = /^[\w!#$%&'*+\/=?^`{|}~-]+(\.[\w!#$%&'*+\/=?^`{|}~-]+)*@(([\w-]+\.)+[A-Za-z]{2,6}|\[\d{1,3}(\.\d{1,3}){3}\])$/;
var reEmail2 = /^[\w-]+(\.[\w-]+)*@(([\w-]{2,63}\.)+[A-Za-z]{2,6}|\[\d{1,3}(\.\d{1,3}){3}\])$/;
var reEmail3 = /^[\w-]+(\.[\w-]+)*@(([A-Za-z\d][A-Za-z\d-]{0,61}[A-Za-z\d]\.)+[A-Za-z]{2,6}|\[\d{1,3}(\.\d{1,3}){3}\])$/;
var reEmail = reEmail3;

function ValidaEmail(pStr, pFmt)
{
	eval("reEmail = reEmail" + pFmt);
	if (reEmail.test(pStr)) 
	{
		return true;
		
	} else if (pStr != null && pStr != "") 
	{
		return false;
		
	}
}

//Marca combo conforme valor informado -----------------------------------------------------------------------------
function markCombo(obj, refValue)
{
	// Vari�vel para controle de objetos desabilitados.
	var volta = false;
	if (obj != undefined)
	{
		if(obj.disabled){obj.disabled = false; volta = true;}
	
		var limCombo = obj.length;
		for (i=0; i < limCombo; i++)
		{
					
			if(obj.item(i).value == refValue)
			{
			obj.item(i).selected = true;
			
			}		
		}
	
		obj.disabled = volta;
	}
}


function mergeXmlArray (pastr_Xml){
 
  try{ 
		var obj_MergeXml;
		var obj_MergeXml2;
		var obj_MergeRoot;
		var obj_MergeNode;
		var llng_cont;       

		obj_MergeXml	  = new ActiveXObject("MSXML2.DOMDocument");
		obj_MergeXml2	  = new ActiveXObject("MSXML2.DOMDocument");
    
		obj_MergeXml.loadXML ("<root/>");
    
		obj_MergeRoot = obj_MergeXml.documentElement;
		for(llng_cont = 0 ; llng_cont < pastr_Xml.length ; llng_cont++)
		{
			obj_MergeXml2.loadXML (pastr_Xml[llng_cont]);
		    
		    if (obj_MergeXml2.parseError == 0){
		        
		        obj_MergeNode = obj_MergeXml2.selectSingleNode("root/*");
		        
		        if(obj_MergeNode!= null){
		            obj_MergeRoot.appendChild (obj_MergeNode.cloneNode("True"));
		        }
		    }
    	}
    
	return obj_MergeXml.xml;
  
  }catch(obj_Exception) {
    exception(obj_Exception,"General[mergeXmlArray]");
  }
  finally {
	delete obj_MergeXml;
	delete obj_MergeXml2;
	delete obj_MergeRoot;
	delete obj_MergeNode;
    
  }
}

// Retorna o conte�do do atributo desejado...
//		Felipe T.
function getAttribute(strXML, atribute, path)
{
	var objDOM_v = new ActiveXObject("MSXML2.DOMDocument");
	objDOM_v.loadXML(strXML);
	if (objDOM_v.parseError == 0) 
	{
	    if(objDOM_v.selectSingleNode(path) != null) 
	    {obj_Node = objDOM_v.selectSingleNode(path);return obj_Node.getAttribute(atribute);}
		else{return "";}
	}
	delete objDOM_v;
}


function getXmlToRel(){
	try{
		
		var str_xml_in = arguments[0];
		
		var objXML_At  =  new ActiveXObject("MSXML2.FreeThreadedDOMDocument");
		var objNodesAt;
		var objXML_Tipo  =  new ActiveXObject("MSXML2.FreeThreadedDOMDocument");
		var objNodesTipo;
	
		objXML_At.loadXML(str_xml_in);
	
		objNodesAt = objXML_At.selectSingleNode("root/*");
		objNodesAt.setAttribute("pathname",arguments[1]);
	
		var nodename = objNodesAt.nodeName;
		str_xml_in = objXML_At.xml;
				
		objXML_Tipo.loadXML(str_xml_in);
		objNodesTipo = objXML_At.selectNodes("//frm_filtro");
				
		var xml_ini = "";
		var xml_meio = "";
		var xml_fim = "";
		var xml_rel = "";
				
		xml_ini = "<root><frm pathname='" + arguments[1] + "'>";
		xml_fim = "</frm></root>";
				
		var obj_NodeFilho = objNodesTipo(0).childNodes;
				
		for(i=0;i < obj_NodeFilho.length;i++){
			if (obj_NodeFilho(i).nodeName !="loginatu" && obj_NodeFilho(i).nodeName !="loginentidade" && obj_NodeFilho(i).nodeName !="loginfilial"){
				var nodeSel = document.getElementById(obj_NodeFilho(i).nodeName);
				xml_meio += "<" + unescape(obj_NodeFilho(i).nodeName) + " value='" + unescape(nodeSel.value) + "' type_value='" + unescape(nodeSel.type_value) + "'/>";
			 }else{
			 	xml_meio += "<" + unescape(obj_NodeFilho(i).nodeName) + " value='" + unescape(obj_NodeFilho(i).getAttribute("value")) + "' type_value='int'/>";
			 }
		}
		xml_rel = xml_ini + xml_meio + xml_fim;
		
		return xml_rel;
		
	}catch(obj_Exception) {
		exception(obj_Exception,"General[getXmlToRel]");
	}
	finally {
		delete objXML_At;
		delete objNodesAt;
		delete objXML_Tipo;
		delete objNodesTipo;
		delete obj_NodeFilho;
	}
}

function fncForceForm(objForm){

	var mensagem = "Necess�rio informar o(s) seguinte(s) campo(s):\n\n";
	var indice = "";
	for (var i=0; i < objForm.length; i++)
	{
		
		if ((objForm.item(i).lbl != undefined)&&(objForm.item(i).lbl != ""))
		{
			if (trim(objForm.item(i).value) == "")
			{
				mensagem += "- " + objForm.item(i).lbl + "\n";
				if (indice.toString() == "") 
				{
					indice = i;
				}
			}
		}
	}
	if (indice.toString() != "")
	{
		msgBox(mensagem);
		objForm.item(indice).focus();
		return false;
	}
	else
	{
		return true;
	}
}
function fncObtemImpressora()
{
	return Impressora.ObtemImpressora;
}

function fncVerificaImpressora()
{
	var nrVersao			= 0;
	var strXMLImpressora	= "";
	var objXMLImpressora	= new ActiveXObject("MSXML2.DOMDocument");
	
	strXMLImpressora = Impressora.ObtemImpressora;
	objXMLImpressora.loadXML(strXMLImpressora);
	
	if (objXMLImpressora.parseError == 0) 
	{
		nrVersao = objXMLImpressora.selectSingleNode("//versao").getAttribute("value");
	
		if (nrVersao == "")
		{
			nrVersao = "0";
		}
		
		if (nrVersao == "6")
		{
			return true;
		}
		else
		{
			return false;
		}	
	}
	else
	{
		return false;
	}
}


function formatarDecimal(valor, precisao){
	try{
		valor = valor.replace(".",",")
		var valor_conv = valor.split(",");
		var valor_aux = "";
		var valor_zero = "";
		var resultado;
		
		if (valor_conv.length > 1){
			if (valor_conv[1].length < precisao){
				for(i=valor_conv[1].length;i < precisao;i++){
					valor_zero = valor_zero + '0'
				}
				resultado = valor_conv[0] + "," + valor_conv[1] + valor_zero;
			}else{
				valor_aux = valor_conv[1].substr(0,precisao);
				resultado = valor_conv[0] + "," + valor_aux;
			}
		}else{
			for(i=0;i < precisao;i++){
				valor_zero = valor_zero + '0'
			}
			resultado = valor + ',' + valor_zero;
			}
			
		return resultado;
	}catch(obj_Exception) {
		exception(obj_Exception,"General[formatarDecimal]");
	}
}

function verificarDataInicialFinal(dataInicial,horaInicial,dataFinal,horaFinal,operador){
  try{
	var str_DataInicial, str_DataFinal, str_Data=false;           

	if (trim(dataInicial) == "" || trim(horaInicial) == "" || trim(dataFinal) == "" || trim(horaFinal) == ""){
		str_Data = false;
	}else{
		str_DataInicial = new Date(ANSIDate(dataInicial + " " + horaInicial));
		str_DataFinal = new Date(ANSIDate(dataFinal + " " + horaFinal));
		switch(operador){
			case ">":
				if (str_DataInicial > str_DataFinal){
					str_Data=true;
				}	
			break;
			case ">=":
				if (str_DataInicial >= str_DataFinal){
					str_Data=true;
				}	
			break;
			case "<":
				if (str_DataInicial < str_DataFinal){
					str_Data=true;
				}	
			break;
			case "<=":
				if (str_DataInicial <= str_DataFinal){
					str_Data=true;
				}	
			break;
			default:
				if (str_DataInicial == str_DataFinal){
					str_Data=true;
					}	
			break;
		}
	}
    return str_Data;
  } 
    catch(obj_Exception) {
		exception(obj_Exception,"General[data error]");		
  }
  finally {
  }
}