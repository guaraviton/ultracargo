
function setButton(pstr_Enable) {
  try {
    this.astr_ButtonSequence = new Array("S","N","C","P","E","I");
    this.astr_Enable = pstr_Enable.split(",");
    for (var int_I = 0; int_I < this.astr_ButtonSequence.length; int_I++) {
      document.getElementById("idMenu_" + this.astr_ButtonSequence[int_I]).style.display = "none";
      for (var int_J = 0; int_J < this.astr_Enable.length; int_J++) {
        if (this.astr_ButtonSequence[int_I] == this.astr_Enable[int_J]) {
          document.getElementById("idMenu_" + this.astr_ButtonSequence[int_I]).style.display = "";
        }
      }
    }
  }
  catch(obj_Exception) {
    alert("General[setButton]: " + obj_Exception.description);
  }
}
