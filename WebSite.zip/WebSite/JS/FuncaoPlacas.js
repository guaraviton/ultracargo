﻿//Função responsável por validar placas nos padrões Brasil e MercoSul
$(document).ready(function(){

	$( ".dsplaca" ).blur(function() {
		
		var er =  /^[a-zA-Z]{3}[0-9]{1}[a-zA-Z0-9]{1}[0-9]{2}$/;
		var placa = $(this).val()
		if(placa != ''){
		    if(!er.test(placa)){
			    msgBox("Placa digitada esta fora do padrão permitido");
			    $(this).val("");
			    $(this).focus();
		    }
		}
	});
});