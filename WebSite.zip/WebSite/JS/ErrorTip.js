﻿// ErrorTip library

isIE=document.all;
isNN=!document.all&&document.getElementById;
isN4=document.layers;
isHot=false;

function ErrorTipInit(e){
  topDog=isIE ? "BODY" : "HTML";
  whichDog=isIE ? document.all.ErrorTipControl : document.getElementById("ErrorTipControl");  
  hotDog=isIE ? event.srcElement : e.target;  
  while (hotDog.id!="titleBar"&&hotDog.tagName!=topDog){
    hotDog=isIE ? hotDog.parentElement : hotDog.parentNode;
  }  
  if (hotDog.id=="titleBar"){
    offsetx=isIE ? event.clientX : e.clientX;
    offsety=isIE ? event.clientY : e.clientY;
    nowX=parseInt(whichDog.style.left);
    nowY=parseInt(whichDog.style.top);
    ddEnabled=true;
    document.onmousemove=ErrorTip;
  }
}

function ErrorTip(e){
  if (!ddEnabled) return;
try{  
  whichDog.style.left=isIE ? nowX+event.clientX-offsetx : nowX+e.clientX-offsetx; 
  whichDog.style.top=isIE ? nowY+event.clientY-offsety : nowY+e.clientY-offsety;
}catch(ex){}
  return false;  
}

function hideErrorTip(){
try{
  if (isIE||isNN) whichDog.style.display="none";
}catch(ex){}
}

function showErrorTip(strMessage){
try{
  document.getElementById("ErrorTipMessage").innerHTML = strMessage;
  if (isIE||isNN) whichDog.style.display="block";
}catch(ex){}
}

//document.onmousedown=ErrorTipInit;
document.onactivate=ErrorTipInit;
document.onmouseup=Function("ddEnabled=false");