﻿//ToolTip para exibição no grid, quando passa o mouse sobre um objeto
//Thiago Jardim Gaona, 27/08/2006

function showToolTip(objThis, objEvent, strTexto){
    if(document.all && document.readyState == 'complete'){
        document.all.ToolTipControl.innerHTML = '<b>' + strTexto + '</b>';
        document.all.ToolTipControl.style.pixelLeft = event.clientX + document.body.scrollLeft + 10;
        document.all.ToolTipControl.style.pixelTop = event.clientY + document.body.scrollTop + 10;
        document.all.ToolTipControl.style.visibility = 'visible';
    }
    else if(document.layers){
        document.ToolTipControl.document.nstip.document.write('<b>' + strTexto + '</b>');
        document.ToolTipControl.document.nstip.document.close();
        document.ToolTipControl.document.nstip.left=0;
        currentscroll = setInterval('scrolltip()',100);
        document.ToolTipControl.left = objEvent.pageX + 10;
        document.ToolTipControl.top = objEvent.pageY + 10;
        document.ToolTipControl.style.visibility = 'visible';
    }
}

function hideToolTip(){
    if(document.all)
        document.all.ToolTipControl.style.visibility = 'hidden';
    else if(document.layers){
        clearInterval(currentscroll);
        document.ToolTipControl.style.visibility = 'hidden';
    }
}