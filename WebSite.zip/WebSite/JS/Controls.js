﻿// JScript File

function AutoCompleteConsultaWS(AjaxMetodo, nodeRetorno, MetodoPopUp, MetodoRetorno, ObjThis, VerificaExecucao)
{
    if (VerificaExecucao == undefined | VerificaExecucao)
    {
        var value = ObjThis.value;
        try
        {
            if (!valida_Alfabeto(ObjThis))
            {
                return;
            }
            if (value != "" && ObjThis.isTextEdit)
            {
                var response = eval(AjaxMetodo);
                if (response.error == null)
                {
                    var ds = response.value;
                    
                    if (ds != null)
                    {
                   
                        if (ds.Tables[0].Rows.length == 1)
                        {
                            if(ds.Tables[0].Rows[0]["mensagem"] != undefined)
                            {
                                if ((ds.Tables[0].Rows[0]["mensagem"] == "Nenhum registro encontrado.") || (ds.Tables[0].Rows[0]["mensagem"].indexOf("Melhore o filtro") != -1))
                                {
                                    if (MetodoPopUp != "")
                                        eval(MetodoPopUp);
                                }
                                else
                                {
                                    alert(ds.Tables[0].Rows[0]["mensagem"]);
                                }
                            }
                            else if(ds.Tables[0].Rows[0]["mstr_mensagem"] != undefined || ds.Tables[0].Rows[0]["mstr_Mensagem"] != undefined)
                            {
                                if (ds.Tables[0].Rows[0]["mstr_mensagem"] == "Nenhum registro encontrado." || ds.Tables[0].Rows[0]["mstr_Mensagem"] == "Nenhum registro encontrado.")
                                {
                                    if (MetodoPopUp != "")
                                        eval(MetodoPopUp);
                                }
                                else
                                {
                                    if(ds.Tables[0].Rows[0]["mstr_mensagem"] != undefined)
                                        alert(ds.Tables[0].Rows[0]["mstr_mensagem"]);
                                    if(ds.Tables[0].Rows[0]["mstr_Mensagem"] != undefined)
                                        alert(ds.Tables[0].Rows[0]["mstr_Mensagem"]);
                                }
                            }
                            else 
                            {
                                ObjThis.value = ds.Tables[0].Rows[0][nodeRetorno];
                                if (MetodoRetorno != "")
                                    eval(MetodoRetorno);
                            }
                        }
                        else if (ds.Tables[0].Rows.length > 1)
                        {
                            if (MetodoPopUp != "")
                                eval(MetodoPopUp);
                        }
                        
                        else if (ds.Tables[0].Rows.length = 1)
                        {
                            if (MetodoPopUp != "")
                                eval(MetodoPopUp);
                        }
                    }
                    else
                    {
                        if (MetodoPopUp != "")
                            eval(MetodoPopUp);
                    }
                }
                else
                {
                    alert((response.error.Message) ? response.error.Message : response.error.description);
                    showErrorTip((response.error.Message) ? response.error.Message : response.error.description);
                }
            }
            else
                if (MetodoRetorno != ""){
                    MetodoRetorno = MetodoRetorno.replace('ds', '""');
                    eval(MetodoRetorno);
                }
        }
        catch (ex)
        {
            alert("AutoCompleteConsultaWS: " + ex.message);
        }
    }
}


// ActivePrint
function TextPrint()
{
    try
    {   
        return new ActiveXObject("ActivePrint.TextPrint");
    } catch (ex)
    {
        return null;
    }
}