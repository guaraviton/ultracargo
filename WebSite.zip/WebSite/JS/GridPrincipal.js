﻿//Arquivo JavaScript que Contem as Funcoes Principas para se dar o " Bind " do Grid.

//Variaveis Globais de Set para o Grid
var xmlData; //= "ID do XML. Exemplo: xmlDados";
var gridId; //= "ID do Grid. Exemplo: Grid";
var pkField; //= "Campo que carrega o ID para Exclusao/Alteracao/Consulta dos Registros. Exemplo: 0";
var showModalOn; //= " Caso a Escolha do Registro no Grid, venha de um PopUp. Exemplo: ON/OFF";
var cfgTipoGravacao; //= " Escolhe o Tipo de Gravacao na Base. Podendo ser em Cache ou em Direto. Exemplo: SIMPLES/CACHE "
var cfgTipoEdicao; //= " Escolhe o Tipo de Edicao na Base. Podendo ser no Proprio Grid ou na Tela. Exemplo: TELA/GRID "
var cfgPaginacao; //= " Configura o Tipo de Paginacao. Exemplo: AUTO/MANUAL "
var pathSource; //= " Recupera o Caminho Default da Aplicacao para que possa Chamar as Imagens/Telas/PopUps e Afins "
var getRegister; //= " Caso Queira que o GRID venha com 1 Registro. Exemplo: S/N."
var cfgAcesso; //= "Configuração de acesso do grid"
var cfgCtrAcesso = 'EAC'; //= "Configura os coltroles que serão bloqueados. Se conter E = Excluir, A = Alterar, C = Confirma "

//Variaveis de Uso Interno do Grid.
var oChooseIdCombo = new Array; // = Variavel que transfere os IDs dos Registros das Combos Geradas pelo GRID.
var strCacheAutoComplete_Grid = new Array; //vetor de controle do AutoComplete
var strCacheAutoCompleteAux_Grid = new Array; //vetor de controle do AutoComplete Aux


//************************************ FUNCOES DE MANIPULACAO DE REGISTROS DO GRID *********************************//  
//                                                                                                                  //
//                                                                                                                  //
//******************************************************************************************************************//

//Exclui Registro Selecionado.
function DeleteRow(oID) 
    {
        var xmlDoc = document.getElementById(xmlData);
        var children = xmlDoc.documentElement.childNodes;        
        
        for (var i = 0; i < children.length; i++)
            {
                if (children[i].childNodes[pkField].firstChild.nodeValue == oID)
                    {
                        //Verifica se a Exclusao vem do Grid ou do Cancelamento de Inclusao de Novo Registro.
                        if (oID.indexOf("xkzID") != -1)
                            {                              
                                xmlDoc.documentElement.removeChild(children[i]); 
                                document.getElementById(gridId+".dvGeral").scrollTop = 0;                                   
                            }
                        else
                            {
                                if (confirm("Tem Certeza que deseja Apagar o Registro?!"))
                                    {
                                        //Caso Seja Exclusao Simples de Registros, chama a funcao que Excluira o Registro do Banco.
                                        if (cfgTipoGravacao.toUpperCase() == "SIMPLES")
                                            {
                                                if (!excluiRegistro(ChooseRow(oID)))
                                                {
                                                    return;
                                                }   
                                                document.getElementById(gridId+".dvGeral").scrollTop = 0;
                                                scrollTitle();
                                            }
                                        if (xmlDoc.documentElement)    
                                            xmlDoc.documentElement.removeChild(children[i]);                   
                                    }                            
                            }
 
                        return
                    }
            }
    }

//Funcao para Inclusao de Registros.
function AddRows()
    {
        var oTableData = document.getElementById(gridId+".tbEditData");        
        var tds = oTableData.getElementsByTagName("td");
        var dvHeight;
        
        //Rola o Scroll para o Top.
        document.getElementById(gridId+".dvGeral").scrollTop = 0;
        
        //Verifica o Tamanho da Div Geral.
        dvHeight = document.getElementById(gridId+".dvGeral").style.height;
        dvHeight = dvHeight.replace("px","");  
            
        //Posiciona o Div de Alteracao/Inclusao.
        document.getElementById(gridId+".dvEdit").style.top = dvHeight - 59;
        
        //Exibe o Div de Alteracao.
        document.getElementById(gridId+".dvEdit").style.display = "block";
            
        //Modifica o Titulo da Aba para "Editar".
        document.getElementById(gridId+".tbEditTitle").getElementsByTagName("td")[0].innerHTML = "Novo";
        
        //Altera o Link de Confirmacao para funcao de "Alteracao".
        document.getElementById(gridId+".btConfirma").href = "javascript:confirmaAcao('I','');"

        //Limpa os Elementos.
        for (var i = 0; i < tds.length; i++) 
            {
                if (tds[i].style.display == "block")
                    {
                        document.getElementById(gridId+".Element"+i).value = "";
                    }
            }
            
        //Limpa as Obrigatoriedades.
        for (var i = 0; i < tds.length; i++) 
            {
                if (tds[i].style.display == "block")
                    {
                        if (document.getElementById(gridId+".imgRequired"+i))
                            {
                                document.getElementById(gridId+".imgRequired"+i).style.visibility = "hidden";                         
                            }
                    }
            }  
            
        //setTimeout('document.getElementById(gridId+".dvGeral").scrollTop = 10000;', 50);                                          
    }
    
//Exibe o Controle para Atualizacao dos Registros.    
function UpdateRow(oID)
    {
        var oTable = document.getElementById(gridId);
        var oTableData = document.getElementById(gridId+".tbEditData");        
        var trs = oTable.getElementsByTagName("tr");
        var tds = oTableData.getElementsByTagName("td");      

		var xmlDoc = document.getElementById(xmlData);
		var children = xmlDoc.documentElement.childNodes;
		var oIndexNode;        
		var intFoco;
		var strDescGrid;

        //Caso a Edicao do Registro seja em Tela ao Inves do Proprio Grid.
        if (cfgTipoEdicao.toUpperCase() == "TELA")
            {
                retornaRegistro(ChooseRow(oID)); 
                return
            }            
            
        //Acha o Indice da Linha.
        for (var i = 0; i < children.length; i++)
            {
                if (children[i].childNodes[pkField].firstChild.nodeValue == oID)
                    {
                        oIndexNode = i;
                        break;
                    }
            }
                        
        //Exibe o Div de Alteracao.
        document.getElementById(gridId+".dvEdit").style.display = "block";
        
        //Modifica o Titulo da Aba para "Editar".
        document.getElementById(gridId+".tbEditTitle").getElementsByTagName("td")[0].innerHTML = "Editar";

        //Altera o Link de Confirmacao para funcao de "Alteracao".
        if (document.getElementById(gridId+".btConfirma") != null)
        {
            if(arguments[1] != null)
                document.getElementById(gridId+".btConfirma").href = "javascript:selecionar_LinkSalvar" + arguments[1] + "('U','"+oIndexNode+"');"
            else
                document.getElementById(gridId+".btConfirma").href = "javascript:confirmaAcao('U','"+oIndexNode+"');"
        }

        //Verifica em qual "TR" o Div de Edicao deve Aparecer.
        for (var i = 0; i < trs.length; i++) 
            {
                if (trs[i].innerHTML.indexOf("UpdateRow('"+oID+"')") != -1)
                    {
                        var trTop = trs[i].offsetTop;
                        
                        document.getElementById(gridId+".dvEdit").style.top = trTop - 18;                  
                    }
            }

        //Verifica o Tipo de Controle para Atribuicao dos Dados.
        for (var i = 0; i < tds.length; i++) 
            {
                if (tds[i].style.display == "block")
                    {   
                        if ((document.getElementById(gridId+".Element"+i).disabled == false) && (document.getElementById(gridId+".Element"+i).readOnly == false) && (intFoco == undefined))
                        {
                            intFoco = i;
                            document.getElementById(gridId+".Element"+intFoco).focus();
                        }
                        //Verifica o Tipo de Controle para Atribuicao dos Dados.
                        switch(document.getElementById(gridId+".Element"+i).type)
                            {
                                case "text":
                                    if (children[oIndexNode].childNodes[i].firstChild)
                                        {
                                            if (trim(children[oIndexNode].childNodes[i].firstChild.nodeValue) == "-")
                                            {
                                                document.getElementById(gridId+".Element"+i).value = "";
                                            }
                                            else
                                            {
                                                document.getElementById(gridId+".Element"+i).value = children[oIndexNode].childNodes[i].firstChild.nodeValue;
                                            }   
                                        }
                                    else
                                        {
                                            document.getElementById(gridId+".Element"+i).value = "";
                                        }                                    
                                    break
                                case "span":
                                    if (children[oIndexNode].childNodes[i].firstChild)
                                        {
                                            if (children[oIndexNode].childNodes[i].firstChild.nodeValue == "-")
                                            {
                                                document.getElementById(gridId+".Element"+i).innerText = "";
                                            }
                                            else
                                            {
                                                document.getElementById(gridId+".Element"+i).innerText = children[oIndexNode].childNodes[i].firstChild.nodeValue;
                                            }   
                                        }
                                    else
                                        {
                                            document.getElementById(gridId+".Element"+i).innerText = "";
                                        }                                    
                                    break
                                case "select-one":
                                    var ocomboBox = document.getElementById(gridId+".Element"+i);
                                    for( var w = 0; w < ocomboBox.options.length; w++ )
                                        {
                                            if (children[oIndexNode].childNodes[i].firstChild)
                                                {
                                                    if (children[oIndexNode].childNodes[i].firstChild.nodeValue == ocomboBox.options[w].text)
                                                        {
                                                           ocomboBox.selectedIndex = w; 
                                                        }                                                
                                                }
                                            else
                                                {
                                                    ocomboBox.selectedIndex = 0;
                                                }
                                        }
                                    break
                                case "checkbox":
                                    var ocheckBox = document.getElementById(gridId+".Element"+i);
                                    if (children[oIndexNode].childNodes[i].firstChild)
                                        {
                                            if (children[oIndexNode].childNodes[i].firstChild.nodeValue == "S")
                                                {
                                                   ocheckBox.checked = true; 
                                                }                          
                                            else
                                                {
                                                   ocheckBox.checked = false; 
                                                }                      
                                        }
                                    else
                                        {
                                            ocheckBox.checked = false; 
                                        }
                                    break                                    
                            }                      
                    }
            }      
            
        //Limpa as Obrigatoriedades.
        for (var i = 0; i < tds.length; i++) 
            {
                if (tds[i].style.display == "block")
                    {
                        if (document.getElementById(gridId+".imgRequired"+i))
                            {
                                document.getElementById(gridId+".imgRequired"+i).style.visibility = "hidden";                         
                            }
                    }
            }                                     
    }    
    
//Procura o ID para a Pesquisa dos Dados.
function findId()
    {
        var elTd = document.getElementsByTagName("td");
        var oCountTd = 0;
        
        //Verifica qual Radio foi Checkado.
		while (elTd[oCountTd])
			{
			    if (elTd[oCountTd].type == "Escolher" && elTd[oCountTd].innerHTML.indexOf("CHECKED") != -1)
			        {
			            var oID = elTd[oCountTd+1].innerHTML.substring(elTd[oCountTd+1].innerHTML.indexOf("'")+1,elTd[oCountTd+1].innerHTML.lastIndexOf("'"));
			            
			            //Devolve o Resultado via Funcao.
                        ChooseRow(oID); 
                        break	            
			        }
			        
				oCountTd += 1;
			}
    }
        
//Escolha o Registro do Grid.
function ChooseRow(oID)
    {
		var xmlDoc = document.getElementById(xmlData);
		var children = xmlDoc.documentElement.childNodes;
        var oIndexNode;
        var arrValues = new Array;
        var oColumnsxml = 0;       
        
        //Acha o Indice da Linha.
        for (var i = 0; i < children.length; i++)
            {
                if (children[i].childNodes[pkField].firstChild.nodeValue == oID)
                    {
                        oIndexNode = i;
                        break;
                    }
            }


        //Passa o xml para um Array.
		while (children[oIndexNode].childNodes[oColumnsxml])
			{
			    //Verifica se O No do XML esta com Informacao.
			    if (children[oIndexNode].childNodes[oColumnsxml].firstChild)
			        {
			            arrValues[oColumnsxml] = children[oIndexNode].childNodes[oColumnsxml].firstChild.nodeValue;
			        }
			    else
			        {
			            arrValues[oColumnsxml] = "";
			        }			    

				oColumnsxml += 1;
			}

        //Retira os Ultimos indices do array que mencionam os campos "ALTERAR/EXCLUIR/ESCOLHER" do xml.
        arrValues.splice(arrValues.length -3,3);	   
	    
	    //Verifica se o Retorno sera feito pelo "ShowModalDialog".
	    if (showModalOn.toUpperCase() == "ON")
	        {
	            //Retorna o Valor do Objeto "showModalDialog" para a tela "Parent".	            
		        window.returnValue = arrValues.toString();
		        window.close();		        
	        }
        else
            {
                //Retorna o Valor da para a Propria Tela.
                return arrValues.toString();
            }
    }   

//Funcao para Retorno de Dados.
function confirmaAcao(oType,oID)
    {
		var xmlDoc = document.getElementById(xmlData);
		if (xmlDoc.documentElement != null)
		{
		    var children = xmlDoc.documentElement.childNodes;
		}
		var oColumnsxml = 0;
		    
        var oTable = document.getElementById(gridId+".tbEditData");        
        var tds = oTable.getElementsByTagName("td");
        var arrValues = new Array;

        if (!VerifyRequiredFields())
            {
                alert("Por Favor, Preencha os Campos Obrigatórios (*).");
                return
            }
        
        if (oType == "U")
            {
                //Passa o xml para um Array.
		        
		        while (children[oID].childNodes[oColumnsxml])
			        {
			            //Verifica se O No do XML esta com Informacao.
			            if (children[oID].childNodes[oColumnsxml].firstChild)
			                {
			                    arrValues[arrValues.length] = children[oID].childNodes[oColumnsxml].firstChild.nodeValue;
			                }
			            else
			                {
			                    arrValues[arrValues.length] = "";
			                }			    

				        oColumnsxml += 1;
			        }             
            
                //Retira os Ultimos indices do array que mencionam os campos "ALTERAR/EXCLUIR/ESCOLHER" do xml.
                arrValues.splice(arrValues.length -3,3);
            }                                                                             
                                    
        //Recupera os Valores dos Elementos.
        for (var i = 0; i < tds.length; i++) 
            {
                if (tds[i].style.display == "block")
                    {
                        if (document.getElementById(gridId+".Element"+i).value != undefined){
                            if (document.getElementById(gridId+".Element"+i).type == "checkbox")
                                arrValues[i] = document.getElementById(gridId+".Element"+i).checked;
                            else
                                arrValues[i] = document.getElementById(gridId+".Element"+i).value;
                        }else{
                            arrValues[i] = document.getElementById(gridId+".Element"+i).innerHTML;
                        }
                    }
            }            
        
        //Torna o Controle Invisivel.
        cancelaAcao(); 
                
        //Verifica o Tipo de Acao a Ser Tomada.
        if (oType == "I")
            {
                insereRegistro(arrValues);
            }
        else
            {
                if (arguments[2] != null)
                    alteraRegistro(arrValues, arguments[2]);
                else
                    alteraRegistro(arrValues);
            }                         
    }

//Funcao para Cancelamento de Inclusao de Novos Registros via Grid.
function cancelaAcao()
    {
        var nomeGrid;
        
        if (event && event.srcElement){
            oTitle = event.srcElement;
            oTitle.id = oTitle.id + "";
            if (oTitle.id.indexOf('grd') != -1){
                nomeGrid = oTitle.id.split(".")[0];
            }else{
                if (oTitle.parentElement && oTitle.parentElement.id && oTitle.parentElement.id.indexOf('grd') != -1){
                    nomeGrid = oTitle.parentElement.id.split(".")[0];
                }else{
                    oTitle = document.getElementById(gridId);
                    nomeGrid = gridId;
                }
            }
        }else{
            oTitle = document.getElementById(gridId);
            nomeGrid = gridId;
        }
        
        document.getElementById(nomeGrid+".dvGeral").scrollTop = 0;
        document.getElementById(nomeGrid+".dvEdit").style.display = "none";
    }
    

//************************************ FUNCOES DE APOIO E TRATAMENTO AO GRID ***************************************//  
//                                                                                                                  //
//                                                                                                                  //
//******************************************************************************************************************//

//Recupera o Caminho Default da Aplicacao.
function pathDefault()
    {
        var path = new String(parent.top.location);
        var arrayPath = "";
        var concatPath = "";
        
        arrayPath = path.split("/");
        pathSource = "";
        
        for ( i = 0; i < arrayPath.length; i++ )
        {
            concatPath += arrayPath[i] + "/";

            if (i == 2 || (i == 3 && arrayPath[i] != 'menu.asp'))
            {
                pathSource = concatPath.substr(0,concatPath.length-1);
            }
        }
    }
	
//Limpa os Caracteres das Expressoes;
function replaceAll(str, replacements) {
    replacements = [[",",""],["&nbsp;"," "],["'",""],["[",""],["]",""]];
    
    for ( i = 0; i < replacements.length; i++ ) {
        var idx = str.indexOf( replacements[i][0] );

        while ( idx > -1 ) {
            str = str.replace( replacements[i][0], replacements[i][1] ); 
            idx = str.indexOf( replacements[i][0] );
        }
    }

    return str;
}

//Calendario
function showCalendario(elTarget)
    {
        {
            var sRtn = showModalDialog(pathSource + "/includes/calendar.asp","","center=yes;dialogWidth=307px;dialogHeight=170px;status=no");
                
            if (sRtn!="") 
                {
                    
	                document.getElementById(elTarget).value = sRtn;
	                document.getElementById(elTarget).focus();       
                }                     
        }
    }

//Verifica se e do DataType Numerico.
function isNumeric(pNum){
	if (pNum==''){
		return false;
		}
	for (var i = 0; i < pNum.length; i++){
		var ch = pNum.substring(i, i + 1);
		if ((ch < '0' || '9' < ch) && (ch != "." && ch != ",")){
			return false;
		}
	}
		return true;
}

//Valida Campos de Data.
function IsDate(oDate){

    var dtNovaData;
    try
    {
        dtNovaData = new Date();
        
        var Data = oDate.value.split("/")
        
        if (Data.length > 2)
        {
            if (Data[2].length < 4)
            {
                Data[2] = dtNovaData.getFullYear();
            }
        }
        else
        {
            Data[2] = dtNovaData.getFullYear();
        }
        
        var nData = new Date(Data[2]+"/"+Data[1]+"/"+Data[0]+" "+"01:00:00");
        if (nData.getDate() == Data[0] && nData.getMonth() + 1 == Data[1] &&
            nData.getFullYear() == Data[2])
        {
            oDate.value = ((Data[0].length < 2)? "0" + Data[0] : Data[0]) + '/' + ((Data[1].length < 2)? "0" + Data[1] : Data[1]) + '/' + Data[2];
            
            return true;
        }
        else
        {
            return false;
        }
    }
    catch (ex)
    {
        return false;
    }	
}

function isNumericTextBoxHoraGrid(txtText)
{
    var strTecla = event.keyCode;
    var strValor = new String();
    var strMinuto;

    if(strTecla > 47 && strTecla < 58)
    {
        for (var intCont = 0; intCont < txtText.value.length; intCont++) {
            if (!validaNumero(txtText.value.charAt(intCont))) {
                txtText.value = '';
                event.keycode = 0;
                return;
            }
        }
        strValor = txtText.value;
        if(strValor.length == 2)
        {
            if (eval(strValor) < 0 || eval(strValor) > 23)
            {
                txtText.value = '';
                return true;
            }
            else
            {
                txtText.value += ':';
                return true;
            }
        }
        
        if (strValor.length == 4)
        {
          strMinuto = strValor.substr(strValor.length-1,1);
          
          if (eval(strMinuto) < 0 || eval(strMinuto) > 5)
            {
                txtText.value = strValor.split(':')[0] + ':';
                return true;
            }  
        }
            	    
    }
    else
        event.keyCode = 0;
}

//Verifica se e do DataType AlphaNumerico.
function isAlphaNumeric(pSymbol)
    {                   
        if (!isNumeric(pSymbol.value))
        {
            if (pSymbol.value.length > 0)
            {
                pSymbol.value = pSymbol.value.substr(0, pSymbol.value.length - 1)
            }
        }
    }        

//Configuracao dos Parametros do Objeto.
function ConfigGrid(oxmlData,ogridId,opkField,oshowModalOn,ocfgTipoGravacao,ocfgTipoEdicao,ocfgPaginacao,ogetRegister, ocfgAcesso, ocfgCtrAcesso)
    {
        xmlData = oxmlData;
        gridId = ogridId;
        pkField = opkField;
        showModalOn = oshowModalOn;
        cfgTipoGravacao = ocfgTipoGravacao;
        cfgTipoEdicao = ocfgTipoEdicao;
        cfgPaginacao = ocfgPaginacao;
        getRegister = ogetRegister;
        if (ocfgAcesso != undefined)
            cfgAcesso = ocfgAcesso;
        if (ocfgCtrAcesso != undefined)
            cfgCtrAcesso = ocfgCtrAcesso;
        
        //Chama a Funcao que Recupera o Caminho Padrao da Aplicacao.
        pathDefault();            
    }
 
//Executa o Bind do Grid;
function GridBind()
    {
        var oTimer = setTimeout('GridBind();', 200);        
        var xmlDoc = document.getElementById(xmlData);
                
        if (xmlDoc.documentElement)
            {
                var children = xmlDoc.documentElement.childNodes;                           

                document.getElementById(gridId).style.display = "block";
                document.getElementById(gridId+".dvGeral").style.display = "block";
                document.getElementById(gridId+".dvTitle").style.display = "block";
                
                //Evita o erro quando todas as linhas forem excluídas
                if (document.getElementById(gridId+".dvBody"))
                    document.getElementById(gridId+".dvBody").style.display = "block";
                    
                document.getElementById(gridId+".showPager").style.display = "block";
                document.getElementById(gridId+".dvLoad").style.display = "none"; 
                
                MostrarReg(gridId);               
                setTimeout("stripedTable('"+gridId+"')", 500);
                
                document.getElementById(gridId+".dvGeral").scrollTop = 0;
                document.getElementById(gridId+".dvTitle").scrollTop = 0;

                if (getRegister != "S")
                    {
                        if (children[0].childNodes[pkField].text == "xkzID0")
                            {
                                document.getElementById(gridId+".dvTitle").style.display = "block";
                                document.getElementById(gridId+".dvBody").style.display = "none";
                            }                                                    
                    }                                  
                    
                clearTimeout(oTimer);
                
                setTimeout("validarAcessoGrid()", 200);
            }        
    }

//Funcao que Limpa os Nodes do Registro Clonado do XML.
function ClearXml()
    {
        var xmlDoc = document.getElementById(xmlData)
        var oColumnsxml = 0;

        if (xmlDoc.documentElement)
            {
                var children = xmlDoc.documentElement.childNodes;

                //Caso Não Exista nenhum Registro na Base de Dados, Atualiza o Valor do Primeiro
                //No do XML para Branco.
                if (children[0].childNodes[pkField].firstChild.nodeValue == "xkzID0" || children[0].childNodes[pkField].firstChild.nodeValue == "")
                    {
                        xmlDoc.documentElement.removeChild(children[0]);                                                                                  
                    }
            }                          
    }
    
//Verifica Campos Obrigatorios.
function VerifyRequiredFields()
    {
        var oTable = document.getElementById(gridId+".tbEditData");        
        var tds = oTable.getElementsByTagName("td");
        var oReturn = true;

        //Verifica quais Elementos sao Obrigatorios.
        for (var i = 0; i < tds.length; i++) 
            {
                if (tds[i].style.display == "block")
                    {
                        if (document.getElementById(gridId+".imgRequired"+i))
                            {
                                if (document.getElementById(gridId+".imgRequired"+i).disabled == false)
                                    {
                                        if (document.getElementById(gridId+".Element"+i).value == "" || document.getElementById(gridId+".Element"+i).value == "-")
                                            {
                                                document.getElementById(gridId+".imgRequired"+i).style.visibility = "visible";
                                                oReturn = false;                                    
                                            }                        
                                    }
                            }
                    }
            }
            
        return oReturn;       
    }

//Permite a Rolagem do Cabecalho e dos Comandos.    
function scrollTitle() 
    {
        var oTitle;
        var nomeGrid;
        
        if (event && event.srcElement){
            oTitle = event.srcElement;
            oTitle.id = oTitle.id + "";
            if (oTitle.id.indexOf('grd') != -1){
                nomeGrid = oTitle.id.split(".")[0];
            }else{
                oTitle = document.getElementById(gridId);
                nomeGrid = gridId;
            }
        }else{
            oTitle = document.getElementById(gridId);
            nomeGrid = gridId;
        }
        
        var oTdsTitle = oTitle.getElementsByTagName("td");        
        
        document.getElementById(nomeGrid+".tbEditTitle").style.left = document.all[nomeGrid+'.dvGeral'].scrollLeft;
        document.getElementById(nomeGrid+".tbEditCommand").style.left = document.all[nomeGrid+'.dvGeral'].scrollLeft;        
                                
        for (var i = 0; i < oTdsTitle.length; i++) 
            {                    
                if (oTdsTitle[i].type == "CabBotao")
                    {
                        oTdsTitle[i].style.position = "relative";
                        oTdsTitle[i].style.zIndex = "11";
                        oTdsTitle[i].style.top = document.all[nomeGrid+'.dvGeral'].scrollTop;
                        oTdsTitle[i].style.left = document.all[nomeGrid+'.dvGeral'].scrollLeft;                       
                    }
                if (oTdsTitle[i].type == "CabLinha")
                    {
                        oTdsTitle[i].style.zIndex = "7";
                        oTdsTitle[i].style.position = "relative";
                        oTdsTitle[i].style.left = document.all[nomeGrid+'.dvGeral'].scrollLeft;
                    }
                if (oTdsTitle[i].type == "CabCorpo")
                    {
                        oTdsTitle[i].style.zIndex = "8";
                        oTdsTitle[i].style.position = "relative";
                        oTdsTitle[i].style.top = document.all[nomeGrid+'.dvGeral'].scrollTop;
                    }
                if (oTdsTitle[i].type == "Alterar" || oTdsTitle[i].type == "Excluir" || oTdsTitle[i].type == "Escolher")
                    {
                        oTdsTitle[i].style.zIndex = "10";
                        oTdsTitle[i].style.position = "relative";
                        oTdsTitle[i].style.left = document.all[nomeGrid+'.dvGeral'].scrollLeft;
                    }                                                                               
            }        
    }	

//Zebrado da Tabela.
function stripedTable(oGridID) 
    {
        var oTitle = document.getElementById(oGridID);
        var oTrsTitle = oTitle.getElementsByTagName("tr");            
            
        for (var i = 0; i < oTrsTitle.length; i++) 
            {                    
                if (i > 0)
                    {         
                        for (var x = 0; x < oTrsTitle[i].getElementsByTagName("td").length; x++)
                            {
                                oTrsTitle[i].getElementsByTagName("td")[x].className = "iftab3branco";
                            }
                                               
                    }
             }  
                         
        for (var i = 0; i < oTrsTitle.length; i+=2) 
            {                    
                if (i > 0)
                    {         
                        for (var x = 0; x < oTrsTitle[i].getElementsByTagName("td").length; x++)
                            {
                                oTrsTitle[i].getElementsByTagName("td")[x].className = "iftab2cinza";
                            }
                                               
                    }
             }     
    }

//************************************ FUNCOES DE PAGINACAO DO GRID ************************************************//  
//                                                                                                                  //
//                                                                                                                  //
//******************************************************************************************************************//

//Funcao que adianta o Paginador.
function GoPage()
    {    
        var xmlDoc = document.getElementById(xmlData);
        var xmlRecordSet = xmlDoc.recordset;
        var children = xmlDoc.documentElement.childNodes;
        var oGrid = document.getElementById(gridId);
        var oCount = document.getElementById("txtGoPage").value;
        if(document.all('txtGoPage').length > 1){
            if(event && event.srcElement && event.srcElement.id == 'txtGoPage'){
                oCount = event.srcElement.value
            }
        }
        var intKeyCode = ((arguments[0] == null) ? 0 : arguments[0]);

        if (event.keyCode == 13 || intKeyCode == '13')
            {
                if (isNumeric(oCount))
                    {
                        //Verifica se a Paginacao sera Automatica ou Manual.
                        if (cfgPaginacao.toUpperCase() == "MANUAL")
                            {
                                  irParaPagina();
                            }      
                        else
                            {
                                document.getElementById(gridId+".dvGeral").scrollTop = 0;
                                document.getElementById(gridId+".dvEdit").style.display = "none";
        
                                xmlRecordSet.moveFirst();
                                oGrid.firstPage();

                                if (oCount == 1)
                                    {
                                        document.getElementById(gridId+".showGoPager").innerHTML = "<input type=\"text\" id=\"txtGoPage\" class=\"cxtextbranca\" style=\"width:20px;text-align:center;\" value=\""+xmlRecordSet.absoluteposition+"\" onKeyPress=\"GoPage();\" onKeyUp=\"isAlphaNumeric(this);\"> <font style=\"font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 10px; color: black;\"> de "+xmlRecordSet.pagecount+"</font>";
                                        PagerShow(gridId);
                                        setTimeout("stripedTable('"+gridId+"')", 500);
                                        return
                                    }

                                for (var i = 1; i < oCount; i++)
                                    {
                                        moveNext();
                                    } 
                                
                                PagerShow(gridId);
                                setTimeout("stripedTable('"+gridId+"')", 500);                               
                            }                                                      
                    }        
            }
    }

//Funcao que Mostra/Esconde as Setas de Avancar e Retroceder.
function PagerShow(oGridId)
    {
        var xmlDoc = document.getElementById(xmlData)
        var xmlRecordSet = xmlDoc.recordset;
        
        if (xmlRecordSet.absoluteposition <= 1)
            {
                document.getElementById(oGridId+".mPrevious").style.display = "none";
            }
        else
            {
                document.getElementById(oGridId+".mPrevious").style.display = "block";
            }
            
        if (xmlRecordSet.absoluteposition >= xmlRecordSet.pageCount)
            {
                document.getElementById(oGridId+".mNext").style.display = "none";
            }
        else
            {
                document.getElementById(oGridId+".mNext").style.display = "block";
            }                      
    }
    
//Exibe a Quantidade de Registros.
function MostrarReg(oGridID)
    {
        var xmlDoc = document.getElementById(xmlData);
        
        if (xmlDoc.documentElement)
            {
                document.getElementById(oGridID+".showGoPager").innerHTML = "<input type=\"text\" id=\"txtGoPage\" class=\"cxtextbranca\" style=\"width:20px;text-align:center;\" value=\""+xmlDoc.recordset.absoluteposition+"\" onKeyPress=\"GoPage();\" onKeyUp=\"isAlphaNumeric(this);\"> <font style=\"font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 10px; color: black;\">de "+xmlDoc.recordset.pagecount+"</font>";             
                PagerShow(oGridID);            
            }        
    }

//Avanca a Paginacao do Grid e do RecordSet;
function moveNext()
    {
        var xmlDoc = document.getElementById(xmlData).recordset;
        var oGrid = document.getElementById(gridId);
        
        document.getElementById(gridId+".dvGeral").scrollTop = 0;
        document.getElementById(gridId+".dvEdit").style.display = "none";
        
        //Verifica se a Paginacao sera Automatica ou Manual.
        if (cfgPaginacao.toUpperCase() == "MANUAL")
            {
                  cancelaAcao();
                  moverProxima();
            }
        else
            {
                if (xmlDoc.absoluteposition >= xmlDoc.pagecount) 
                    {
                        cancelaAcao();
                        PagerShow(gridId);
	                    return
                    }
                else
                    {
                        cancelaAcao();
                        xmlDoc.moveNext();
                        oGrid.nextPage();        
                    }
                
                document.getElementById(gridId+".showGoPager").innerHTML = "<input type=\"text\" id=\"txtGoPage\" class=\"cxtextbranca\" style=\"width:20px;text-align:center;\" value=\""+xmlDoc.absoluteposition+"\" onKeyPress=\"GoPage();\" onKeyUp=\"isAlphaNumeric(this);\"><font style=\"font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 10px; color: black;\"> de "+xmlDoc.pagecount+"</font>";
                PagerShow(gridId);    
                setTimeout("stripedTable('"+gridId+"')", 500);                         
            }        
    }
    
//Retrocede a Paginacao do Grid e do RecordSet;
function movePrevious()
    {
        var xmlDoc = document.getElementById(xmlData).recordset;
        var oGrid = document.getElementById(gridId);     
	    
	    document.getElementById(gridId+".dvGeral").scrollTop = 0;
        document.getElementById(gridId+".dvEdit").style.display = "none";
	    
	    //Verifica se a Paginacao sera Automatica ou Manual.
        if (cfgPaginacao.toUpperCase() == "MANUAL")
            {
                  cancelaAcao();
                  moverAnterior();
            }
        else
            {
	            if (xmlDoc.absoluteposition <= 1)
	                {
	                    cancelaAcao();
	                    PagerShow(gridId);
	                    return
	                }
	            else
	                {
	                    cancelaAcao();
                        xmlDoc.movePrevious();
                        oGrid.previousPage();      
	                }
        	        
                document.getElementById(gridId+".showGoPager").innerHTML = "<input type=\"text\" id=\"txtGoPage\" class=\"cxtextbranca\" style=\"width:20px;text-align:center;\" value=\""+xmlDoc.absoluteposition+"\" onKeyPress=\"GoPage();\" onKeyUp=\"isAlphaNumeric(this);\"><font style=\"font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 10px; color: black;\"> de "+xmlDoc.pagecount+"</font>";        
                PagerShow(gridId);          
                setTimeout("stripedTable('"+gridId+"')", 500);  
            }	    
    }       
    
    //evita que o grid aceite valores não validados se nenhum registro for selecionado no pop-up ou se digitar o mesmo valor após validação
    //Thiago Jardim Gaona, 23/08/2006
    function autoComplete_onBlurGrid(strFuncao, txtText){
        var intIndex = txtText.id.substr(parseInt(txtText.id.lastIndexOf('t')) + 1);
        
        if (txtText.value != '')
        {
            if (txtText.value == strCacheAutoComplete_Grid[intIndex])
            {
                if (txtText.value != strCacheAutoCompleteAux_Grid[intIndex])
                {   
                    for(var intCont = 0; intCont < strFuncao.length; intCont++)
                        strFuncao = strFuncao.replace("@","'");
                    eval(strFuncao);
                }
            }
            else
            {
                for(var intCont = 0; intCont < strFuncao.length; intCont++)
                    strFuncao = strFuncao.replace("@","'");
                eval(strFuncao);
            }
        }
    }
    // Função de validação de Acesso do grid
    // caso o paramentro cfgAcesso seja 'N', os botões Alterar e Editar ficam desativados.
    function validarAcessoGrid()
    {
        if (cfgAcesso == 'N')
        {
            var CancelaAlterar = (cfgCtrAcesso.indexOf("A") < 0)? false : true ;
            var CancelaExcluir = (cfgCtrAcesso.indexOf("E") < 0)? false : true ;
            var CancelaConfirma = (cfgCtrAcesso.indexOf("C") < 0)? false : true ;
            
            if (document.all.tdAlterar != undefined && CancelaAlterar)
            {
                if (document.all.tdAlterar.length == undefined)
                {
                    bloqControle(document.all.tdAlterar);
                }
                else
                {
                    for (var gContA = 0; gContA < document.all.tdAlterar.length; gContA++)
                    {
                        bloqControle(document.all.tdAlterar[gContA]);
                    }
                }
            }
            
            if (document.all.tdExcluir != undefined && CancelaExcluir)
            {
            
                if (document.all.tdExcluir.length == undefined)
                {
                        bloqControle(document.all.tdExcluir);
                }
                else
                {
                    for (var gContE = 0; gContE < document.all.tdExcluir.length; gContE++)
                    {
                        bloqControle(document.all.tdExcluir[gContE]);
                    }
                }
            }
            
    
            if (document.all.tdConfirma != undefined && CancelaConfirma)
            {
            
                if (document.all.tdConfirma.length == undefined)
                {
                        bloqControle(document.all.tdConfirma);
                }
                else
                {
                    for (var gContC = 0; gContC < document.all.tdConfirma.length; gContC++)
                    {
                        bloqControle(document.all.tdConfirma[gContC]);
                    }
                }
            }        
        }
        
    }
    
    
    
    
    function bloqControle(tdElemento)
    {
        var iCtrIni, iCtrTam;
        var sImgHTML, sBufHTML;
        
        sBufHTML = tdElemento.innerHTML;
        
        iCtrIni = sBufHTML.indexOf('<IMG');
        sImgHTML = sBufHTML.substr(iCtrIni);
        iCtrTam = sImgHTML.indexOf('>') + 1;
        sImgHTML = sImgHTML.substr(0, iCtrTam);
        
        sBufHTML = "<A style=\"cursor:not-allowed\">" + sImgHTML + "</A>";
        
        tdElemento.innerHTML = sBufHTML;
    }