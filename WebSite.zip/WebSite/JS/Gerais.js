﻿// JScript File

window.alert = msgBox;
window.confirm = msgBoxConfirm;

function msgBox(msg) { abre_MsgBox(msg, new Array("OK")); }
function msgBoxConfirm(msg) { return !abre_MsgBox(msg, new Array("OK", "Cancelar")); }

function getHost()
{
	var str_Host, astr_Host, str_Host_Origem;
    
	if (opener != null) {
		str_Host = self.opener.parent.top.location.toString().toLowerCase();
		str_Host = str_Host.substring(0,str_Host.lastIndexOf("/"));
	}
	else {    	
		str_Host = parent.top.location.toString().toLowerCase();	
		str_Host_Origem = str_Host;
		astr_Host = str_Host.split("//");
		str_Host = (astr_Host[0] + "//");
		astr_Host = astr_Host[1].split("/");
		
		if (astr_Host[1].lastIndexOf("integra") != -1  || astr_Host[1].lastIndexOf("website") != -1)
		{
			for (var iH = 0; iH < 2; iH++) {
				str_Host += (astr_Host[iH] + "/");
			}
		}
		else
		{
			for (var iH = 0; iH < 1; iH++) {
				str_Host += (astr_Host[iH] + "/");
			}
		}

		str_Host = str_Host.substring(0,(str_Host.length - 1));
	}
	return str_Host;
}

//Função para capturar o caminho do diretório virtual
function pathHost()
{
    return getHost();
}

var Host = pathHost();

function valida_numero(objElemento) {
    if (objElemento.value.length > 0) {
        if (!validaNumero(objElemento.value)) {
            alert("Este campo somente aceita valores numéricos");
            objElemento.value = '';
            objElemento.focus();
            return;
        }
    }
    return true;
}

//Busca Session do ASP 3.0.
function sessionASP(name)
{
    try
    {
        var SessionXML = new ActiveXObject("Msxml.DOMDocument");
        SessionXML.async = false 
        SessionXML.load(Host + "/RequestSession.asp?name=" + name);
        if (SessionXML.documentElement.childNodes[0].childNodes.length > 0 )
            return SessionXML.documentElement.childNodes[0].childNodes[0].nodeValue;
        else
        {
            //msgBox('A sua sessão expirou! Efetue o login novamente.');
            location.replace(Host + "/redirectAcesso.aspx?acesso=false");
            return null;
        }
    } catch (e)
    {
        alert("Erro: sessionASP()\nErro ao buscar Session: " + name);
        alert(e.message);
    }
}

function trim(pstr_Value) {
  try {
    var str_Result = pstr_Value;
    while(str_Result.indexOf("  ") != -1) {
      str_Result = str_Result.replace(/  /g," ");
    }
    if (str_Result.substring(0,1) == " ") {
      str_Result = str_Result.substring(1,str_Result.length);
    }
    if (str_Result.substring((str_Result.length - 1),str_Result.length) == " ") {
      str_Result = str_Result.substring(0,(str_Result.length - 1));
    }
    return str_Result;
  }
  catch(obj_Exception) {
    exception(obj_Exception,"General[trim]");
  } 
  finally {
    delete str_Result;
  }
}

function trim(pstr_Palavra) {
    var inicial=0;
    var final=pstr_Palavra.length;
    while (pstr_Palavra.charCodeAt(inicial)==32) {inicial++;}
    while (pstr_Palavra.charCodeAt(final-1)==32) {final--;}
    return(pstr_Palavra.substr(inicial,final-inicial));
}

//função para formatar o cabeçalho do grid quando o mesmo é dinâmico
//desenvolvido por Thiago Jardim, Thammy Gritti em 28/06/06
//pré-condições: todas as colunas do grid devem estar invisíveis e sem width.
function formatarGridDinamico(objGrid, intColunas, intQtdeBotoes){
    //parâmetros: objGrid: a referência do grid
    //            intColunas: vetor com todas as colunas que devem ficar visíveis
    var objEditData = document.all[objGrid.id + '.tbEditData']
    var intCont, intContRow;
    
    //Titulo do Grid
    for (intCont = 0; intCont < intColunas.length; intCont++)
        objGrid.rows(0).cells(intColunas[intCont] - (intQtdeBotoes - 1)).style.display = 'block' ;   
    
    //Edit Data
    for (intCont = 0; intCont < intColunas.length; intCont++)
        objEditData.rows(0).cells(intColunas[intCont] - intQtdeBotoes).style.display = 'block' ;   

//    for (intCont = 0; intCont < 27; intCont++)
//        objEditData.rows(0).cells(intCont).style.display = 'block' ;   
    
    //Corpo Grid
    for (intCont = 0; intCont < intColunas.length; intCont++){
        for (intContRow = 1; intContRow < objGrid.rows.length; intContRow++){
            objGrid.rows(intContRow).cells(intColunas[intCont]).style.display = 'block' ;   
        }
    }
}

function formatarLarguraGrid(objGrid, intQtdBotoes, intColunas, intWidthPadrao, intWidthOverflowPadrao)
{
    var intWidthBotoes = (intQtdBotoes == 1)? 55 : 60;
    
    var intCont, intContLin;
    var intcontwidth = 0;

    var objCorpoGrid = objGrid.getElementsByTagName('tr')[1].getElementsByTagName('td');
    var objEditData = document.getElementById(objGrid.id + '.tbEditData').getElementsByTagName('tr')[0].getElementsByTagName('td');

    for (intCont = 0; intCont < intColunas.length; intCont++)
    {
        if ((document.getElementById(objGrid.id).rows(0).cells(intColunas[intCont]).innerText.toUpperCase().indexOf('CONDUTOR') != -1) ||
            (document.getElementById(objGrid.id).rows(0).cells(intColunas[intCont]).innerText.toUpperCase().indexOf('GERENCIADORA') != -1))
        {
            intWidthPadrao = '230';
            intcontwidth += 230;
        }
        else
        {
            intWidthPadrao = '120';
            intcontwidth += 120;
        }
        objCorpoGrid[intColunas[intCont]].width = intWidthPadrao;
        objEditData[intColunas[intCont] - intQtdBotoes].width = intWidthPadrao;
        objEditData[intColunas[intCont] - intQtdBotoes].style.width = intWidthPadrao;

        for (intContLin = 1; intContLin < objGrid.getElementsByTagName('tr').length; intContLin++){
            objLinhaGrid = objGrid.getElementsByTagName('tr')[intContLin].getElementsByTagName('td');
            objLinhaGrid[intColunas[intCont]].width = intWidthPadrao;
        }
    }
    
    var intDiff = intWidthOverflowPadrao - (intcontwidth + intWidthBotoes);

    if((intcontwidth + intWidthBotoes) <= intWidthOverflowPadrao){
        objGrid.width = (intDiff >= 0) ? intWidthOverflowPadrao - intDiff : intWidthOverflowPadrao;
        document.getElementById(objGrid.id + '.tbEditData').width = (intDiff >= 0) ? (intWidthOverflowPadrao - intDiff - intWidthBotoes) : (intWidthOverflowPadrao - intWidthBotoes);
    }
    else{
        intCont = intcontwidth;

        objGrid.width = intCont;
        document.getElementById(objGrid.id + '.tbEditData').width = (intDiff >= 0) ? (intCont - intDiff - intWidthBotoes - 9) : (intCont - intWidthBotoes - 9);
    }
}

//Deixa com status invisível todas as colunas do Grid
function desabilita_ColunasGrid(objGrid, intQtdeBotoes)
{
    
    var objEditData = document.all[objGrid.id + '.tbEditData']
    var intCont, intContRow;
    
     //Titulo do Grid e Edit Data
    objEditData.rows(0).cells(0).style.display = 'none';
    
    for (intCont = 1; intCont < objGrid.rows(0).cells.length; intCont++)
    {
        objGrid.rows(0).cells(intCont).style.display = 'none' ;
        
        if(intCont != objGrid.rows(0).cells.length - 1)
        {
            objEditData.rows(0).cells(intCont).style.display = 'none' ;   
        }  
    }
        
    //Corpo Grid
    for (intCont = intQtdeBotoes; intCont < objGrid.rows(1).cells.length; intCont++)
    {
        for (intContRow = 1; intContRow < objGrid.rows.length; intContRow++)
        {
            objGrid.rows(intContRow).cells(intCont).style.display = 'none' ;   
        }
    }
}

//Transfere do DataTable Para List.
function dataTableToSelect(ListBox, tableOrigem, CampoText, CampoValue)
{
    for (var i = 0; i < tableOrigem.Rows.length; i++)
    {
        ListBox[ListBox.length] = new Option(tableOrigem.Rows[i][CampoText], tableOrigem.Rows[i][CampoValue], false);
    }
    selectColor(ListBox);
}

//Transfere os itens selecionado do List "Origem" ao List "Destino".
function selectToSelect(origem, destino)
{
    for(var i = 0; i < origem.length; i++)
    {
        if (origem.options[i].selected)
        {
            destino[destino.length] = new Option(origem[i].text, origem[i].value, false);
            origem[i] = null;
            i--;
        }
    }
    selectColor(origem);
    selectColor(destino);
}
//Deleta os itens selecionado do List.
function deleteSelect(List)
{
    for(var i = 0; i < List.length; i++)
    {
        if (List.options[i].selected)
        {
            List[i] = null;
            i--;
        }
    }
    selectColor(List);
}

//Copia os itens selecionado do List "Origem" ao List "Destino".
function copyToSelect(origem, destino)
{
    for(var i = 0; i < origem.length; i++)
    {
        if (origem.options[i].selected)
        {
            destino[destino.length] = new Option(origem[i].text, origem[i].value, false);
        }
    }
    selectColor(origem);
    selectColor(destino);
}

//Transfere e ordena o Select
function selectToSelectOrdena(origem, destino)
{
    selectToSelect(origem, destino);        
    sortSelect(origem);
    sortSelect(destino);
    selectColor(origem);
    selectColor(destino);
}

//Ordena o Select (Fonte Internet)
function sortSelect(obj){
    var o = new Array();
    for (var i=0; i<obj.options.length; i++){
        o[o.length] = new Option(obj.options[i].text, obj.options[i].value, obj.options[i].defaultSelected, obj.options[i].selected);
    }
    o = o.sort(
        function(a,b){ 
            if ((a.text+"") < (b.text+"")) { return -1; }
            if ((a.text+"") > (b.text+"")) { return 1; }
            return 0;
        } 
    );

    for (var i=0; i<o.length; i++){
        obj.options[i] = new Option(o[i].text, o[i].value, o[i].defaultSelected, o[i].selected);
    }
    
}

// Colore o Select no Padrão
function selectColor(obj)
{
    for(var i = 0; i < obj.length; i++)
    {
        if (i % 2 == 0)
            obj.options[i].className = 'iftab3branco';
        else
            obj.options[i].className = 'iftab2cinza';
    }
}


function reSizeSelect(obj)
{
    var total = obj.length * 18
    if (total < 120 )
    {
        obj.style.height =  "120px"
    }
    else
    {
        if (obj.length > 10)
        total = total - 15
        obj.style.height =  total + "px"
    }
}

//busca o valor de IDContrato nos campos hidden de Contratos
//SOMENTE PARA TELAS DE CONTRATOS
function obterIDContrato(){
    var intIDContrato = -1;
    for (var intCont = 0; intCont < parent.document.forms.length; intCont++){
        if (parent.document.forms[intCont].idcontrato != null)
            if (parent.document.forms[intCont].idcontrato.value != ''){
                intIDContrato = parent.document.forms[intCont].idcontrato.value;
                break;
            }
    }
    return intIDContrato;
}

//formata campos que só aceitem valores no formato hhh:mm
//Alterado por Marcos Tenorio - 26/07/2006
function formatarHora(txtText)
{
    var strValor  = new String();
    var strPosi;
    var strHora;
    var strMinuto;
    var blnHoraSimples = (txtText.id == 'txtHrCarga' || txtText.id == 'txtHrDescarga' || txtText.id == 'txtCarga' || txtText.id == 'txtDescarga' || txtText.id == 'txtCargaDescarga' || txtText.id == 'txtAduaneira') ? true : false;
    
    strValor = txtText.value;
    strValor = strValor.substr(0,6)  
    if(txtText.value == '') 
        return;

    strPosi = strValor.indexOf(':',1);
    if(strPosi >= 0){
        strHora	= strValor.split(':')[0];
        strMinuto = strValor.split(':')[1];
    }
    else{
        strValor = strValor.substr(0,6)  
        strHora  =  strValor.substr(0,3);
        //parte alterada começo
        if (strValor.length > 3){
            if (strValor.length == 4)
                strMinuto  =  strValor.substr(3,1);
            if (strValor.length == 5)
                strMinuto  =  strValor.substr(3,2);
            if (strValor.length == 6)
                strMinuto  =  strValor.substr(3,2);
        }
        //parte alterada fim
        else
            strMinuto = '0';
    }
    strHora	= '000' + strHora;
    strHora = (blnHoraSimples) ? strHora.substr(strHora.length-2,2) : strHora.substr(strHora.length-3,3);
    strMinuto = '00' + strMinuto;
    strMinuto = strMinuto.substr(strMinuto.length-2,2);
    
    if(strMinuto > 59 || strMinuto < 0){
        txtText.value = (blnHoraSimples) ? '00:00' : '000:00';
        return; 
    }  
    txtText.value = strHora + ':' + strMinuto;
}

//função que só permite que o usuário digite valores numéricos
function isNumericTextBox(txtText)
{
    var strTecla = event.keyCode;
    var strValor = new String();

    if(strTecla > 47 && strTecla < 58){
        strValor = txtText.value;
        if(strValor.length == 3 && (txtText.id == 'txtTempoPadrao' || txtText.id == 'txtHrSaida' || txtText.id == 'txtToleranciaDe' || txtText.id == 'txtToleranciaAte'  || txtText.id == 'txtHrChegada' || txtText.id == 'txtHoraAte' || txtText.id == 'txtHoraDe' || txtText.id == 'txtToleranciaAtraso' )) //só adiciona : se for campo de hora
	        txtText.value += ':';
	        
	    if(strValor.length == 2 && (txtText.id == 'txtCarga' || txtText.id == 'txtDescarga' || txtText.id == 'txtCargaDescarga' || txtText.id == 'txtAduaneira')) //só adiciona : se for campo de hora
	        txtText.value += ':';
        
        return true;
            
    }
    else
        event.keyCode = 0;
}

function Valida_isNumeric(txtText)
{
    var strTecla = event.keyCode;
    var strValor = new String();

    if(strTecla > 47 && strTecla < 58)
    {       
       return true;
    }
    else
        if(strTecla != 44 && strTecla != 46)
        {
            event.keyCode = 0;
        }
}

function validaNumero(txtText) {
    
    var strCharacter;
    
    if (txtText.length > 0) {
        
        for (var intCont = 0; intCont < txtText.length; intCont++) {
            strCharacter = txtText.charCodeAt(intCont);
            if (strCharacter < 47 || strCharacter > 58) {
                return false;
            }
        }
        return true;
    }
}


//formata campos que só aceitem valores no formato hh:mm
function formatarHoraReal(txtText)
{
    var strValorDigitado;
    var strHoraDigitada;
    var strMinDigitado;
    var strPosi;
    var strMinuto;
    var strHora;
    
    strValorDigitado = txtText.value;
      
    if(txtText.value == '')
    {
        return;
    } 
    
    strPosi = strValorDigitado.indexOf(':',1);
    
    //Verifica se já foi digitado o minuto
    if(strPosi >= 0) //Se sim
    {
        strHora	= strValorDigitado.split(':')[0];
        strMinuto = strValorDigitado.split(':')[1];
    }
    else
    {
        strValorDigitado = strValorDigitado.substr(0,5)  
        strHora  =  strValorDigitado.substr(0,2);
        strMinuto = '00'
    }
    
    strHora	= '00' + strHora;
    strHora = strHora.substr(strHora.length-2, 2);
    
    strMinuto = '00' + strMinuto;
    strMinuto = strMinuto.substr(strMinuto.length-2,2);
    
    if (eval(strHora) > 23 || eval(strHora) < 0)
    {
       strHora = 23; 
    }
    
    if (eval(strMinuto) > 59 || eval(strMinuto) < 0)
    {
      strMinuto = 59
    }  
    txtText.value = strHora + ':' + strMinuto;
    return true;
}

 //função que só permite que o usuário digite valores numéricos
 function isNumericTextBoxHora(txtText)
 {
    var strTecla = event.keyCode;
    var strValor = new String();
    var strMinuto;

    if(strTecla > 47 && strTecla < 58)
    {
        for (var intCont = 0; intCont < txtText.value.length; intCont++) {
            if (!validaNumero(txtText.value.charAt(intCont))) {
                txtText.value = '';
                event.keycode = 0;
                return;
            }
        }
        strValor = txtText.value;
        if(strValor.length == 2 && (txtText.id == 'nrPrazoJanela' || txtText.id == 'nrReutVeicMot' || txtText.id == 'txtHoraEvento' || txtText.id == 'txtHrSaida' || txtText.id == 'txtToleranciaDe' || txtText.id == 'txtToleranciaAte'  || txtText.id == 'txtHrChegada' || txtText.id == 'txtHrCarga' || txtText.id == 'txtHrDescarga' || txtText.id == 'txtHoraAte' || txtText.id == 'txtHoraDe' || txtText.id == 'txtHrInicio' || txtText.id == 'txtHrTermino' || txtText.id == 'txtDetConHoraSaida')) //só adiciona : se for campo de hora
        {
            if (eval(strValor) < 0 || eval(strValor) > 23)
            {
                txtText.value = '';
                return true;
            }
            else
            {
                txtText.value += ':';
                return true;
            }
        }
        
        if (strValor.length == 4)
        {
          strMinuto = strValor.substr(strValor.length-1,1);
          
          if (eval(strMinuto) < 0 || eval(strMinuto) > 5)
            {
                txtText.value = strValor.split(':')[0] + ':';
                return true;
            }  
        }
            	    
    }
    else
        event.keyCode = 0;
 }
 
 //Inseri a barra na data 
 function isNumericTextBoxData(txtText)
 {
    var strTecla = event.keyCode;
    var strValor = new String();
    var strValidar = new Array();
    var strDia;
    var strMes;
    var strAno;
    var blnValidar = true;
   
    strValor = txtText.value;

    if(strTecla > 47 && strTecla < 58)
    {
        strValidar = strValor.split('/');
        
        if (strValidar.length == 1)
        {
            strDia = strValidar[0];
        }
        
        if (strValidar.length == 2)
        {
            strDia = strValidar[0];
            strMes = strValidar[1];
        }
        
        if (strValidar.length == 3)
        {
            strDia = strValidar[0];
            strMes = strValidar[1];
            strAno = strValidar[2];
        }
        
        if (strValor.length == 2) 
        {
            if (eval(strDia) <= 0 || eval(strDia) > 31)
            {
                txtText.value = '';
                blnValidar = false;   
            }
        }
        
        if (strValor.length == 5) 
        {
            if (eval(strMes) <= 0 || eval(strMes) > 12)
            {
                txtText.value = strDia + '/';
                blnValidar = false;   
            }
        }
        
         if (blnValidar == true && (strValor.length == 2 || strValor.length == 5))
         {
            txtText.value += '/';
         }
    }
    else
    {
         event.keyCode = 0; 
    }
 }

 //Função para validação de Data
function validaData(txtData)
{        
    var dtNovaData;
    try
    {
        dtNovaData = new Date();
        
        var Data = txtData.value.split("/")
        
        if (Data.length > 2)
        {
            if (Data[2].length < 4)
            {
                Data[2] = dtNovaData.getFullYear();
                //return false;
            }
        }
        else
        {
            Data[2] = dtNovaData.getFullYear();
        }
        
        var nData = new Date(Data[2]+"/"+Data[1]+"/"+Data[0]+" "+"01:00:00");
        if (nData.getDate() == Data[0] && nData.getMonth() + 1 == Data[1] &&
            nData.getFullYear() == Data[2])
        {
            //txtData.value = Data[0]+"/"+Data[1]+"/"+Data[2];
            txtData.value = ((Data[0].length < 2)? "0" + Data[0] : Data[0]) + '/' + ((Data[1].length < 2)? "0" + Data[1] : Data[1]) + '/' + Data[2];
            
            return true;
        }
        else
        {
            return false;
        }
    }
    catch (ex)
    {
        return false;
    }
}

function abre_MsgBox(strTexto, arrBotoes, intLargura, intAltura) {

    var oParams = new Array();
    
    oParams[0] = strTexto;
    oParams[1] = intLargura;
    oParams[2] = intAltura;
    
    for (var i = 3; i <= (arrBotoes.length + 2) ; i++) {
    
        oParams[i] = arrBotoes[i - 3];
    }    
        
    var retValue = window.showModalDialog(Host + '/includes/pop-up/PopUp_MsgBox.aspx', oParams, 'center: yes; help: no; status: false;');
    
    return retValue;

}

// Função para aplicar Tab na tecla [Enter]
function EnterTab() 
{ 
    if (event.keyCode == 13)
    {
        for (var iTab = 0; iTab < this.form.elements.length - 1; iTab++)
        {   
            if (this.form.elements[iTab] == this)
            {
                try
                {
                    this.form.elements[iTab+1].focus();
                    break;
                }
                catch (ex) {}
            }
        }
        return false;
    }
    else
    {
        return event.keyCode;
    }
}

function aplicarEnterTab(f)
{
    for (var iTab = 0; iTab < f.elements.length - 1; iTab++)
    {
        f.elements[iTab].onkeypress = EnterTab;
    }
}

//Função para verificar se um caracter é Alpha
function isAlpha(pSymbol)
{                   
    if ((pSymbol >= 'A' && pSymbol <= 'Z') ||
        (pSymbol >= 'a' && pSymbol <= 'z'))
    {
        return true;
    }
    return false;
}

//converte HexaDecimal para valor Char
//Thiago Jardim Gaona, 12/08/2006
function hexaToChar(strTexto){
    var intPos;
    var strHexaCode;
    var intCharCode;
    var strHexa = new Array("0","1","2","3","4","5","6","7","8","9","A","B","C","D","E","F");

    for(var intCont = 0; intCont < strTexto.length; intCont++){
        if((strTexto.charAt(intCont) == '%') && (intCont < strTexto.length - 2)){
            intPos = intCont;
            strHexaCode = strTexto.substr(intPos+1,2);
            intCharCode = parseInt(((strHexa.toString().indexOf((strHexaCode.charAt(0).toUpperCase()))/2) * 16) + (strHexa.toString().indexOf(strHexaCode.charAt(1).toUpperCase())/2));
            strTexto = strTexto.replace('%' + strHexaCode, String.fromCharCode(intCharCode));
        }
    }
    return strTexto;
}

// verifica acesso usuário
function verificarAcesso(strTela)
{
    var blnAcesso = false;
    var strManutencao = "";
    var lstFuncaoAcesso = sessionASP("funcoes");
    if (lstFuncaoAcesso != null)
    {
        lstFuncaoAcesso = lstFuncaoAcesso.split(",")
        for(var i = 0; i < lstFuncaoAcesso.length; i++ )
        {
            if (lstFuncaoAcesso[i].indexOf(strTela) == 0)
            {
                strManutencao = lstFuncaoAcesso[i]
                strManutencao = strManutencao.substr(strManutencao.length -1, 1);
                return strManutencao;
            }
        }
        location.replace(Host + "/redirectAcesso.aspx?acesso=true");
    }
    else
    {
        location.replace(Host + "/redirectAcesso.aspx?acesso=false");
    }
}

// Objetivo: Validar se o usuário possui acesso à determinada função
// Parâmetro:
//      strFunção: nome da função a ser validada
// Retorno: "S" se o usuário tiver acesso à função passada como parâmetro e 
//          "N" se o contrário ocorrer
function verificarTipoAcesso(strFuncao)
{
    var lstFuncaoAcesso = sessionASP("funcoes");
    var strAcesso;
    if (lstFuncaoAcesso != null)
    {
        lstFuncaoAcesso = lstFuncaoAcesso.split(",")
        for(var i=0; i<lstFuncaoAcesso.length; i++)
        {
            if (lstFuncaoAcesso[i].indexOf(strFuncao) == 0)
            {
                strAcesso = lstFuncaoAcesso[i]
                strAcesso = strAcesso.substr(strAcesso.length -1, 1);
                return strAcesso;
            }
        }
    }
    
    return "N";
}

//exceção para controle
function exception(msg)
{
    this.message = msg;
    this.messages += "\n" + msg;
}

//Função que recebe uma string com data AAAAMMDD e retorna DDMMAAAA
function AMDToDMA(strDate)
{
 str = new String(strDate);

 strDate = str.substr(8,2)+ '/' + str.substr(5,2) + '/' + str.substr(0,4);
 
 return strDate;

}

//_______________________________________________________________________________________________________________________________        
        // valida campos que não permitem caracteres acentuados
        function valida_Alfabeto(objElemento) {
            var strAux;
            
            strAux = objElemento.value.replace('\r\n',' ')
            
            if (strAux.length > 0) {
                var reVerifica = /^[+\/\-0-9a-zA-Z%.&()* ]*$/ 
                if (strAux.search(reVerifica) == -1) {
                    abre_MsgBox('Insira valores sem acentuações',new Array('OK'),350);
                    objElemento.value = '';
                    objElemento.focus();
                    return false;
                }
            }
            return true;
        }
//_______________________________________________________________________________________________________________________________                
        // não permite entrada de caracteres acentuados
        function onKeypress_Alfabeto(objElemento) {
            
            var reVerifica = /^[+\/\-0-9a-zA-Z%.&()* ]*$/
            
            if (String.fromCharCode(event.keyCode).search(reVerifica) == -1) {
            
            switch(String.fromCharCode(event.keyCode)){
                case 'Ç':
                    event.keyCode = 67;
                    break;
                case 'ç':
                    event.keyCode = 99;
                    break;
                case 'Á':
                    event.keyCode = 65;
                    break;
                case 'À':
                    event.keyCode = 65;
                    break;   
                case 'Ã':
                    event.keyCode = 65;
                    break;  
                case 'Â':
                    event.keyCode = 65;
                    break;                                                           
                case 'á':
                    event.keyCode = 97;
                    break;
                case 'à':
                    event.keyCode = 97;
                    break;
                case 'ã':
                    event.keyCode = 97;
                    break;
                case 'â':
                    event.keyCode = 97;
                    break;                                         
                case 'É':
                    event.keyCode = 69;
                    break; 
                case 'È':
                    event.keyCode = 69;
                    break;
                case 'Ê':
                    event.keyCode = 69;
                    break;                    
                case 'é':
                    event.keyCode = 101;
                    break;
                case 'è':
                    event.keyCode = 101;
                    break;                      
                case 'ê':
                    event.keyCode = 101;
                    break;                    
                case 'Í':
                    event.keyCode = 73;
                    break;  
                case 'Ì':
                    event.keyCode = 73;
                    break; 
                case 'í':
                    event.keyCode = 105;
                    break;  
                case 'ì':
                    event.keyCode = 105;
                    break; 
                case 'Ó':
                    event.keyCode = 79;
                    break;  
                case 'Ò':
                    event.keyCode = 79;
                    break;
                case 'Ô':
                    event.keyCode = 79;
                    break;                      
                case 'ó':
                    event.keyCode = 111;
                    break;  
                case 'ò':
                    event.keyCode = 111;
                    break;
                case 'ô':
                    event.keyCode = 111;
                    break;                      
                case 'Ú':
                    event.keyCode = 85;
                    break;  
                case 'Ù':
                    event.keyCode = 85;
                    break; 
                case 'ú':
                    event.keyCode = 117;
                    break;  
                case 'ù':
                    event.keyCode = 117;
                    break;
                case 'ü':
                    event.keyCode = 117;
                    break; 
                case 'Ü':
                    event.keyCode = 85;
                    break;   
                default: event.keyCode = 0;
              }
           
           }
        }

//funcionam como o IndexOf e LastIndexOf do Visual Basic, pois o método indexOf 
//do JavaScript não é suportado pelo Internet Explorer
//Thiago Jardim Gaona, 11/09/2006
function arrayIndexOf(strValor, objArray){
    var intIndex = -1;
    
    for (var intCont = 0; intCont < objArray.length; intCont++){
        if (objArray[intCont] == strValor){
            intIndex = intCont;
            break;
        }
    }
    
    return intIndex;
}

function arrayLastIndexOf(strValor, objArray){
    var intIndex = -1;

    for (var intCont = objArray.length - 1; intCont >= 0; intCont--){
        if (objArray[intCont] == strValor){
            intIndex = intCont;
            break;
        }
    }
    
    return intIndex;
}

//Funcao: MascaraMoeda
//Sinopse: Mascara de preenchimento de moeda
//Parametro:
//   objTextBox : Objeto (TextBox)
//   SeparadorMilesimo : Caracter separador de milésimos
//   SeparadorDecimal : Caracter separador de decimais
//   e : Evento
//Retorno: Booleano
//-----------------------------------------------------
function MascaraMoeda(objTextBox, SeparadorMilesimo, SeparadorDecimal, e)
{
    var sep = 0;
    var key = '';
    var intCont = intContador = 0;
    var intTamanho = intTamanho2 = 0;
    var strCheck = '0123456789';
    var aux = aux2 = '';
    var whichCode = (window.Event) ? e.which : e.keyCode;
    if (objTextBox.value.length > 11)
    {
        e.keyCode = 0;
        return false;
    }
    if (whichCode == 13) return true;
    key = String.fromCharCode(whichCode); // Valor para o código da Chave
    if (strCheck.indexOf(key) == -1) return false; // Chave inválida
    intTamanho = objTextBox.value.length;
    for(intCont = 0; intCont < intTamanho; intCont++)
        if ((objTextBox.value.charAt(intCont) != '0') && (objTextBox.value.charAt(intCont) != SeparadorDecimal)) break;
    aux = '';
    for(; intCont < intTamanho; intCont++)
        if (strCheck.indexOf(objTextBox.value.charAt(intCont))!=-1) aux += objTextBox.value.charAt(intCont);
    aux += key;
    intTamanho = aux.length;
    if (intTamanho == 0) objTextBox.value = '';
    if (intTamanho == 1) objTextBox.value = '0'+ SeparadorDecimal + '0' + aux;
    if (intTamanho == 2) objTextBox.value = '0'+ SeparadorDecimal + aux;
    if (intTamanho > 2) {
        aux2 = '';
        for (intContador = 0, intCont = intTamanho - 3; intCont >= 0; intCont--) {
            if (intContador == 3) {
                aux2 += SeparadorMilesimo;
                intContador = 0;
            }
            aux2 += aux.charAt(intCont);
            intContador++;
        }
        objTextBox.value = '';
        intTamanho2 = aux2.length;
        for (intCont = intTamanho2 - 1; intCont >= 0; intCont--)
        objTextBox.value += aux2.charAt(intCont);
        objTextBox.value += SeparadorDecimal + aux.substr(intTamanho - 2, intTamanho);
    }
    return false;
}

// Função para validar valores numéricos com formato de moeda ao sair da caixa.
function valida_Moeda(objElemento) 
{
    var intContPonto = 0;
    var intContVirgula = 0;
    
    if (objElemento.value.length > 0) 
    {
        if (!validaMoeda(objElemento.value)) 
        {
            abre_MsgBox("Valores Inválidos!", new Array('OK'));
            objElemento.value = '';
            objElemento.focus();
            return false;
        }
        else
        {
            if (objElemento.value.indexOf(".") != -1)
            {
                if (objElemento.value.substr(objElemento.value.indexOf(".") + 1).indexOf(".") != -1)
                {
                    if (objElemento.value.substr(objElemento.value.indexOf(".") + 5).indexOf(".") != -1)
                    {
                        abre_MsgBox("Valores Inválidos!",new Array('OK'));
                        objElemento.value = '';
                        objElemento.focus();
                        return false;
                    }
                }
                intContPonto = 1;
            }
            
            if (objElemento.value.indexOf(",") != -1)
            {
                if (objElemento.value.substr(objElemento.value.indexOf(",") + 1).indexOf(",") != -1)
                {
                    abre_MsgBox("Valores Inválidos!",new Array('OK'));
                    objElemento.value = '';
                    objElemento.focus();
                    return false;
                }
                intContVirgula = 1;
            }
            
            if (intContPonto == 1 && intContVirgula == 1 && (objElemento.value.length > 12 || objElemento.value.length < 8))
            {
                abre_MsgBox("Valores Inválidos!",new Array('OK'));
                objElemento.value = '';
                objElemento.focus();
                return false;
            }
            
            if (intContPonto == 1 && intContVirgula == 0 && objElemento.value.length > 7)
            {
                abre_MsgBox("Valores Inválidos!",new Array('OK'));
                objElemento.value = '';
                objElemento.focus();
                return false;
            }
            
            if (intContPonto == 0 && intContVirgula == 1 && objElemento.value.length > 6)
            {
                abre_MsgBox("Valores Inválidos!",new Array('OK'));
                objElemento.value = '';
                objElemento.focus();
                return false;
            }
            
            if (intContPonto == 0 && intContVirgula == 0 && objElemento.value.length > 3)
            {
                abre_MsgBox("Valores Inválidos!",new Array('OK'));
                objElemento.value = '';
                objElemento.focus();
                return false;
            }
        }
    }
}
        
//verifica se contem um valor de moeda valido
//Aceita somente numerico, ponto (.) e virgula (,)
function validaMoeda(txtText) 
{
    var strCharacter;

    if (txtText.length > 0) 
    {   
        for (var intCont = 0; intCont < txtText.length; intCont++) 
        {
            strCharacter = txtText.charCodeAt(intCont);
            
            if (strCharacter < 46 || strCharacter > 58) 
            {
                if (strCharacter != 44)
                    return false;
            }
        }
        return true;
    }
}


//Função que converte valores para formatação de moeda
function CvFloatString(moe, precision)
{
	var num, strnum, vira, n, ndig, dig;
	
	vira = "";

	num = Math.abs(moe) & 0xffffffff;
	strnum = "";
	ndig = 0;

	while (num > 0)
	{
		dig = num % 10;
		strnum += dig.toString();
		num = (num / 10) & 0xffffffff;
		ndig++;
		if (ndig == 3)
		{
			strnum += ".";
			ndig = 0;
		}
	}

	if (strnum.charAt(strnum.length-1) == ".")
		strnum = strnum.substr(0,strnum.length-1);

	if (strnum == "")
		vira = "0";
	else
	{
		for ( n = strnum.length-1; n >= 0; n-- )
			vira += strnum.charAt(n);
	}

	vira += ",";

	num = (Math.round(Math.abs(moe) * Math.pow(10, precision)) % Math.pow(10, precision)) & 0xffffffff;
	strnum = "";

	while (num > 0)
	{
		dig = num % 10;
		strnum += dig.toString();
		num = (num / 10) & 0xffffffff;
	}

	for ( n = strnum.length; n < precision; n++ )
		strnum += "0";

	for ( n = strnum.length - 1; n >= 0; n-- )
		vira += strnum.charAt(n);

	if (moe < 0)
		vira = "-" + vira;

	return vira;
}

//inclusão das funções left e right, que não são suportadas pelo Internet Explorer
//Thiago Jardim Gaona, 26/09/2006
function left(strValor, intLen){
	if (intLen <= 0)
	    return '';
	else if (intLen > strValor.length)
	    return strValor;
	else
	    return strValor.substring(0, intLen);
}

function right(strValor, intLen){
    if (intLen <= 0)
       return '';
    else if (intLen > strValor.length)
       return strValor;
    else{
       var iLen = strValor.length;
       return strValor.substring(iLen, iLen - intLen);
    }
}


function formata_Numero_Decimal(pnumber,decimals)
{
    if (isNaN(pnumber)) { return 0};
    if (pnumber=='') { return 0};
	
    var snum = new String(pnumber);
    var sec = snum.split('.');
    var whole = parseFloat(sec[0]);
    var result = '';
	
    if(sec.length > 1){
        var dec = new String(sec[1]);
        dec = String(parseFloat(sec[1])/Math.pow(10,(dec.length - decimals)));
        dec = String(whole + Math.round(parseFloat(dec))/Math.pow(10,decimals));
        var dot = dec.indexOf('.');
        if(dot == -1){
	        dec += '.'; 
	        dot = dec.indexOf('.');
        }
        while(dec.length <= dot + decimals) { dec += '0'; }
        result = dec.replace(".",",");
    } else{
        var dot;
        var dec = new String(whole);
        dec += ',';
        dot = dec.indexOf(',');		
        while(dec.length <= dot + decimals) { dec += '0'; }
        result = dec;
    }	
    
    sec = result.split(',');
    
    result = CvFloatString1(sec[0],3);
    
    result += ',' + sec[1];
    
    return result;
}

function formatNumber(pnumber,decimals)
{
	        if (isNaN(pnumber)) { return 0};
	        if (pnumber=='') { return 0};
        	
	        var snum = new String(pnumber);
	        var sec = snum.split('.');
	        var whole = parseFloat(sec[0]);
	        var result = '';
        	
	        if(sec.length > 1){
		        var dec = new String(sec[1]);
		        dec = String(parseFloat(sec[1])/Math.pow(10,(dec.length - decimals)));
		        dec = String(whole + Math.round(parseFloat(dec))/Math.pow(10,decimals));
		        var dot = dec.indexOf('.');
		        if(dot == -1){
			        dec += '.'; 
			        dot = dec.indexOf('.');
		        }
		        while(dec.length <= dot + decimals) { dec += '0'; }
		        result = dec.replace(".",",");
	        } else{
		        var dot;
		        var dec = new String(whole);
		        dec += ',';
		        dot = dec.indexOf(',');		
		        while(dec.length <= dot + decimals) { dec += '0'; }
		        result = dec;
	        }	
	        return result;
        }
 // Formata numero decimal só com pontos       
 function CvFloatString1(moe, precision)
{
	var num, strnum, vira, n, ndig, dig;
	
	vira = "";

	num = Math.abs(moe) & 0xffffffff;
	strnum = "";
	ndig = 0;

	while (num > 0)
	{
		dig = num % 10;
		strnum += dig.toString();
		num = (num / 10) & 0xffffffff;
		ndig++;
		if (ndig == 3)
		{
			strnum += ".";
			ndig = 0;
		}
	}

	if (strnum.charAt(strnum.length-1) == ".")
		strnum = strnum.substr(0,strnum.length-1);

	if (strnum == "")
		vira = "0";
	else
	{
		for ( n = strnum.length-1; n >= 0; n-- )
			vira += strnum.charAt(n);
	}

	return vira;
}

var OrdZero = '0'.charCodeAt(0);
function CharToInt(ch)
{
return ch.charCodeAt(0) - OrdZero;
}


function IntToChar(intt)
{
return String.fromCharCode(intt + OrdZero);
}


function CheckIEAC(ie){
if (ie.length != 13)
return false;
var b = 4, soma = 0;

for (var i = 0; i <= 10; i++)
{
soma += CharToInt(ie.charAt(i)) * b;
--b;
if (b == 1) { b = 9; }
}
dig = 11 - (soma % 11);
if (dig >= 10) { dig = 0; }
resultado = (IntToChar(dig) == ie.charAt(11));
if (!resultado) { return false; }

b = 5;
soma = 0;
for (var i = 0; i <= 11; i++)
{
soma += CharToInt(ie.charAt(i)) * b;
--b;
if (b == 1) { b = 9; }
}
dig = 11 - (soma % 11);
if (dig >= 10) { dig = 0; }
if (IntToChar(dig) == ie.charAt(12)) { return true; } else { return false; }
} //AC


function CheckIEAL(ie)
{
if (ie.length != 9)
  return false;
var b = 9, soma = 0;
for (var i = 0; i <= 7; i++)
{
   soma += CharToInt(ie.charAt(i)) * b;
   --b;
}
soma *= 10;
dig = soma - Math.floor(soma / 11) * 11;
if (dig == 10) { dig = 0; }
return (IntToChar(dig) == ie.charAt(8));
} //AL


function CheckIEAM(ie)
{
if (ie.length != 9)
  return false;
var b = 9, soma = 0;
for (var i = 0; i <= 7; i++)
{
  soma += CharToInt(ie.charAt(i)) * b;
  b--;
}
if (soma < 11) { dig = 11 - soma; }
else {
   i = soma % 11;
   if (i <= 1) { dig = 0; } else { dig = 11 - i; }
}
return (IntToChar(dig) == ie.charAt(8));
} //am


function CheckIEAP(ie)
{
if (ie.length != 9)
  return false;
var p = 0, d = 0, i = ie.substring(1, 8);
if ((i >= 3000001) && (i <= 3017000))
{
  p =5;
  d = 0;
}
else if ((i >= 3017001) && (i <= 3019022))
{
  p = 9;
  d = 1;
}
b = 9;
soma = p;
for (var i = 0; i <= 7; i++)
{
  soma += CharToInt(ie.charAt(i)) * b;
  b--;
}
dig = 11 - (soma % 11);
if (dig == 10)
{
   dig = 0;
}
else if (dig == 11)
{
   dig = d;
}
return (IntToChar(dig) == ie.charAt(8));
} //ap


function CheckIEBA(ie)
{
if (ie.length != 8)
  return false;
die = ie.substring(0, 8);
var nro = new Array(8);
var dig = -1;
for (var i = 0; i <= 7; i++)
{
  nro[i] = CharToInt(die.charAt(i));
}
var NumMod = 0;
if (String(nro[0]).match(/[0123458]/))
   NumMod = 10;
else
   NumMod = 11;
b = 7;
soma = 0;
for (i = 0; i <= 5; i++)
{
  soma += nro[i] * b;
  b--;
}
i = soma % NumMod;
if (NumMod == 10)
{
  if (i == 0) { dig = 0; } else { dig = NumMod - i; }
}
else
{
  if (i <= 1) { dig = 0; } else { dig = NumMod - i; }
}
resultado = (dig == nro[7]);
if (!resultado) { return false; }
b = 8;
soma = 0;
for (i = 0; i <= 5; i++)
{
  soma += nro[i] * b;
  b--;
}
soma += nro[7] * 2;
i = soma % NumMod;
if (NumMod == 10)
{
  if (i == 0) { dig = 0; } else { dig = NumMod - i; }
}
else
{
  if (i <= 1) { dig = 0; } else { dig = NumMod - i; }
}
return (dig == nro[6]);
} //ba


function CheckIECE(ie)
{
if (ie.length > 9)
  return false;
die = ie;
if (ie.length < 9)
{
  while (die.length <= 8)
   die = '0' + die;
}
var nro = Array(9);
for (var i = 0; i <= 8; i++)
  nro[i] = CharToInt(die);
b = 9;
soma = 0;
for (i = 0; i <= 7; i++)
{
  soma += nro[i] * b;
  b--;
}
dig = 11 - (soma % 11);
if (dig >= 10)
  dig = 0;
return (dig == nro[8]);
} //ce


function CheckIEDF(ie)
{
if (ie.length != 13)
  return false;
var nro = new Array(13);
for (var i = 0; i <= 12; i++)
  nro[i] = CharToInt(ie.charAt(i));
b = 4;
soma = 0;
for (i = 0; i <= 10; i++)
{
  soma += nro[i] * b;
  b--;
  if (b == 1)
   b = 9;
}
dig = 11 - (soma % 11);
if (dig >= 10)
  dig = 0;
resultado = (dig == nro[11]);
if (!resultado)
  return false;  
b = 5;
soma = 0;
for (i = 0; i <= 11; i++)
{
  soma += nro[i] * b;
  b--;
  if (b == 1)
   b = 9;
}
dig = 11 - (soma % 11);
if (dig >= 10)
  dig = 0;
return (dig == nro[12]);
}


// CHRISTOPHE T. C. <wG @ codingz.info>
function CheckIEES(ie)
{
if (ie.length != 9)
  return false;
var nro = new Array(9);
for (var i = 0; i <= 8; i++)
  nro[i] = CharToInt(ie.charAt(i));
b = 9;
soma = 0;
for (i = 0; i <= 7; i++)
{
  soma += nro[i] * b;
  b--;
}
i = soma % 11;
if (i < 2)
  dig = 0;
else
  dig = 11 - i;
return (dig == nro[8]);
}


function CheckIEGO(ie)
{
if (ie.length != 9)
  return false;
s = ie.substring(0, 2);
if ((s == '10') || (s == '11') || (s == '15'))
{
  var nro = new Array(9);
  for (var i = 0; i <= 8; i++)
   nro[i] = CharToInt(ie.charAt(i));
  n = Math.floor(ie / 10);
  if (n = 11094402)
  {
   if ((nro[8] == 0) || (nro[8] == 1))
return true;
  }
  b = 9;
  soma = 0;
  for (i = 0; i <= 7; i++)
  {
   soma += nro[i] * b;
   b--;
  }
  i = soma % 11;
  if (i == 0)
   dig = 0;
  else
  {
   if (i == 1)
   {
if ((n >= 10103105) && (n <= 10119997))
  dig = 1;
else
  dig = 0;
   }
   else
dig = 11 - i;
  }
  return (dig == nro[8]);
}
}


function CheckIEMA(ie)
{
if (ie.length != 9)
  return false;
var nro = new Array(9);
for (var i = 0; i <= 8; i++)
  nro[i] = CharToInt(ie.charAt(i));
b = 9;
soma = 0;
for (i = 0; i <= 7; i++)
{
  soma += nro[i] * b;
  b--;
}
i = soma % 11;
if (i <= 1)
  dig = 0;
else
  dig = 11 - i;
return (dig == nro[8]);
}


function CheckIEMT(ie)
{
if (ie.length < 9)
  return false;
die = ie;
if (die.length < 11)
{
  while (die.length <= 10)
   die = '0' + die;
  var nro = new Array(11);
  for (var i = 0; i <= 10; i++)
   nro[i] = CharToInt(die);
  b = 3;
  soma = 0;
  for (i = 0; i <= 9; i++)
  {
   soma += nro[i] * b;
   b--;
   if (b == 1)
b = 9;
  }
  i = soma % 11;
  if (i <= 1)
   dig = 0;
  else
   dig = 11 - i;
  return (dig == nro[10]);
}
} //muito


function CheckIEMS(ie)
{
if (ie.length != 9)
  return false;
if (ie.substring(0,2) != '28')
  return false;
var nro = new Array(9);
for (var i = 0; i <= 8; i++)
  nro[i] = CharToInt(ie.charAt(i));
b = 9;
soma = 0;
for (i = 0; i <= 7; i++)
{
  soma += nro[i] * b;
  b--;
}
i = soma % 11;
if (i <= 1)
  dig = 0;
else
  dig = 11 - i;
return (dig == nro[8]);
} //ms


function CheckIEPA(ie)
{
if (ie.length != 9)
  return false;
if (ie.substring(0, 2) != '15')
  return false;
var nro = new Array(9);
for (var i = 0; i <= 8; i++)
  nro[i] = CharToInt(ie.charAt(i));
b = 9;
soma = 0;
for (i = 0; i <= 7; i++)
{
  soma += nro[i] * b;
  b--;
}
i = soma % 11;
if (i <= 1)
  dig = 0;
else
  dig = 11 - i;
return (dig == nro[8]);
} //pra


function CheckIEPB(ie)
{
if (ie.length != 9)
  return false;
var nro = new Array(9);
for (var i = 0; i <= 8; i++)
  nro[i] = CharToInt(ie.charAt(i));
b = 9;
soma = 0;
for (i = 0; i <= 7; i++)
{
  soma += nro[i] * b;
  b--;  
}
i = soma % 11;
if (i <= 1)
  dig = 0;
else
  dig = 11 - i;
return (dig == nro[8]);
} //pb


function CheckIEPR(ie)
{
if (ie.length != 10)
  return false;
var nro = new Array(10);
for (var i = 0; i <= 9; i++)
  nro[i] = CharToInt(ie.charAt(i));
b = 3;
soma = 0;
for (i = 0; i <= 7; i++)
{
  soma += nro[i] * b;
  b--;
  if (b == 1)
   b = 7;
}
i = soma % 11;
if (i <= 1)
  dig = 0;
else
  dig = 11 - i;
resultado = (dig == nro[8]);
if (!resultado)
  return false;
b = 4;
soma = 0;
for (i = 0; i <= 8; i++)
{
  soma += nro[i] * b;
  b--;
  if (b == 1)
   b = 7;
}
i = soma % 11;
if (i <= 1)
  dig = 0;
else
  dig = 11 - i;
return (dig == nro[9]);
} //pr


function CheckIEPE(ie)
{
if (ie.length != 14)
  return false;
var nro = new Array(14);
for (var i = 0; i <= 13; i++)
  nro[i] = CharToInt(ie.charAt(i));
b = 5;
soma = 0;
for (i = 0; i <= 12; i++)
{
  soma += nro[i] * b;
  b--;
  if (b == 0)
   b = 9;
}
dig = 11 - (soma % 11);
if (dig > 9)
  dig = dig - 10;
return (dig == nro[13]);
} //pe


function CheckIEPI(ie)
{
if (ie.length != 9)
  return false;
var nro = new Array(9);
for (var i = 0; i <= 8; i++)
  nro[i] = CharToInt(ie.charAt(i));
b = 9;
soma = 0;
for (i = 0; i <= 7; i++)
{
  soma += nro[i] * b;
  b--;
}
i = soma % 11;
if (i <= 1)
  dig = 0;
else
  dig = 11 - i;
return (dig == nro[8]);
} //pi


function CheckIERJ(ie)
{
if (ie.length != 8)
  return false;
var nro = new Array(8);
for (var i = 0; i <= 7; i++)
  nro[i] = CharToInt(ie.charAt(i));
b = 2;
soma = 0;
for (i = 0; i <= 6; i++)
{
  soma += nro[i] * b;
  b--;
  if (b == 1)
   b = 7;
}
i = soma % 11;
if (i <= 1)
  dig = 0;
else
  dig = 11 - i;
return (dig == nro[7]);
} //rj


// CHRISTOPHE T. C. <wG @ codingz.info>
function CheckIERN(ie)
{
if (ie.length != 9)
  return false;
var nro = new Array(9);
for (var i = 0; i <= 8; i++)
  nro[i] = CharToInt(ie.charAt(i));
b = 9;
soma = 0;
for (i = 0; i <= 7; i++)
{
  soma += nro[i] * b;
  b--;
}
soma *= 10;
dig = soma % 11;
if (dig == 10)
  dig = 0;
return (dig == nro[8]);
} //rn


function CheckIERS(ie)
{
if (ie.length != 10)
  return false;
i = ie.substring(0, 3);
if ((i >= 1) && (i <= 467))
{
  var nro = new Array(10);
  for (var i = 0; i <= 9; i++)
   nro[i] = CharToInt(ie.charAt(i));
  b = 2;
  soma = 0;
  for (i = 0; i <= 8; i++)
  {
   soma += nro[i] * b;
   b--;
   if (b == 1)
b = 9;
  }
  dig = 11 - (soma % 11);
  if (dig >= 10)
   dig = 0;
  return (dig == nro[9]);
} //if i&&i
} //rs


function CheckIEROantigo(ie)
{
if (ie.length != 9) {
return false;
}

var nro = new Array(9);
b=6;
soma =0;

for( var i = 3; i <= 8; i++) {

    nro[i] = CharToInt(ie.charAt(i));

        if( i != 8 ) {
            soma = soma + ( nro[i] * b );
            b--;
        }

}

dig = 11 - (soma % 11);
if (dig >= 10)
  dig = dig - 10;

return (dig == nro[8]);

} //ro-antiga


function CheckIERO(ie)
{

if (ie.length != 14) {
return false;
}

var nro = new Array(14);
b=6;
soma=0;

        for(var i=0; i <= 4; i++) {
    
            nro[i] = CharToInt(ie.charAt(i));

        
                soma = soma + ( nro[i] * b );
                b--;

        }

        b=9;
        for(var i=5; i <= 13; i++) {
    
            nro[i] = CharToInt(ie.charAt(i));

                if ( i != 13 ) {        
                soma = soma + ( nro[i] * b );
                b--;
                }

        }

                        dig = 11 - ( soma % 11);
                            
                            if (dig >= 10)
                                  dig = dig - 10;

                                    return(dig == nro[13]);
                        
} //ro nova


function CheckIERR(ie)
{
if (ie.length != 9)
  return false;
if (ie.substring(0,2) != '24')
  return false;
var nro = new Array(9);
for (var i = 0; i <= 8; i++)
  nro[i] = CharToInt(ie.charAt(i));
var soma = 0;
var n = 0;
for (i = 0; i <= 7; i++)
  soma += nro * ++n;
dig = soma % 9;
return (dig == nro[8]);
} //rr


function CheckIESC(ie)
{
if (ie.length != 9)
  return false;
var nro = new Array(9);
for (var i = 0; i <= 8; i++)
  nro[i] = CharToInt(ie.charAt(i));
b = 9;
soma = 0;
for (i = 0; i <= 7; i++)
{
  soma += nro[i] * b;
  b--;
}
i = soma % 11;
if (i <= 1)
  dig = 0;
else
  dig = 11 - i;
return (dig == nro[8]);
} //sc


// CHRISTOPHE T. C. <wG @ codingz.info>
function CheckIESP(ie)
{
if (((ie.substring(0,1)).toUpperCase()) == 'P')
{
  s = ie.substring(1, 9);
  var nro = new Array(12);
  for (var i = 0; i <= 7; i++)
   nro[i] = CharToInt(s);
  soma = (nro[0] * 1) + (nro[1] * 3) + (nro[2] * 4) + (nro[3] * 5) +
   (nro[4] * 6) + (nro[5] * 7) + (nro[6] * 8) + (nro[7] * 10);
  dig = soma % 11;
  if (dig >= 10)
   dig = 0;
  resultado = (dig == nro[8]);
  if (!resultado)
   return false;
}
else
{
  if (ie.length != 12 )
   return false;
  var nro = new Array(12);
  for (var i = 0; i <= 11; i++)
   nro[i] = CharToInt(ie.charAt(i));
  soma = (nro[0] * 1) + (nro[1] * 3) + (nro[2] * 4) + (nro[3] * 5) +
   (nro[4] * 6) + (nro[5] * 7) + (nro[6] * 8) + (nro[7] * 10);
  dig = soma % 11;
  if (dig >= 10)
   dig = 0;
  resultado = (dig == nro[8]);
  if (!resultado)
   return false;
  soma = (nro[0] * 3) + (nro[1] * 2) + (nro[2] * 10) + (nro[3] * 9) +
   (nro[4] * 8) + (nro[5] * 7) + (nro[6] * 6)  + (nro[7] * 5) +
   (nro[8] * 4) + (nro[9] * 3) + (nro[10] * 2);
  dig = soma % 11;
  if (dig >= 10)
   dig = 0;
  return (dig == nro[11]);
}
} //sp


function CheckIESE(ie)
{
if (ie.length != 9)
  return false;
var nro = new Array(9);
for (var i = 0; i <= 8; i++)
  nro[i] = CharToInt(ie.charAt(i));
b = 9;
soma = 0;
for (i = 0; i <= 7; i++)
{
  soma += nro[i] * b;
  b--;
}
dig = 11 - (soma % 11);
if (dig >= 10)
  dig = 0;
return (dig == nro[8]);
} //se


function CheckIETO(ie)
{
if (ie.length != 9) {
return false;
}

var nro = new Array(9);
b=9;
soma=0;

for (var i=0; i <= 8; i++ ) {

nro[i] = CharToInt(ie.charAt(i));

if(i != 8) {
soma = soma + ( nro[i] * b );
b--;
}


}

ver = soma % 11;

if ( ver < 2 )

dig=0;

if ( ver >= 2 )
dig = 11 - ver;

return(dig == nro[8]);
} //to


//inscrição estadual antiga
function CheckIETOantigo(ie)
{

if ( ie.length != 11 ) {
    return false;

}


var nro = new Array(11);
b=9;
soma=0;

s = ie.substring(2, 4);

    if( s != '01' || s != '02' || s != '03' || s != '99' ) {


        for ( var i=0; i <= 10; i++)
        {

            nro[i] = CharToInt(ie.charAt(i));    

            if( i != 3 || i != 4) {

            soma = soma + ( nro[i] * b );
            b--;
            
            } // if ( i != 3 || i != 4 )

        } //fecha for


            resto = soma % 11;        
            
                if( resto < 2 ) {    

                    dig = 0;

                }


                if ( resto >= 2 ) {

                    dig = 11 - resto;

                }            

                return (dig == nro[10]);

    } // fecha if


}//fecha função CheckIETOantiga


function CheckIEMG(ie)
{
if (ie.substring(0,2) == 'PR')
  return true;
if (ie.substring(0,5) == 'ISENT')
  return true;
if (ie.length != 13)
  return false;
dig1 = ie.substring(11, 12);
dig2 = ie.substring(12, 13);
inscC = ie.substring(0, 3) + '0' + ie.substring(3, 11);
insc=inscC.split('');
npos = 11;
i = 1;
ptotal = 0;
psoma = 0;
while (npos >= 0)
{
  i++;
  psoma = CharToInt(insc[npos]) * i;  
  if (psoma >= 10)
   psoma -= 9;
  ptotal += psoma;
  if (i == 2)
   i = 0;
  npos--;
}
nresto = ptotal % 10;
if (nresto == 0)
  nresto = 10;
nresto = 10 - nresto;
if (nresto != CharToInt(dig1))
  return false;
npos = 11;
i = 1;
ptotal = 0;
is=ie.split('');
while (npos >= 0)
{
  i++;
  if (i == 12)
   i = 2;
  ptotal += CharToInt(is[npos]) * i;
  npos--;
}
nresto = ptotal % 11;
if ((nresto == 0) || (nresto == 1))
  nresto = 11;
nresto = 11 - nresto;  
return (nresto == CharToInt(dig2));
}


function CheckIE(ie, estado)
{
ie = ie.replace(/\./g, '');
ie = ie.replace(/\\/g, '');
ie = ie.replace(/\-/g, '');
ie = ie.replace(/\//g, '');
if ( ie == 'ISENTO')
  return true;
switch (estado)
{
  case 'MG': return CheckIEMG(ie); break;
  case 'AC': return CheckIEAC(ie); break;
  case 'AL': return CheckIEAL(ie); break;
  case 'AM': return CheckIEAM(ie); break;
  case 'AP': return CheckIEAP(ie); break;
  case 'BA': return CheckIEBA(ie); break;
  case 'CE': return CheckIECE(ie); break;
  case 'DF': return CheckIEDF(ie); break;
  case 'ES': return CheckIEES(ie); break;
  case 'GO': return CheckIEGO(ie); break;
  case 'MA': return CheckIEMA(ie); break;
  case 'muito': return CheckIEMT(ie); break;
  case 'MS': return CheckIEMS(ie); break;
  case 'pra': return CheckIEPA(ie); break;
  case 'PB': return CheckIEPB(ie); break;
  case 'PR': return CheckIEPR(ie); break;
  case 'PE': return CheckIEPE(ie); break;
  case 'PI': return CheckIEPI(ie); break;
  case 'RJ': return CheckIERJ(ie); break;
  case 'RN': return CheckIERN(ie); break;
  case 'RS': return CheckIERS(ie); break;
  case 'RO': return ((CheckIERO(ie)) || (CheckIEROantigo(ie))); break;
  case 'RR': return CheckIERR(ie); break;
  case 'SC': return CheckIESC(ie); break;
  case 'SP': return CheckIESP(ie); break;
  case 'SE': return CheckIESE(ie); break;
  case 'TO': return ((CheckIETO(ie)) || (CheckIETOantigo(ie))); break;//return CheckIETO(ie); break;        
}
}

// Validação de email
function validaFormatoEmail(strValor)
{
    var rx = /^[\w\.\-_&]+@\w+\.\w+(\.\w+)*$/i;
    
    if(!strValor.match(rx))
        return false;
    
    return true;
}

function isEmailTextBox(objTextBox)
{
    if(objTextBox.value != "")
        if(!validaFormatoEmail(objTextBox.value))
        {
            alert("Formato de e-mail inválido!");
            objTextBox.focus();
        }
}

function validarFormatoHHmm(campo){
    //Funcao valida se o campo esta no formato hh:mm. Caso o campo estiver vazio a validacao nao e aplicada    
    
    var boolValorInvalido = false;
    var strMsgValidacao = "Valor informado inválido. O valor deve estar no formato hh:mm !";
    var strValorHora = "";
    var strValorMinuto = "";
    
    if(campo.value == ""){
        //campo vazio, nao aplica validacao
        return true;    
    }else{
        //Campo preenchido, valida o valor informado
        if(campo.value.length < 5){
            //Valor informado incompleto
            boolValorInvalido = true;   
        }else{
            strValorHora = campo.value.split(':')[0];
            strValorMinuto = campo.value.split(':')[1];
            if(strValorHora.length < 2 || strValorMinuto.length < 2){
                //Valor informado incorreto
                boolValorInvalido = true;
            }else{
                //verifica se foi informado numeros, evitando ctrl+v
                if(isNaN(strValorHora) || isNaN(strValorMinuto)){
                    boolValorInvalido = true;
                }
            }

        }               
    }
    if(boolValorInvalido){
        //Valor invalido, apresenta msg e mantem o foco/cursor no campo
        alert(strMsgValidacao);
        campo.focus();
        return false;
    }else{
        //Valor informado valido
        return true;
    }
}