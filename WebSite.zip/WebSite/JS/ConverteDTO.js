﻿// JScript File

// Converte de DTO no js para "Mapa XML".
// Este "Mapa XML" será covertido em DTO do 
// lado do servidor pela função XMLToDTO.
function DTOToXML(objDTO)
{   
    try
    {
        var structDTO = new ActiveXObject("Msxml.DOMDocument");
        structDTO.async = false
        var strXML = eval(objDTO).SchemaXML;    
        structDTO.loadXML(strXML);
        var ListTag = structDTO.documentElement.childNodes;
    } catch (e)
    {
        alert("Erro: DTOToXML()\nErro ao Popular " + objDTO);
        alert(e.message);
    }
    populaDTOToXML(ListTag, objDTO);
    var strXMLTemp = structDTO.xml;
    return strXMLTemp.replace("\r\n", "")//retira quebra de linhas    
}

// Função utilizada pela function DTOToXML
// OBS: não utilizar esta função
function populaDTOToXML(ListTag, objDTO)
{
    for (var i = 0; i < ListTag.length; i ++)
    {
        try
        {
            if (ListTag[i].childNodes[0].nodeName == "#text")
            {
                try{
                    if (ListTag[i].attributes[0].nodeValue == "System.DateTime")
                    {
                        var dtValue = new Date();
                        dtValue = eval(objDTO + "." + ListTag[i].nodeName)
                        ListTag[i].childNodes[0].nodeValue = dtValue.getHours()+':'+dtValue.getMinutes()+':'+dtValue.getSeconds()+' '+
                                                                dtValue.getDate()+'-'+(dtValue.getMonth()+1)+'-'+dtValue.getFullYear();
                    }
                    
                    else
                    {
                        if (ListTag[i].attributes[0].nodeValue == "System.Boolean")
                        {
                            if ((eval(objDTO + "." + ListTag[i].nodeName) == true) || (eval(objDTO + "." + ListTag[i].nodeName) == false))
                            {
                                ListTag[i].childNodes[0].nodeValue = "'" + eval(objDTO + "." + ListTag[i].nodeName) + "'"
                            }
                            else
                            {
                                ListTag[i].childNodes[0].nodeValue = eval(objDTO + "." + ListTag[i].nodeName)
                            }
                        }
                        else
                        {
                            ListTag[i].childNodes[0].nodeValue = (eval(objDTO + "." + ListTag[i].nodeName) == null) ? "null" : eval(objDTO + "." + ListTag[i].nodeName);
                        }
                        
                        //ListTag[i].childNodes[0].nodeValue = (eval(objDTO + "." + ListTag[i].nodeName) == true || eval(objDTO + "." + ListTag[i].nodeName) == false) ? eval("'" + objDTO + "." + ListTag[i].nodeName + "'") : eval(objDTO + "." + ListTag[i].nodeName);
                    }
                } catch (e){}
            }
            else if(ListTag[i].attributes[0].nodeValue != "Array")
            {
                if(eval(objDTO+"."+ListTag[i].nodeName) != null)
                {
                    populaDTOToXML(ListTag[i].childNodes[0].childNodes, objDTO + "." +ListTag[i].nodeName);
                }
            }
            else if (ListTag[i].attributes[0].nodeValue == "Array")
            {
                if(eval(objDTO+"."+ListTag[i].nodeName) != null)
                {
                    for (var z = 0; z < eval(objDTO+"."+ListTag[i].nodeName).length; z++)
                    {
                        var newNode = ListTag[i].childNodes[z].cloneNode(true)
                        ListTag[i].appendChild (newNode)
                        if (ListTag[i].childNodes[z].childNodes[0].nodeName == "#text")
                        {
                            ListTag[i].childNodes[z].childNodes[0].nodeValue = (eval(objDTO + "." +ListTag[i].nodeName + "[" + z + "]") == null) ? "null" : eval(objDTO + "." +ListTag[i].nodeName + "[" + z + "]");
                        }
                        else
                        {
                            populaDTOToXML(ListTag[i].childNodes[z].childNodes, objDTO + "." +ListTag[i].nodeName + "[" + z + "]");
                        }
                    }
                }
                var lastNode = ListTag[i].lastChild;
                ListTag[i].removeChild(lastNode);
            }
        } catch (e)
        {
            alert("Erro: populaDTOToXML()\nErro ao Popular " + objDTO + "." + ListTag[i].nodeName);
            alert(e.message);
        }
    }
}